/* Pure domain engine. No DOM, no fabricated missing values. */
(function(root){'use strict';
const pools={BA:'照顧及專業服務',GA:'喘息服務',SC:'短照服務'};
const num=v=>v==null||String(v).trim()===''?null:(Number.isFinite(Number(String(v).replace(/,/g,'')))?Number(String(v).replace(/,/g,'')):null);
const date=v=>{if(!v)return'';if(v instanceof Date)return Number.isNaN(v.getTime())?'':v.toISOString().slice(0,10);let s=String(v).trim(),m=s.match(/^(\d{3,4})[-/年](\d{1,2})[-/月](\d{1,2})/);if(!m&&/^\d{7}$/.test(s))m=[s,s.slice(0,3),s.slice(3,5),s.slice(5)];if(!m)return'';const y=+m[1]+(+m[1]<1911?1911:0),d=`${y}-${m[2].padStart(2,'0')}-${m[3].padStart(2,'0')}`;const parsed=new Date(d+'T00:00:00Z');return !Number.isNaN(parsed.getTime())&&parsed.toISOString().slice(0,10)===d?d:''};
const pool=c=>/^GA/i.test(c)?'GA':/^SC/i.test(c)?'SC':/^(BA|BB|BC|BD|CA|CB|CC|CD)/i.test(c)?'BA':'OTHER';
const ident=r=>String(r.person||r.idno||r.case_no||r.name||'').trim();
const hash=v=>{let n=2166136261;for(const c of JSON.stringify(v)){n^=c.charCodeAt(0);n=Math.imul(n,16777619)}return(n>>>0).toString(16)};
const cancelled=r=>/取消|撤銷|無效|作廢|停用/.test(r.status||'');
const active=(r,d)=>(!r.start||r.start<=d)&&(!r.end||r.end>=d)&&!cancelled(r);
const latest=arr=>arr.slice().sort((a,b)=>String(b.updated||b.asof||'').localeCompare(String(a.updated||a.asof||'')))[0];
function choose(arr,issues,label){if(!arr.length)return null;const r=latest(arr),same=arr.filter(x=>String(x.updated||x.asof||'')===String(r.updated||r.asof||''));if(new Set(same.map(x=>JSON.stringify(Object.fromEntries(Object.entries(x).filter(([k])=>!['source','row','importedAt','batch'].includes(k)))))).size>1)issues.push(`${label}同版本內容矛盾`);return r}
function dedupe(rows,type){const out=[],audit=[],seen=new Map();for(const r of rows){const identity=ident(r);const k=r.recordId?`${identity}|${type}|${r.recordId}`:JSON.stringify([identity,r.code,r.date,r.slot,r.employee,r.qty]);const old=seen.get(k);if(!old){seen.set(k,r);continue}if(r.recordId){if(String(r.updated||'')>String(old.updated||'')){audit.push({...old,reason:'同紀錄較舊版本'});seen.set(k,r)}else if(String(r.updated||'')===String(old.updated||'')&&hash({...old,source:'',row:0,batch:'',importedAt:''})!==hash({...r,source:'',row:0,batch:'',importedAt:''})){audit.push({...r,reason:'紀錄ID同版本矛盾',blocking:true});}else audit.push({...r,reason:'重複紀錄／較舊版本'})}else{audit.push({...r,reason:'相同業務欄位重複，已去重；缺紀錄ID需覆核',blocking:!r.employee&&!r.slot})}}for(const r of seen.values())out.push(r);return{rows:out,audit}}
function formula(K,R,S,P,full){[K,R,S,P]=[K,R,S,P].map(num);const errors=[];if(K!=null&&R!=null&&R>K)errors.push(`實際服務超核定${R-K}支`);const D=R==null||S==null?null:R+S;if(K!=null&&D!=null&&R<=K&&D>K)errors.push(`預排超核定${D-K}支`);if(K!=null&&P!=null&&P>K)errors.push('已配支數超過核定，待查');if([K,R,S,P].some(x=>x==null||x<0))errors.push('K／R／S／P資料缺漏或無效');const T=K==null||D==null?null:full?K:Math.min(D,K),gap=T==null||P==null?null:Math.max(0,T-P);return{K,R,S,D,T,P,gap,errors,status:errors.length?'待確認／異常':gap>0?(R>P?'現在補配':'月底預配'):'配額已足夠'}}
function price(row,prices,area){if(num(row.price)!=null&&num(row.price)>0)return num(row.price);const p=latest(prices.filter(p=>p.code===row.code&&p.area===area&&active(p,row.date)&&p.verified&&p.source&&num(p.price)>0));return p?num(p.price):null}
function moneyRows(rows,prices,area,errors){let total=0,unknown=false;for(const r of rows){const p=price(r,prices,area);if(p==null){errors.push(`${r.code} ${r.date}支付價格待確認`);unknown=true;continue}if(num(r.qty)==null||num(r.qty)<0){errors.push(`${r.code}服務支數無效`);unknown=true;continue}total+=p*num(r.qty)}return unknown?null:total}
function compute(data,ctx){
 const all=[],audit=[],groups=[],start=ctx.month+'-01',end=new Date(Number(ctx.month.slice(0,4)),Number(ctx.month.slice(5)),0).getDate(),finish=ctx.month+'-'+end,cutoff=ctx.cutoff;
 const sd=dedupe(data.services||[],'service'),qd=dedupe(data.schedules||[],'schedule');audit.push(...sd.audit,...qd.audit);
 const people=new Map();for(const c of data.clients||[])people.set(ident(c),c);for(const r of [...sd.rows,...(data.plans||[]),...(data.allocations||[]),...qd.rows])if(!people.has(ident(r)))people.set(ident(r),{person:ident(r),name:r.name||ident(r)});
 for(const [person,c] of people){
  const sr=sd.rows.filter(r=>ident(r)===person),sch=qd.rows.filter(r=>ident(r)===person),plans=(data.plans||[]).filter(r=>ident(r)===person),alloc=(data.allocations||[]).filter(r=>ident(r)===person),events=(data.events||[]).filter(r=>ident(r)===person);
  const codes=[...new Set([...sr,...sch,...plans,...alloc].map(r=>r.code).filter(x=>pool(x)!=='OTHER'))];
  for(const code of codes){
   const errors=[],warnings=[],p=pool(code),key=[ctx.month,person,code].join('|'),review=(data.reviews||{})[key]||{};
   const validServices=sr.filter(r=>r.code===code&&r.date>=start&&r.date<=cutoff&&!cancelled(r)&&r.subsidy!==false);
   const R=validServices.reduce((n,r)=>n+(num(r.qty)||0),0),codePlans=plans.filter(r=>r.code===code&&r.start<=finish&&r.end>=start),ap=choose(alloc.filter(r=>r.code===code&&r.start===start&&r.end===finish),errors,'已配');
   const latestPlan=choose(codePlans.filter(r=>r.scope!=='分段'),errors,'核定'),segments=codePlans.filter(r=>r.scope==='分段');let K=latestPlan?.qty;
   if(segments.length){if(latestPlan)errors.push('核定同時存在整期與分段，請確認');const ranges=new Map();for(const x of segments){const k=x.start+'|'+x.end;const old=ranges.get(k);if(!old||String(x.updated)>String(old.updated))ranges.set(k,x)}const parts=[...ranges.values()].sort((a,b)=>a.start.localeCompare(b.start));if(parts.some((r,i)=>i&&r.start<=parts[i-1].end))errors.push('分段核定期間重疊');K=parts.every(r=>num(r.qty)!=null)?parts.reduce((n,r)=>n+num(r.qty),0):null;}
   const period=(data.coverage||[]).filter(r=>ident(r)===person||ident(r)==='*');
   const scov=latest(period.filter(r=>r.kind==='schedule'&&r.start<=cutoff&&r.end>=finish&&(r.pool===p||r.pool==='ALL')));
   const rcov=latest(period.filter(r=>r.kind==='service'&&r.start<=start&&r.end>=cutoff&&(r.pool===p||r.pool==='ALL')));
   if(!ctx.confirmed||!date(cutoff)||cutoff<start||cutoff>finish)errors.push('請確認本月中央截止日');
   if(!rcov)errors.push('中央涵蓋完整性待確認');
   let future=[],U=0;
   for(const r of sch.filter(x=>x.code===code&&x.date>=start&&x.date<=finish)){
    const reason=cancelled(r)?'取消／無效':r.subsidy===false?'自費':null;if(reason){audit.push({...r,reason});continue}
    const completed=/完成|已執行/.test(r.status||'');const hasActual=validServices.some(a=>a.recordId&&r.serviceId?a.recordId===r.serviceId:a.date===r.date&&a.slot===r.slot&&a.code===r.code&&num(a.qty)===num(r.qty));
    if(completed){audit.push({...r,reason:'已執行排班不列S'});if(!hasActual)U+=num(r.qty)||0;continue}
    if(r.date<=cutoff){audit.push({...r,reason:'截止日以前班次不列S'});continue}
    if(!['有效','預排','未執行','服務中'].includes(r.status)){errors.push('預排狀態待確認');continue}
    const plan=latest(codePlans.filter(x=>active(x,r.date)));const event=latest(events.filter(x=>x.date<=r.date));
    if(event&&/暫停|結案|住院|死亡/.test(event.status)){audit.push({...r,reason:`${event.status}生效後排班`,blocking:true});errors.push(`${r.date} ${event.status}後仍有排班`);continue}
    if(!plan){audit.push({...r,reason:'不在已知核定有效期間',blocking:true});errors.push(`${r.date}預排無有效計畫`);continue}
    future.push(r);
   }
   const S=scov?future.reduce((n,r)=>n+(num(r.qty)||0),0):null;if(!scov)errors.push('剩餘班表涵蓋未到月底');if(U)errors.push(`已執行未上傳／待對帳${U}支`);
   for(const r of validServices)if(!codePlans.some(x=>active(x,r.date)))errors.push(`${r.date}實績無適用核定版本`);
   for(const seg of segments){const u=validServices.filter(r=>active(seg,r.date)).reduce((n,r)=>n+num(r.qty),0),f=future.filter(r=>active(seg,r.date)).reduce((n,r)=>n+num(r.qty),0);if(num(seg.qty)!=null&&u+f>num(seg.qty))errors.push(`${seg.start}～${seg.end}分段超核定`)}
   const fingerprint=hash([person,code,cutoff,validServices,future,codePlans,ap,events,period,ctx.confirmed,(data.prices||[]).filter(r=>r.code===code),(data.budgets||[]).filter(r=>ident(r)===person&&r.pool===p)]);
   const freshReview=review.fingerprint===fingerprint;
   const full=review.mode==='依核定配滿'&&freshReview;
   if(review.mode==='依核定配滿'&&!freshReview)errors.push('配滿確認已因來源變更失效');
   if(full&&(/暫停|結案|住院|死亡/.test(c.status||'')||!codePlans.some(x=>active(x,finish))))errors.push('服務狀態／月底核定不適用配滿');
   let availableK=K;if(p!=='BA'&&latestPlan){const previous=sr.filter(r=>r.code===code&&r.date<start&&active(latestPlan,r.date)&&!cancelled(r)&&r.subsidy!==false).reduce((n,r)=>n+(num(r.qty)||0),0);let previousConfirmed=previous;if(latestPlan.start<start){if(num(latestPlan.usedBeforeMonth)!=null)previousConfirmed=num(latestPlan.usedBeforeMonth);else if(!(data.coverage||[]).some(x=>(ident(x)===person||ident(x)==='*')&&x.kind==='service'&&(x.pool===p||x.pool==='ALL')&&x.start<=latestPlan.start&&x.end>=cutoff))errors.push('期間核定支數對帳完整性待確認');}availableK=num(K)==null?null:Math.max(0,num(K)-previousConfirmed);if(previous>num(K)&&num(K)!=null)errors.push('前期實績已超期間核定');}const f=formula(availableK,R,S,ap&&!cancelled(ap)?ap.qty:null,full);errors.push(...f.errors);
   if(![2,3,4,5,6,7,8].includes(Number(c.cms)))errors.push('CMS等級待確認');if(future.length&&/暫停|結案|住院|死亡/.test(c.status||''))errors.push('個案目前非有效服務狀態，請確認預排');if(!c.a_unit||!c.a_manager)errors.push('A單位／A個管待確認');
   const actualAmount=moneyRows(validServices,data.prices||[],c.area,errors),futureAmount=moneyRows(future,data.prices||[],c.area,errors);let targetAmount=actualAmount==null||futureAmount==null||S==null?null:actualAmount+futureAmount;
   if(full&&f.T>f.D){const v=price({code,date:finish},data.prices||[],c.area);if(v==null){errors.push('配滿新增需求價格待確認');targetAmount=null}else if(targetAmount!=null)targetAmount+=(f.T-f.D)*v;}
   if(!latestPlan&&!segments.length)errors.push('照顧計畫核定待確認');
   if(audit.some(x=>x.blocking&&ident(x)===person&&x.code===code))errors.push('重複／矛盾紀錄待確認');
   const snapshots=[latestPlan,ap,scov,rcov].filter(Boolean);for(const r of snapshots){if(!r.asof&&!r.updated)errors.push('來源快照日期缺漏');else if(ctx.staleDays!=null&&date(r.asof||r.updated)&&((new Date(cutoff)-new Date(date(r.asof||r.updated)))/86400000)>ctx.staleDays)errors.push('來源快照過舊')}
   all.push({...c,...f,person,code,pool:p,key,periodApprovedK:num(K),fingerprint,U,full,review:freshReview?review:null,actualAmount,targetAmount,futureAmount,source:[...new Set(snapshots.map(x=>x.source).filter(Boolean))].join('；'),dates:validServices.map(x=>x.date),errors:[...new Set(errors)],warnings,planDate:latestPlan?.updated||segments.map(x=>x.updated).join('、'),allocationDate:ap?.updated,scheduleDate:scov?.asof});
  }
 }
 const pg=new Map();for(const r of all){const k=r.person+'|'+r.pool;(pg.get(k)||pg.set(k,[]).get(k)).push(r)}
 for(const rows of pg.values()){
  const r=rows[0],issues=[],budget=choose((data.budgets||[]).filter(x=>ident(x)===r.person&&x.pool===r.pool&&x.start<=start&&x.end>=finish),issues,'額度'),actual=rows.some(x=>x.actualAmount==null)?null:rows.reduce((n,x)=>n+x.actualAmount,0),target=rows.some(x=>x.targetAmount==null)?null:rows.reduce((n,x)=>n+x.targetAmount,0);let limit=null,Pamount=num(budget?.allocated);
  if(!budget)issues.push(r.pool==='SC'?'SC核定資料待確認':`${pools[r.pool]}可分配額度待確認`);
  else{if(!date(budget.asof))issues.push('額度來源快照日期缺漏');else if(ctx.staleDays!=null&&(new Date(cutoff)-new Date(date(budget.asof)))/86400000>ctx.staleDays)issues.push('額度來源快照過舊');if(r.pool==='BA'){limit=num(budget.maxTotal);if(limit==null)issues.push('永護寧可配總額上限待確認')}else{if(!budget.scheme&&r.pool==='SC')issues.push('SC適用方案待確認');if(!budget.eligible)issues.push('GA／SC資格及同質服務限制待確認');if(num(budget.remaining)==null||budget.asof!==cutoff)issues.push('期間剩餘額度或對帳截止日待確認');else if(actual==null)issues.push('實際使用金額待確認');else if(budget.basis==='已扣使用與保留')limit=actual+num(budget.remaining);else if(budget.basis==='只扣使用'&&num(budget.reserved)!=null)limit=actual+num(budget.remaining)-num(budget.reserved);else issues.push('剩餘額度扣除口徑待確認')}
   if(Pamount==null||budget.allocationStart!==start||budget.allocationEnd!==finish)issues.push('已配金額／比較期間待確認');
  }
  if(limit!=null&&target!=null&&target>limit)issues.push(`${pools[r.pool]}需求超過可配額度${Math.round(target-limit)}元`);
  if(limit!=null&&limit<0)issues.push('期間剩餘額度無效');
  const gapAmount=Pamount==null||target==null?null:Math.max(0,target-Pamount),blocked=issues.length||rows.some(x=>x.errors.length);
  for(const x of rows){x.poolTarget=target;x.poolLimit=limit;x.poolAllocated=Pamount;x.amountGap=gapAmount;x.budget=budget;x.errors=[...new Set([...x.errors,...issues])];if(blocked&&!x.errors.length)x.errors.push('同額度池其他碼待確認');x.status=x.errors.length?'待確認／異常':x.review&&['本月不需補配','計畫待異動','核定待確認','個案暫停','服務已取消'].includes(x.review.mode)?x.review.mode:(x.gap>0||gapAmount>0)?(x.R>x.P||actual>Pamount?'現在補配':'月底預配'):'配額已足夠';if(x.review?.mode==='A單位已更新'&&(x.gap>0||gapAmount>0))x.status='A單位已更新待驗證';}
  if(!blocked){const notify=rows.filter(x=>['現在補配','月底預配'].includes(x.status));if(notify.length)groups.push({person:r.person,name:r.name,cms:r.cms,a_unit:r.a_unit,a_manager:r.a_manager,pool:r.pool,targetAmount:target,amountGap:gapAmount,rows:notify.filter(x=>x.gap>0),allRows:rows,period:`${start}～${finish}`})}
 }
 return{rows:all,groups,audit,status:!people.size?'尚未計算':!all.length?'服務碼資料待確認':all.some(r=>r.errors.length)?'資料未齊或異常阻擋':groups.length?'有補配需求':'檢查完成，配額足夠'};
}
root.QuotaCore={num,date,pool,pools,ident,hash,dedupe,formula,price,compute};
})(typeof globalThis!=='undefined'?globalThis:this);
