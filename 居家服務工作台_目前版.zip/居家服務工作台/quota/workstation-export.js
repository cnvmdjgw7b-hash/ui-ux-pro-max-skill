(() => {
'use strict';
// Formatting adapter only: calculation and report rows are owned by quota source.
if(window.ExcelJS){const proto=ExcelJS.Workbook.prototype;const original=Object.getOwnPropertyDescriptor(proto,'xlsx')?.get;
 if(original)Object.defineProperty(proto,'xlsx',{configurable:true,get(){const writer=original.call(this);if(!writer.__yhnPrint){const write=writer.writeBuffer.bind(writer),book=this;writer.writeBuffer=function(...args){book.worksheets.forEach(ws=>{ws.pageSetup={...ws.pageSetup,paperSize:9,orientation:'landscape',fitToPage:true,fitToWidth:1,fitToHeight:0,printTitlesRow:'1:6'};});return write(...args);};writer.__yhnPrint=true;}return writer;}});
}
window.YhnQuotaEmbedded={run(action){
 const button=document.getElementById(action==='weekly'?'weeklyExportBtn':'generateBtn');
 if(!button||button.disabled)return {ok:false,message:'請先完成第1、2關報表匯入與比對，再匯出或列印。'};
 if(action==='excel'||action==='weekly'){button.click();return {ok:true,message:'已交由原額度工具產生 Excel；下載結果與錯誤會顯示在操作區。'};}
 if(action==='print'){
  if(!state.gate1Ready||!state.gate2Ready)return {ok:false,message:'請先完成第1、2關。'};
  renderReportPreview(state.previewKind||'cases');
  let print=document.getElementById('quotaPrintContent');if(!print){print=document.createElement('section');print.id='quotaPrintContent';document.body.append(print);}
  print.replaceChildren();const h=document.createElement('h1');h.textContent='花蓮縣私立永護寧居家長照機構';print.append(h);
  const meta=document.createElement('p');meta.textContent='資料月份：'+(state.monthKey||'待確認')+'｜產出日期：'+new Date().toLocaleString('zh-TW',{timeZone:'Asia/Taipei'});print.append(meta);
  const title=document.createElement('h2');title.textContent=document.getElementById('reportPreviewTitle').textContent;print.append(title);
  print.append(document.getElementById('reportPreviewBody').cloneNode(true));
  window.focus();window.print();return {ok:true,message:'已開啟目前報表的列印畫面。完整明細請下載 Excel 後列印。'};
 }
 return {ok:false,message:'請選擇報表工具。'};
}};
})();
