// Use the standard SIMD v7 LSTM build on SIMD/relaxed-SIMD devices.
importScripts('/line-v33/ocr/tesseract-core-simd-lstm.wasm.js');
