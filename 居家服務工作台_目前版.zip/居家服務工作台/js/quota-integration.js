(() => {
'use strict';
window.addEventListener('load',()=>{
 const frame=document.getElementById('quotaIntegratedFrame');
 const status=document.getElementById('quotaIntegrationStatus');
 const retry=document.getElementById('quotaRetry');
 function loadFrame(){retry.hidden=true;status.textContent='正在載入額度與申報工具…';frame.dataset.loaded='true';frame.src='quota/index.html?v=20261019-rc326-'+Date.now();}
 frame.addEventListener('load',()=>{try{const body=frame.contentDocument?.body?.innerText||'';if(/Not found|Internal Error/i.test(body)){status.textContent='額度工具載入失敗，請重新載入。';retry.hidden=false;}else{status.textContent='本頁資料儲存在目前瀏覽器；原工具資料需在此重新匯入，尚未與主任本站案件自動同步。';}}catch{status.textContent='無法確認額度工具狀態，請重新載入。';retry.hidden=false;}});
 retry.onclick=loadFrame;
 function act(action){try{const api=frame.contentWindow?.YhnQuotaEmbedded;if(!api){status.textContent='額度工具正在載入，請稍後再試。';return;}const result=api.run(action);if(result?.message)status.textContent=result.message;}catch{status.textContent='額度工具暫時無法操作，請重新開啟「額度與申報」。';}}
 document.getElementById('quotaExportMain').onclick=()=>act('excel');
 document.getElementById('quotaExportWeekly').onclick=()=>act('weekly');
 document.getElementById('quotaPrintReport').onclick=()=>act('print');
 document.querySelectorAll('[data-quota-legacy]').forEach(button=>button.onclick=()=>{
  // Keep the legacy calculators available only from the unified workspace.
  const target=button.dataset.quotaLegacy;const temporary=document.createElement('button');temporary.className='quick-tool-card';temporary.dataset.openTool=target;document.getElementById('toolHome').append(temporary);temporary.click();temporary.remove();
 });
 for(const id of ['quotaReferenceTool','feeTool']){const section=document.getElementById(id);const back=document.createElement('button');back.type='button';back.className='quick-tool-card secondary-btn';back.dataset.openTool='quotaTool';back.textContent='← 回額度與申報';back.onclick=()=>document.querySelector('#yhnSidebar [data-open-tool="quotaTool"]')?.click();section?.prepend(back);}
});
})();
