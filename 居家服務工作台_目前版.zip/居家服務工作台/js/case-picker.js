(() => {
  'use strict';
  const ROSTER_KEY = 'yhn_workstation_case_roster_v1';
  const SELECTED_KEY = 'yhn_workstation_selected_case_v1';
  const ACTIVITY_KEY = 'yhn_workstation_visit_activity_v1';
  const $ = id => document.getElementById(id);
  const esc = value => String(value || '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  const readRoster = () => {
    try {
      const value = JSON.parse(localStorage.getItem(ROSTER_KEY) || '[]');
      return Array.isArray(value) ? value.filter(item => item && typeof item.id === 'string' && typeof item.name === 'string') : [];
    } catch (_) { return []; }
  };
  let roster = readRoster();
  let selected = null;
  const batchIds = new Set();
  const batchDrafts = new Map();
  const editFields = [['name','個案姓名'],['phone','聯絡電話'],['caseNo','衛福部案號'],['clientId','身分證／統一編號'],['type','個案類型'],['status','目前狀態'],['serviceStart','服務開始日期']];
  function visibleCases() {
    const query = $('casePickerSearch').value.trim().toLocaleLowerCase();
    return roster.filter(item => [item.name,item.phone,item.caseNo,item.clientId].join(' ').toLocaleLowerCase().includes(query));
  }
  function batchMessage(text,error=false) {
    $('caseBatchStatus').textContent=text;
    $('caseBatchStatus').classList.toggle('is-error',error);
  }
  function updateBatchControls() {
    const shown=visibleCases(), checked=shown.filter(item=>batchIds.has(item.id)).length;
    const all=$('caseBatchAll');all.checked=shown.length>0&&checked===shown.length;all.indeterminate=checked>0&&checked<shown.length;all.disabled=!shown.length;
    $('caseBatchSave').disabled=!batchIds.size;$('caseBatchDelete').disabled=!batchIds.size;$('caseBatchClear').disabled=!batchIds.size;
    $('caseBatchCount').textContent=`已選 ${batchIds.size} 筆／共 ${roster.length} 筆`+(batchIds.size>checked?`（含未顯示 ${batchIds.size-checked} 筆）`:'');
    $('caseBatchAllLabel').textContent=$('casePickerSearch').value.trim()?`全選搜尋結果（${shown.length}筆）`:`全選個案（${shown.length}筆）`;
  }
  function commitRoster(next,nextSelected) {
    const previous=localStorage.getItem(ROSTER_KEY),previousSelected=localStorage.getItem(SELECTED_KEY);
    try {
      localStorage.setItem(ROSTER_KEY,JSON.stringify(next));
      if(nextSelected===null)localStorage.removeItem(SELECTED_KEY);
    } catch(error) {
      try {if(previous===null)localStorage.removeItem(ROSTER_KEY);else localStorage.setItem(ROSTER_KEY,previous);if(previousSelected!==null)localStorage.setItem(SELECTED_KEY,previousSelected);} catch(_) {}
      throw new Error('名冊無法儲存，編輯內容已保留，請確認裝置儲存空間。');
    }
    roster=next;
    window.dispatchEvent(new CustomEvent('yhn:case-roster-updated',{detail:{count:next.length}}));
  }
  function saveBatch() {
    if(!batchIds.size)return;
    try {
      const next=roster.map(item=>batchIds.has(item.id)?{...item,...(batchDrafts.get(item.id)||{})}:item);
      if(next.some(item=>batchIds.has(item.id)&&!String(item.name||'').trim()))throw new Error('所選個案姓名不可空白，請補齊後再儲存。');
      commitRoster(next);
      for(const id of batchIds)batchDrafts.delete(id);
      setSelectedCard();invalidateRecordPreviews();renderList();batchMessage(`已儲存 ${batchIds.size} 筆至本機名冊。`);
    } catch(error) {batchMessage(error.message,true);}
  }
  function deleteBatch() {
    const chosen=roster.filter(item=>batchIds.has(item.id));if(!chosen.length)return;
    const names=chosen.slice(0,5).map(item=>item.name).join('、')+(chosen.length>5?'…':'');
    if(!window.confirm(`確認從本機名冊刪除 ${chosen.length} 筆個案？\n${names}`))return;
    try {
      const clearSelected=chosen.some(item=>item.id===selected?.id);
      commitRoster(roster.filter(item=>!batchIds.has(item.id)),clearSelected?null:undefined);
      for(const item of chosen)batchDrafts.delete(item.id);
      batchIds.clear();setSelectedCard();renderList();batchMessage(`已從本機名冊刪除 ${chosen.length} 筆。`);
    } catch(error) {batchMessage(error.message,true);}
  }

  function findSelected() {
    const id = localStorage.getItem(SELECTED_KEY);
    return roster.find(item => item.id === id) || null;
  }
  function setSelectedCard() {
    selected = findSelected();
    $('selectedCaseName').textContent = selected?.name || '點選個案';
    $('selectedCaseMeta').textContent = selected
      ? (selected.caseNo ? `衛福部案號：${selected.caseNo}` : '已選取個案｜切換時會帶入基本資料')
      : '選擇或新增個案，快速帶入家訪與電訪';
  }
  function applySelected(force = false) {
    if (!selected) return;
    window.dispatchEvent(new CustomEvent('yhn:selected-case', {detail:{...selected}}));
    const values = {
      homeClientName: selected.name, phoneClientName: selected.name,
      cpName: selected.name, yhnPlanClient: selected.name, confirmClientName: selected.name,
      homeClientPhone: selected.phone, phoneClientPhone: selected.phone,
      homeClientId: selected.clientId, phoneClientId: selected.clientId,
      homeCaseNo: selected.caseNo, phoneCaseNo: selected.caseNo
    };
    Object.entries(values).forEach(([id, value]) => {
      const field = $(id);
      if (field && (force || !field.value.trim())) {
        field.value = value || '';
        field.dispatchEvent(new Event('input', { bubbles: true }));
        field.dispatchEvent(new Event('change', { bubbles: true }));
      }
    });
    const today = new Date();
    const date = `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`;
    ['cpDate'].forEach(id => { const field = $(id); if (field && !field.value) field.value = date; });
    broadcastVisitClient();
  }
  function visitClientPayload(){return selected?{id:selected.id,name:selected.name,caseNo:selected.caseNo||'',clientId:selected.clientId||'',phone:selected.phone||'',status:selected.status||'',serviceStart:selected.serviceStart||'',careLevel:selected.careLevel||'',supervisor:selected.supervisor||'',gender:selected.gender||''}:null}
  function broadcastVisitClient(){const client=visitClientPayload();[['visit17HomeFrame','家訪'],['visit17PhoneFrame','電訪']].forEach(([id,kind])=>$(id)?.contentWindow?.postMessage({type:'yhn-visit-init',kind,client},location.origin))}
  function saveIframeVisit(payload){
    if(!payload||!['家訪','電訪'].includes(payload.kind)||!clean(payload.name)||!clean(payload.date)||!clean(payload.content))return {ok:false,message:'個案姓名、日期或紀錄內容不足，請檢查後重試。'};
    const identity={name:clean(payload.name),caseNo:clean(payload.caseNo),clientId:clean(payload.clientId),rosterId:clean(payload.rosterId)};
    const client=roster.find(item=>(identity.rosterId&&item.id===identity.rosterId)||(identity.clientId&&item.clientId===identity.clientId)||(identity.caseNo&&item.caseNo===identity.caseNo))||{};
    if(!client.id&&selected&&(selected.name!==identity.name))return {ok:false,message:'目前選取個案與紀錄姓名不符，請重新選擇個案。'};
    const kind=payload.kind,key=kind+'|'+payload.date+'|'+(identity.clientId||identity.caseNo||identity.rosterId||identity.name);
    const rows=readVisitRecords(),at=rows.findIndex(row=>row.key===key);
    const record={id:at>=0?rows[at].id:kind+'-'+Date.now()+'-'+Math.random().toString(36).slice(2,7),kind,date:payload.date,...identity,content:String(payload.content),fields:payload.fields&&typeof payload.fields==='object'?[{id:'visit17',value:JSON.stringify(payload.fields)}]:[],savedAt:Date.now(),key};
    try{
      if(at>=0)rows[at]=record;else rows.push(record);
      localStorage.setItem(RECORDS_KEY,JSON.stringify(rows.slice(-300)));
      const activities=readActivities(),ai=activities.findIndex(row=>row.key===key);
      const activity={key,kind,date:payload.date,...identity,type:client.type||'',status:client.status||'',serviceStart:client.serviceStart||'',supervisor:client.supervisor||''};
      if(ai>=0)activities[ai]=activity;else activities.push(activity);
      localStorage.setItem(ACTIVITY_KEY,JSON.stringify(activities));
      refreshVisitHistory(kind);
      window.dispatchEvent(new CustomEvent('yhn:case-visit-record-updated',{detail:record}));
      return {ok:true};
    }catch(_){return {ok:false,message:'本機儲存空間不足，紀錄未能保存。請先備份或清理空間後重試。'}}
  }
  function invalidateRecordPreviews() {
    [['homeFormPreviewPanel','homeFormPreview','homeFormStatus'],['phoneFormPreviewPanel','phoneFormPreview','phoneFormStatus']].forEach(([panelId, previewId, statusId]) => {
      const panel = $(panelId), preview = $(previewId), status = $(statusId);
      if (panel) panel.hidden = true;
      if (preview) preview.replaceChildren();
      if (status) status.textContent = '個案已切換，請重新產生預覽後再列印。';
    });
  }
  function renderList() {
    const root = $('casePickerList');
    const items = visibleCases();
    root.innerHTML=items.length?items.map(item=>{
      const draft={...item,...(batchDrafts.get(item.id)||{})};
      return `<article class="case-picker-item ${selected?.id===item.id?'is-current':''}"><label class="case-batch-check"><input type="checkbox" data-batch-case="${esc(item.id)}" aria-label="勾選${esc(item.name)}" ${batchIds.has(item.id)?'checked':''}></label><button class="case-picker-select" type="button" data-select-case="${esc(item.id)}"><span class="case-avatar">${esc(item.name.slice(0,1))}</span><span><strong>${esc(item.name)}</strong><small>${item.caseNo?`衛福部案號 ${esc(item.caseNo)}`:'未填衛福部案號'}${item.phone?`　${esc(item.phone)}`:''}</small></span><i>${selected?.id===item.id?'使用中':'選擇'}</i></button><button class="case-picker-delete" type="button" data-delete-case="${esc(item.id)}" aria-label="移除${esc(item.name)}">×</button><details class="case-batch-edit"><summary>編輯個案資料${batchDrafts.has(item.id)?'（未儲存）':''}</summary><div class="case-batch-fields">${editFields.map(([key,label])=>`<label>${label}<input data-batch-edit="${esc(item.id)}" data-field="${key}" type="${key==='serviceStart'?'date':'text'}" value="${esc(draft[key])}" maxlength="${key==='name'?60:100}"></label>`).join('')}</div></details></article>`;
    }).join(''):`<div class="case-picker-empty">${roster.length?'沒有符合的個案。':'尚無個案名冊，使用下方「新增個案資料」建立本機名冊。'}</div>`;
    updateBatchControls();
  }

  const clean = value => String(value == null ? '' : value).replace(/\s+/g, ' ').trim();
  const normalizeKey = value => clean(value).toLowerCase().replace(/[\s＊*：:／/()（）._-]/g, '');
  const aliases = {
    name: ['個案姓名','＊個案姓名傳統姓名','個案姓名傳統姓名','姓名','案主姓名','服務使用者姓名','clientname','name'],
    clientId: ['個案身分證','身分證字號','身分證','身分證／統一編號','統一編號','個案證號','clientid','nationalid'],
    phone: ['個案電話','聯絡電話','電話','手機','行動電話','案主電話','phone','telephone'],
    caseNo: ['衛福部案號','衛福案號','案號','照管案號','個案案號','caseno','casecode'],
    type: ['個案類型','個案類別','分類','服務類型','案類','type','category'],
    status: ['目前狀態','服務狀態','個案狀態','狀態','status'],
    supervisor: ['主責督導','主責居督','督導員','居家督導','督導姓名','supervisor'],
    serviceStart: ['服務開始時間','服務開始日期','服務開始','開案日期','服務起始日','servicestart']
  };
  const aliasKeys = Object.fromEntries(Object.entries(aliases).map(([key, values]) => [key, new Set(values.map(normalizeKey))]));
  function mapPairs(pairs) {
    const item = {};
    pairs.forEach(([label, value]) => {
      const key = Object.keys(aliasKeys).find(name => aliasKeys[name].has(normalizeKey(label)));
      if (key && clean(value)) item[key] = clean(value);
    });
    return item;
  }
  function parseHtml(text) {
    const doc = new DOMParser().parseFromString(text, 'text/html');
    const pairs = [];
    doc.querySelectorAll('tr').forEach(row => {
      const cells = Array.from(row.querySelectorAll('th,td')).map(cell => clean(cell.textContent));
      for (let i = 0; i + 1 < cells.length; i++) pairs.push([cells[i], cells[i + 1]]);
    });
    const result = mapPairs(pairs);
    if (!result.name) {
      const labels = Array.from(doc.querySelectorAll('label,dt,th,strong,b')).map(el => [clean(el.textContent), clean(el.nextElementSibling?.textContent || el.parentElement?.querySelector('input,textarea,select')?.value)]);
      Object.assign(result, mapPairs(labels));
    }
    return result.name ? [result] : [];
  }
  function parseXlsx(buffer) {
    if (!window.XLSX) throw new Error('Excel 解析套件尚未載入，請重新整理後再試。');
    const book = XLSX.read(buffer, { type: 'array', cellDates: true });
    let best = null;
    book.SheetNames.forEach(sheetName => {
      const rows = XLSX.utils.sheet_to_json(book.Sheets[sheetName], { header: 1, raw: false, defval: '' });
      for (let ri = 0; ri < Math.min(rows.length, 30); ri++) {
        const headers = rows[ri].map(clean);
        const nameCol = headers.findIndex(h => aliasKeys.name.has(normalizeKey(h)));
        if (nameCol < 0) continue;
        const score = headers.reduce((sum, h) => sum + (Object.values(aliasKeys).some(set => set.has(normalizeKey(h))) ? 1 : 0), 0);
        if (!best || score > best.score) best = { rows, headers, ri, score };
      }
    });
    if (!best) return [];
    return best.rows.slice(best.ri + 1).map(row => mapPairs(best.headers.map((header, i) => [header, row[i]]))).filter(item => item.name);
  }
  function parseDelimited(text) {
    const first = text.split(/\r?\n/).find(line => line.trim()) || '';
    const delimiter = first.includes('\t') ? '\t' : (first.includes('\u001f') ? '\u001f' : (first.includes(',') ? ',' : ''));
    if (delimiter) {
      const book = window.XLSX?.read(text, { type: 'string', FS: delimiter });
      if (book) {
        const rows = XLSX.utils.sheet_to_json(book.Sheets[book.SheetNames[0]], { header: 1, raw: false, defval: '' });
        for (let i = 0; i < Math.min(rows.length, 15); i++) {
          const headers = rows[i].map(clean);
          if (headers.some(h => aliasKeys.name.has(normalizeKey(h)))) return rows.slice(i + 1).map(row => mapPairs(headers.map((h, j) => [h, row[j]]))).filter(item => item.name);
        }
      }
      const rows = text.split(/\r?\n/).filter(Boolean).map(line => line.split(delimiter).map(clean));
      const hi = rows.findIndex(row => row.some(h => aliasKeys.name.has(normalizeKey(h))));
      if (hi >= 0) return rows.slice(hi + 1).map(row => mapPairs(rows[hi].map((h, i) => [h, row[i]]))).filter(item => item.name);
    }
    const pairs = text.split(/\r?\n/).map(line => {
      const match = line.match(/^\s*([^：:=\t]+)\s*[：:=\t]\s*(.*?)\s*$/);
      return match ? [match[1], match[2]] : null;
    }).filter(Boolean);
    const one = mapPairs(pairs);
    return one.name ? [one] : [];
  }
  function parseXml(text) {
    const doc = new DOMParser().parseFromString(text, 'application/xml');
    if (doc.querySelector('parsererror')) throw new Error('XML 格式無法讀取。');
    const nodes = Array.from(doc.querySelectorAll('row, Row, case, Case, client, Client, record, Record, item, Item'));
    const results = nodes.map(node => {
      const pairs = Array.from(node.attributes).map(attr => [attr.name, attr.value]);
      Array.from(node.children).forEach(child => pairs.push([child.localName || child.tagName, clean(child.textContent)]));
      return mapPairs(pairs);
    }).filter(item => item.name);
    if (results.length) return results;
    const pairs = Array.from(doc.querySelectorAll('*')).filter(node => node.children.length === 0).map(node => [node.localName || node.tagName, clean(node.textContent)]);
    const one = mapPairs(pairs); return one.name ? [one] : [];
  }
  function identityKey(item) {
    const id = normalizeKey(item.clientId), no = normalizeKey(item.caseNo);
    return id ? `id:${id}` : (no ? `no:${no}` : `person:${normalizeKey(item.name)}:${normalizeKey(item.phone)}`);
  }
  function mergeImported(incoming) {
    let added = 0, updated = 0, unchanged = 0;
    incoming.forEach(source => {
      const at = roster.findIndex(existing => {
        if (source.clientId && existing.clientId) return normalizeKey(source.clientId) === normalizeKey(existing.clientId);
        if (source.caseNo && existing.caseNo) return normalizeKey(source.caseNo) === normalizeKey(existing.caseNo);
        return normalizeKey(existing.name) === normalizeKey(source.name) && (!existing.phone || !source.phone || normalizeKey(existing.phone) === normalizeKey(source.phone));
      });
      if (at < 0) { roster.unshift({ id:`case-${Date.now()}-${Math.random().toString(36).slice(2,8)}`, ...source }); added++; return; }
      const previous = roster[at], merged = { ...previous };
      Object.entries(source).forEach(([key, value]) => { if (clean(value) && clean(value) !== clean(previous[key])) merged[key] = value; });
      if (Object.keys(merged).some(key => merged[key] !== previous[key])) { roster[at] = merged; updated++; } else unchanged++;
    });
    try { localStorage.setItem(ROSTER_KEY, JSON.stringify(roster)); }
    catch (_) { throw new Error('本機儲存空間不足，名冊未能保存。'); }
    return { added, updated, unchanged };
  }
  function readActivities() { try { const value=JSON.parse(localStorage.getItem(ACTIVITY_KEY)||'[]'); return Array.isArray(value)?value:[]; } catch (_) { return []; } }
  const RECORDS_KEY='yhn_workstation_visit_records_v1';
  function readVisitRecords(){try{const rows=JSON.parse(localStorage.getItem(RECORDS_KEY)||'[]');return Array.isArray(rows)?rows:[]}catch(_){return []}}
  const formInfo=kind=>kind==='家訪'?{root:'visitTool',select:'homeVisitHistorySelect',load:'homeVisitLoadHistory',preview:'homeVisitHistoryPreview',status:'homeVisitHistoryStatus',name:'homeClientName',date:'homeVisitDate',caseNo:'homeCaseNo',clientId:'homeClientId'}:{root:'phoneAssistTool',select:'phoneVisitHistorySelect',load:'phoneVisitLoadHistory',preview:'phoneVisitHistoryPreview',status:'phoneVisitHistoryStatus',name:'phoneClientName',date:'phoneCallDate',caseNo:'phoneCaseNo',clientId:'phoneClientId'};
  function currentIdentity(kind){const f=formInfo(kind),name=clean($(f.name)?.value),caseNo=clean($(f.caseNo)?.value),clientId=clean($(f.clientId)?.value);const client=roster.find(item=>(clientId&&item.clientId===clientId)||(caseNo&&item.caseNo===caseNo)||(name&&item.name===name));return {name,caseNo,clientId,rosterId:client?.id||''}}
  function identityMatches(row,identity){if(identity.rosterId&&row.rosterId)return row.rosterId===identity.rosterId;if(identity.clientId&&row.clientId)return row.clientId===identity.clientId;if(identity.caseNo&&row.caseNo)return row.caseNo===identity.caseNo;return !!identity.name&&row.name===identity.name}
  function refreshVisitHistory(kind){const f=formInfo(kind),select=$(f.select),preview=$(f.preview),load=$(f.load);if(!select)return;const identity=currentIdentity(kind),records=readVisitRecords().filter(row=>row.kind===kind&&identityMatches(row,identity)).sort((a,b)=>String(b.date).localeCompare(String(a.date))||b.savedAt-a.savedAt),legacy=readActivities().filter(row=>row.kind===kind&&identityMatches(row,identity)&&!records.some(record=>record.date===row.date));const selected=select.value;select.innerHTML='<option value="">選擇過往紀錄</option>'+records.map((row,i)=>`<option value="saved:${esc(row.id)}">${esc(row.date)}｜${esc(row.name)}｜完整紀錄</option>`).join('')+legacy.map((row,i)=>`<option value="legacy:${i}">${esc(row.date)}｜${esc(row.name)}｜僅日期</option>`).join('');if(Array.from(select.options).some(option=>option.value===selected))select.value=selected;const choice=select.value;load.disabled=!choice;if(!choice){preview.textContent='選取紀錄後會顯示上次內容。';return}const record=choice.startsWith('saved:')?records.find(row=>row.id===choice.slice(6)):legacy[Number(choice.slice(7))];preview.textContent=record?(record.content||'本機僅存有該次紀錄日期，沒有可帶入的紀錄內容。'):'找不到這筆紀錄。';}
  function saveVisitRecord(kind,content){const f=formInfo(kind),identity=currentIdentity(kind);if(!identity.name)return false;const root=$(f.root),fields=Array.from(root.querySelectorAll('input[id],select[id],textarea[id]')).map(el=>({id:el.id,value:el.value,checked:el.type==='checkbox'?el.checked:undefined}));const record={id:`${kind}-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,kind,date:$(f.date)?.value||'',...identity,content:String(content||''),fields,savedAt:Date.now()};const rows=readVisitRecords(),key=`${kind}|${record.date}|${identity.clientId||identity.caseNo||identity.rosterId||identity.name}`;const at=rows.findIndex(row=>row.key===key);record.key=key;if(at>=0)rows[at]=record;else rows.push(record);try{localStorage.setItem(RECORDS_KEY,JSON.stringify(rows.slice(-300)));refreshVisitHistory(kind);return true}catch(_){const status=$(f.status);if(status)status.textContent='紀錄已產生，但本機儲存空間不足，無法保存完整歷程。';return false}}
  function loadVisitRecord(kind){const f=formInfo(kind),select=$(f.select),status=$(f.status),choice=select?.value;if(!choice)return;const identity=currentIdentity(kind);if(choice.startsWith('legacy:')){const row=readActivities().filter(item=>item.kind===kind&&identityMatches(item,identity))[Number(choice.slice(7))];if(row){$(f.name).value=row.name||'';$(f.date).value=row.date||'';$(f.caseNo).value=row.caseNo||'';$(f.clientId).value=row.clientId||'';status.textContent='已帶入姓名與日期；這筆舊紀錄原本只保存日期，沒有保存內文。'}return}const record=readVisitRecords().find(row=>row.id===choice.slice(6));if(!record)return;for(const item of record.fields||[]){const el=$(item.id);if(!el)continue;if(el.type==='checkbox')el.checked=!!item.checked;else el.value=item.value??'';el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));}status.textContent='已帶入完整紀錄欄位，可修改後重新產生。';}
  function recordGeneratedActivity(kind) {
    const date = $(kind === '家訪' ? 'homeVisitDate' : 'phoneCallDate')?.value || '';
    const name = clean($(kind === '家訪' ? 'homeClientName' : 'phoneClientName')?.value);
    if (!date || !name) return;
    const caseNo = clean($(kind === '家訪' ? 'homeCaseNo' : 'phoneCaseNo')?.value);
    const clientId = clean($(kind === '家訪' ? 'homeClientId' : 'phoneClientId')?.value);
    const client = roster.find(item => (clientId && item.clientId === clientId) || (caseNo && item.caseNo === caseNo) || item.name === name) || {};
    const rows = readActivities(), key = `${kind}|${date}|${clientId || caseNo || name}`;
    if (!rows.some(row => row.key === key)) {
      rows.push({ key, kind, date, name, caseNo, clientId, type:client.type || '', status:client.status || '', serviceStart:client.serviceStart || '', supervisor:clean($('caseReportSupervisor')?.value) || client.supervisor || '' });
      try { localStorage.setItem(ACTIVITY_KEY, JSON.stringify(rows)); } catch (_) {}
    }
    const reminder = window.yhnCaseReminders?.recordActivity({ kind, date, client: { ...client, name, caseNo, clientId } });
    if (reminder?.ok && !reminder.skipped) window.dispatchEvent(new CustomEvent('yhn:case-reminder-created', { detail:reminder }));
  }
  function exportWorkbook(title, headers, rows, filename) {
    if (!window.XLSX) { $('caseReportStatus').textContent='Excel 匯出套件尚未載入，請重新整理後再試。'; return; }
    const data = [[title], headers, ...rows];
    const sheet = XLSX.utils.aoa_to_sheet(data);
    sheet['!merges'] = [{ s:{r:0,c:0}, e:{r:0,c:Math.max(0,headers.length-1)} }];
    sheet['!cols'] = headers.map((header, i) => ({ wch: i === 1 ? 16 : (header.length > 5 ? 14 : 10) }));
    sheet['!autofilter'] = { ref:`A2:${XLSX.utils.encode_col(headers.length-1)}${Math.max(2,rows.length+2)}` };
    const book = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(book, sheet, '清冊');
    XLSX.writeFile(book, filename, { bookType:'xlsx', compression:true });
    $('caseReportStatus').textContent = `已匯出 ${filename}；來源為此裝置名冊與已生成的家訪／電訪日期。`;
  }
  function reportRows(year) {
    const records = readActivities().filter(row => String(row.date || '').slice(0,4) === String(year));
    return { records, count:(client, month, kind) => records.filter(row => (row.clientId && row.clientId === client.clientId || row.caseNo && row.caseNo === client.caseNo || row.name === client.name) && Number(row.date.slice(5,7)) === month && (!kind || row.kind === kind)).length };
  }
  function initReports() {
    const yearField=$('caseReportYear'), supervisorField=$('caseReportSupervisor'), monthField=$('caseReportMonth');
    if (!yearField) return;
    const now = new Date(); yearField.value = String(now.getFullYear() - 1911);
    for (let month=1; month<=12; month++) monthField.add(new Option(`${month}月`,String(month).padStart(2,'0')));
    const exportSummary = period => {
      const year=Number(yearField.value), gregYear=year<1911?year+1911:year, {count}=reportRows(gregYear), months=Array.from({length:9},(_,i)=>i+1);
      const heads=['主責督導','個案姓名','類型','目前狀態','服務開始',...months.map(m=>`${m}月`),...(period?['1–9月家訪次數','1–9月電訪次數']:[])];
      const rows=roster.map(client=>[client.supervisor||clean(supervisorField.value),client.name,client.type||'',client.status||'',client.serviceStart||'',...months.map(m=>count(client,m)?'✓':''),...(period?[months.reduce((sum,m)=>sum+count(client,m,'家訪'),0),months.reduce((sum,m)=>sum+count(client,m,'電訪'),0)]:[])]);
      exportWorkbook(`永護寧｜${year}年家訪／電訪個別個案${period?'期間':''}清冊`,heads,rows,`${year}年家訪電訪個案${period?'期間':''}清冊.xlsx`);
    };
    $('exportCaseRosterSimple').addEventListener('click',()=>exportSummary(false));
    $('exportCaseRosterPeriod').addEventListener('click',()=>exportSummary(true));
    $('exportCaseMonthlyList').addEventListener('click',()=>{
      const year=String(Number(yearField.value)), gregYear=String(Number(year)<1911?Number(year)+1911:Number(year)), chosenMonth=monthField.value, kind=$('caseReportType').value;
      const {records}=reportRows(gregYear), selectedRows=records.filter(row=>(chosenMonth==='all'||row.date.slice(5,7)===chosenMonth)&&(kind==='all'||row.kind===kind));
      const activityRows=selectedRows.length?selectedRows.map(row=>[`${Number(row.date.slice(5,7))}月`,row.kind,row.supervisor||clean(supervisorField.value),row.name,row.type||'',row.status||'',row.serviceStart||'']):[];
      exportWorkbook(`${year}年家訪／電訪｜月別個案清單`,['月份','訪視類型','主責督導','個案姓名','個案類型','目前狀態','服務開始'],activityRows,`${year}年家訪電訪月別個案清單.xlsx`);
    });
  }
  function closeDialog() { if(batchDrafts.size&&!window.confirm('仍有未儲存的個案編輯，確定關閉？'))return; const dialog = $('casePickerDialog'); if (dialog.open) dialog.close(); }
  document.addEventListener('DOMContentLoaded', () => {
    const dialog = $('casePickerDialog');
    if (!dialog) return;
    setSelectedCard();
    window.addEventListener('message',event=>{
      if(event.origin!==location.origin)return;
      const data=event.data||{},frames=[['visit17HomeFrame','家訪'],['visit17PhoneFrame','電訪']];
      const match=frames.map(([id,kind])=>({frame:$(id),kind})).find(x=>x.frame?.contentWindow===event.source);
      if(!match)return;
      if(data.type==='yhn-visit-ready')match.frame.contentWindow.postMessage({type:'yhn-visit-init',kind:match.kind,client:visitClientPayload()},location.origin);
      else if(data.type==='yhn-visit-open-picker')$('casePickerOpen')?.click();
      else if(data.type==='yhn-visit-close')$('toolModalClose')?.click();
      else if(data.type==='yhn-visit-save')match.frame.contentWindow.postMessage({type:'yhn-visit-save-result',...saveIframeVisit(data.payload)},location.origin);
    });
    window.addEventListener('yhn:case-roster-updated',()=>{roster=readRoster();setSelectedCard();renderList()});
    window.addEventListener('yhn:case-directory-select',event=>{const id=event.detail?.id;selected=roster.find(item=>item.id===id)||null;if(!selected)return;try{localStorage.setItem(SELECTED_KEY,selected.id)}catch(_){}setSelectedCard();applySelected(true);invalidateRecordPreviews()});
    initReports();
    window.recordYhnVisitActivity = recordGeneratedActivity;
    window.saveYhnVisitRecord=saveVisitRecord;
    [['家訪','homeClientName','homeCaseNo','homeClientId'],['電訪','phoneClientName','phoneCaseNo','phoneClientId']].forEach(([kind,...ids])=>{ids.forEach(id=>$(id)?.addEventListener('input',()=>refreshVisitHistory(kind)));refreshVisitHistory(kind);const f=formInfo(kind);$(f.select)?.addEventListener('change',()=>refreshVisitHistory(kind));$(f.load)?.addEventListener('click',()=>loadVisitRecord(kind));});
    $('casePickerOpen').addEventListener('click', () => { $('casePickerSearch').value = ''; renderList(); dialog.showModal(); $('casePickerSearch').focus(); });
    $('casePickerClose').addEventListener('click', closeDialog);
    dialog.addEventListener('click', event => { if (event.target === dialog) closeDialog(); });
    $('casePickerSearch').addEventListener('input', renderList);
    $('caseBatchAll').addEventListener('change',event=>{visibleCases().forEach(item=>event.target.checked?batchIds.add(item.id):batchIds.delete(item.id));renderList();});
    $('caseBatchClear').addEventListener('click',()=>{batchIds.clear();renderList();});
    $('caseBatchSave').addEventListener('click',saveBatch);
    $('caseBatchDelete').addEventListener('click',deleteBatch);
    $('casePickerList').addEventListener('change',event=>{
      const checkbox=event.target.closest('[data-batch-case]');if(!checkbox)return;
      checkbox.checked?batchIds.add(checkbox.dataset.batchCase):batchIds.delete(checkbox.dataset.batchCase);updateBatchControls();
    });
    $('casePickerList').addEventListener('input',event=>{
      const field=event.target.closest('[data-batch-edit]');if(!field)return;
      const id=field.dataset.batchEdit;batchDrafts.set(id,{...(batchDrafts.get(id)||{}),[field.dataset.field]:field.value.trim()});batchIds.add(id);
      const checkbox=field.closest('article').querySelector('[data-batch-case]');if(checkbox)checkbox.checked=true;
      field.closest('details').querySelector('summary').textContent='編輯個案資料（未儲存）';updateBatchControls();batchMessage('內容尚未儲存，編輯後請按「儲存已選個案」。');
    });
    dialog.addEventListener('cancel',event=>{event.preventDefault();closeDialog();});
    $('casePickerList').addEventListener('click', event => {
      const select = event.target.closest('[data-select-case]');
      const remove = event.target.closest('[data-delete-case]');
      if (select) {
        selected = roster.find(item => item.id === select.dataset.selectCase) || null;
        if (!selected) return;
        try { localStorage.setItem(SELECTED_KEY, selected.id); } catch (_) {}
        setSelectedCard(); applySelected(true); invalidateRecordPreviews(); closeDialog();
      } else if (remove) {
        const item = roster.find(entry => entry.id === remove.dataset.deleteCase);
        if (!item || !window.confirm(`從本機名冊移除「${item.name}」？`)) return;
        try {commitRoster(roster.filter(entry=>entry.id!==item.id),selected?.id===item.id?null:undefined);batchIds.delete(item.id);batchDrafts.delete(item.id);setSelectedCard();renderList();batchMessage('已從本機名冊刪除 1 筆。');}
        catch(error) {batchMessage(error.message,true);}
      }
    });
    $('caseAddForm').addEventListener('submit', event => {
      event.preventDefault();
      const item = {
        id: `case-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,
        name: $('caseAddName').value.trim(), phone: $('caseAddPhone').value.trim(),
        caseNo: $('caseAddCaseNo').value.trim(), clientId: $('caseAddId').value.trim(),
        type:$('caseAddType').value.trim(), status:$('caseAddStatus').value.trim(), serviceStart:$('caseAddServiceStart').value
      };
      if (!item.name) return;
      roster = [item, ...roster];
      try { localStorage.setItem(ROSTER_KEY, JSON.stringify(roster)); localStorage.setItem(SELECTED_KEY, item.id); }
      catch (_) { window.alert('目前裝置儲存空間不足，個案名冊未能保存。'); return; }
      selected = item; setSelectedCard(); applySelected(true); invalidateRecordPreviews(); $('caseAddForm').reset(); $('caseAddForm').closest('details').open = false; closeDialog();
      window.dispatchEvent(new CustomEvent('yhn:case-roster-updated',{detail:{count:roster.length}}));
    });
    $('caseRosterImportFiles')?.addEventListener('change', async event => {
      const files=Array.from(event.target.files||[]), status=$('caseRosterImportStatus');
      if(!files.length)return;
      status.textContent='正在讀取檔案…';
      try {
        let all=[];
        for(const file of files){
          const ext=file.name.split('.').pop().toLowerCase();
          const text=ext==='xlsx'?'':await file.text();
          const rows=ext==='xlsx'?parseXlsx(await file.arrayBuffer()):ext==='html'||ext==='htm'?parseHtml(text):ext==='xml'?parseXml(text):parseDelimited(text);
          if(!rows.length)throw new Error(`${file.name} 找不到可辨識的姓名欄或個案資料。`);
          all=all.concat(rows);
        }
        const result=mergeImported(all);status.textContent=`匯入完成：新增 ${result.added} 筆、更新 ${result.updated} 筆、未變更 ${result.unchanged} 筆；原名冊均保留。`;
        setSelectedCard();renderList();window.dispatchEvent(new CustomEvent('yhn:case-roster-updated',{detail:{count:roster.length}}));
      } catch(error){status.textContent=`匯入未完成：${error.message||'檔案格式無法讀取。'}`;}
      finally{event.target.value='';}
    });
    document.addEventListener('click', event => {
      if (!event.target.closest('[data-open-tool]')) return;
      setTimeout(() => applySelected(false), 0);
    });
  });
})();
