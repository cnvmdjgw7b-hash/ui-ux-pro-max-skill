function serviceOptionHtml(){
  return serviceData.map(s=>`<option value="${s.code}">${s.code} ${s.name}｜${money(s.price)}元/${s.unit}</option>`).join('');
}

function renderServices(filter=''){
  if(!$('serviceList')) return;
  const q = filter.trim().toLowerCase();
  const list = serviceData.filter(s=>[s.code,s.name,s.category,s.desc,s.note,s.tip || ''].join(' ').toLowerCase().includes(q));
  $('serviceList').innerHTML = list.map(s=>`
    <article class="service-card">
      <h3>${s.code}｜${s.name}</h3>
      <div class="tag-row"><span class="tag">${s.category}</span><span class="tag">${money(s.price)}元／${s.unit}</span></div>
      <div class="mini-table">
        <div class="mini-cell"><span>第一類</span><strong>${money(s.selfPayFirst)}</strong></div>
        <div class="mini-cell"><span>第二類</span><strong>${money(s.selfPaySecond)}</strong></div>
        <div class="mini-cell"><span>第三類</span><strong>${money(s.selfPayThird)}</strong></div>
      </div>
      <button class="service-card-open" type="button" aria-label="查看 ${s.code} ${s.name} 詳細說明">查看服務說明　⌕</button>
      <div class="service-card-details">
        <p><strong>支付基準摘要：</strong>${s.desc}</p>
        <p><strong>注意事項：</strong>${s.note}</p>
        ${s.tip ? `<div class="supervisor-tip"><strong>☕ 居督碎碎唸：</strong><span>${s.tip}</span></div>` : ''}
        <p><strong>服務計畫：</strong>${s.plan}</p>
      </div>
    </article>
  `).join('') || '<p class="card">查無符合的碼別。</p>';
}

let servicePreviewReturnFocus=null;
function openServicePreview(card){
  const modal=$('servicePreviewModal'),body=$('servicePreviewBody');
  if(!modal||!body||!card)return;
  const preview=card.cloneNode(true);
  servicePreviewReturnFocus=card.querySelector('.service-card-open');
  preview.classList.add('service-preview-card');
  preview.querySelector('.service-card-open')?.remove();
  modal.querySelector('.service-preview-header strong').textContent=card.querySelector('h3')?.textContent||'服務碼別詳細說明';
  body.replaceChildren(preview);
  modal.classList.remove('is-page');
  modal.hidden=false;
  document.body.classList.add('service-preview-open');
  $('servicePreviewEnter')?.focus();
}
function closeServicePreview(){
  const modal=$('servicePreviewModal');if(!modal||modal.hidden)return;
  modal.hidden=true;modal.classList.remove('is-page');document.body.classList.remove('service-preview-open');
  servicePreviewReturnFocus?.focus({preventScroll:true});servicePreviewReturnFocus=null;
}

function initCodeTool(){
  renderServices();
  const search = $('serviceSearch');
  if(search) search.addEventListener('input', e=>renderServices(e.target.value));
  const list=$('serviceList');
  list?.addEventListener('click',event=>{const button=event.target.closest('.service-card-open');if(button)openServicePreview(button.closest('.service-card'))});
  const modal=$('servicePreviewModal');
  modal?.addEventListener('click',event=>{if(event.target===modal||event.target.closest('[data-service-preview-close]'))closeServicePreview()});
  $('servicePreviewEnter')?.addEventListener('click',()=>{modal?.classList.add('is-page');$('servicePreviewBody')?.scrollTo({top:0});$('servicePreviewBack')?.focus()});
  $('servicePreviewBack')?.addEventListener('click',()=>{modal?.classList.remove('is-page');$('servicePreviewEnter')?.focus()});
  document.addEventListener('keydown',event=>{if(event.key==='Escape')closeServicePreview()});
}


