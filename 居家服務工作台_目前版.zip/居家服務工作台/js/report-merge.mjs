// Pure merge policy shared with the future authenticated transaction endpoint.
// Never accept arbitrary workbook keys as database columns.
export const sourceFields = Object.freeze(['recordType','caseNumber','personName','supervisor','sourceOrReporter','serviceTarget','noticeType','receivedDate','responseDate','responseStatus','currentStatus','subject','reportProcessing','reportAdminNote','reportFixCompleted','reportFollowup','reportSupplementary','details','submittedDate','adminReview','managerReview']);
const blank = value => value == null || typeof value === 'string' && !value.trim();
const same = (a,b) => (a ?? '') === (b ?? '');
export function mergeReportFields(current, previousSource, incoming) {
  const patch = {}, conflicts = [], sourceValues = {};
  for (const key of sourceFields) {
    if (!Object.hasOwn(incoming,key)) continue;
    const next = incoming[key];
    if (!blank(next) && typeof next !== 'string') throw new Error('報表欄位格式錯誤：'+key);
    sourceValues[key] = next;
    if (blank(next) || same(current[key],next)) continue;
    const previouslyImported = previousSource && Object.hasOwn(previousSource,key);
    if (blank(current[key]) || previouslyImported && same(current[key],previousSource[key])) patch[key] = next;
    else conflicts.push({field:key, current:current[key], incoming:next});
  }
  return {patch, conflicts, sourceValues, changed:Object.keys(patch).length>0};
}
