/* Case-scoped, deterministic draft linkage. No network, AI or automatic task creation. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.YhnCarePlanLinkage=api})(typeof window==='object'?window:globalThis,function(){
'use strict';
const clone=x=>JSON.parse(JSON.stringify(x||{}));
function iso(value){
 let text=String(value||'').trim();if(/^\d{7,8}$/.test(text)){const n=text.length-4;text=text.slice(0,n)+'/'+text.slice(n,n+2)+'/'+text.slice(n+2)}
 const m=text.match(/^(\d{3,4})[年/.-](\d{1,2})[月/.-](\d{1,2})日?$/);if(!m)return '';
 let y=+m[1];if(y<1911)y+=1911;const d=new Date(Date.UTC(y,+m[2]-1,+m[3]));
 return d.getUTCFullYear()===y&&d.getUTCMonth()===+m[2]-1&&d.getUTCDate()===+m[3]?d.toISOString().slice(0,10):'';
}
function nextReview(value){const s=iso(value);if(!s)return '';const [y,m,d]=s.split('-').map(Number),last=new Date(Date.UTC(y,m+3,0)).getUTCDate();return new Date(Date.UTC(y,m+2,Math.min(d,last))).toISOString().slice(0,10)}
function reviewProblem(fields){const f=fields||{},base=iso(f.rbPlanAssessmentDate)||iso(f.rbPlanEffectiveDate),next=iso(f.rbPlanNextAssessmentDate);if(!base)return '';if(!next)return '請填寫下次複評日期。';if(next<=base||next>nextReview(base))return '下次複評日期須晚於評估日，且不得超過 '+nextReview(base)+'。';return ''}
function key(person){return person?.id?'id:'+person.id:person?.caseNo?'no:'+person.caseNo:person?.name?'name:'+person.name:''}
function seedCase(data,person){const d=clone(data);d.fields=d.fields||{};d.fields.cpName=person.name||d.fields.cpName||'';if(!d.fields.rbPlanOpenDate)d.fields.rbPlanOpenDate=iso(person.openDate||person.serviceStart);if(!d.fields.rbPlanGender&&person.gender)d.fields.rbPlanGender=person.gender;d.caseIdentity={...person};return d}
function matches(a,b){if(!a||!b)return false;if(a.caseNo&&b.caseNo)return a.caseNo===b.caseNo;if(a.id&&b.id)return a.id===b.id;return !!a.name&&a.name===b.name}
function join(a,b){const x=String(a||'').trim(),y=String(b||'').trim();return !y||x.includes(y)?x:[x,y].filter(Boolean).join('\n')}
function add(data,target,text,source){
 if(!text)return;const f=data.fields||(data.fields={}),links=data.linkage||(data.linkage={}),old=links[source];
 if(old?.text===text)return;
 if(old&&String(f[target]||'').includes(old.text))f[target]=String(f[target]).replace(old.text,text);
 else if(old){(data.linkageWarnings||(data.linkageWarnings=[])).push('已人工調整的來源內容未被覆蓋：'+source);return;}
 else f[target]=join(f[target],text);
 links[source]={target,text};
}
const legacyText={cpHealthNote:'rbPlanDisabilityCause',planNeeds:'rbPlanDisabilityCause',planStrengths:'rbPlanDisabilityCause',yhnPlanAssessment:'rbPlanDisabilityCause',cpFamilyNote:'rbPlanFamilySupport',cpEnvNote:'rbPlanFamilySupport',cpCare:'rbPlanExecution',cpTransport:'rbPlanExecution',cpAssist:'rbPlanExecution',cpRespite:'rbPlanExecution',cpResource:'rbPlanExecution',planServices:'rbPlanExecution',yhnPlanServices:'rbPlanExecution',yhnPlanSchedule:'rbPlanExecution',cpGap:'rbPlanModificationContent',planRisks:'rbPlanModificationContent',planReview:'rbPlanModificationContent',yhnPlanRisk:'rbPlanModificationContent',yhnPlanReview:'rbPlanModificationContent'};
const selectionTargets={diseases:'rbPlanDisabilityCause',cognition:'rbPlanPhysical',mobility:'rbPlanPhysical',eating:'rbPlanPhysical',toileting:'rbPlanPhysical',family:'rbPlanFamilySupport',env:'rbPlanFamilySupport',problems:'rbPlanModificationContent'};
const selectionLabels={diseases:'疾病／特殊狀況',cognition:'意識、認知與情緒',mobility:'行動與移位',eating:'進食與營養',toileting:'排泄照護',family:'家庭與照顧者',env:'環境與輔具',problems:'照顧問題'};
function legacyMerge(data,legacy={}){
 const d=clone(data);d.legacyFields={...d.legacyFields,...legacy};
 for(const [id,target]of Object.entries(legacyText))add(d,target,legacy[id],'legacy:'+id);
 if(!d.fields?.rbPlanEffectiveDate){d.fields=d.fields||{};d.fields.rbPlanEffectiveDate=iso(legacy.yhnPlanDate)||iso(legacy.planDate)}
 return d;
}
function selectionMerge(data,selections){
 const d=clone(data),apply=(source,target,label,values)=>{const text=(values||[]).filter(Boolean).join('、');if(text)add(d,target,label+'：'+text,source);else{const old=d.linkage?.[source];if(old&&String(d.fields?.[old.target]||'').includes(old.text)){d.fields[old.target]=d.fields[old.target].replace(old.text,'').trim();delete d.linkage[source]}}};
 for(const [group,values]of Object.entries(selections||{})){
  if(group==='cognition'){const emotional=x=>/情緒|抗拒|安撫|困擾|攻擊/.test(x);apply('selection:cognition:physical','rbPlanPhysical','意識與認知',(values||[]).filter(x=>!emotional(x)));apply('selection:cognition:psychological','rbPlanPsychological','情緒與心理',(values||[]).filter(emotional));}
  else apply('selection:'+group,selectionTargets[group],selectionLabels[group],values);
 }
 return d;
}
function visitMerge(data,visit,person){
 const d=clone(data);if(!visit||!matches(visit,person))return {data:d,applied:false};
 if(!['physical','psychological','family','environment','familyResponse','economy','healthNote','execution','treatment','followup'].some(k=>String(visit[k]||'').trim())&&!visit.services?.length)return {data:d,applied:false};
 const prefix=visit.date?'家訪 '+visit.date+'：':'家訪：',f=d.fields||(d.fields={});
 const source={rbPlanPhysical:visit.physical,rbPlanPsychological:visit.psychological,rbPlanFamilySupport:[visit.family,visit.environment,visit.familyResponse].filter(Boolean).join('\n'),rbPlanEconomy:visit.economy,rbPlanDisabilityCause:visit.healthNote,rbPlanExecution:visit.execution,rbPlanModificationContent:[visit.treatment,visit.followup].filter(Boolean).join('\n')};
 for(const [id,value]of Object.entries(source))if(value)add(d,id,prefix+'\n'+value,'visit:'+id);
 if(!f.rbPlanAssessmentDate&&visit.date)f.rbPlanAssessmentDate=iso(visit.date);
 d.visitSource={name:visit.name,caseNo:visit.caseNo||'',date:visit.date||''};
 return {data:d,applied:true};
}
function codeOf(text){return String(text||'').match(/(?:BA|GA|SC|AA|EB)\d{2}(?:-\d+|[a-z]\d*)?/i)?.[0].toUpperCase()||''}
function codesOf(text){return (String(text||'').match(/(?:BA|GA|SC|AA|EB)\d{2}(?:-\d+|[a-z]\d*)?/gi)||[]).map(x=>x.toUpperCase())}
function continueServices(data,services,catalog=[]){
 const d=clone(data);d.caregivers=d.caregivers||[];while(d.caregivers.length<2)d.caregivers.push({name:'',frequency:'',rows:[]});
 for(let i=0;i<2;i++){const c=d.caregivers[i];c.rows=c.rows||[];while(c.rows.length<(i?1:2))c.rows.push(['','','','']);}
 const slots=d.caregivers.flatMap(c=>c.rows.flatMap(r=>[{r,index:0},{r,index:2}])),existing=new Set(slots.flatMap(s=>codesOf(s.r[s.index])));
 const pending=[];
 for(const service of services||[]){const code=codeOf(service.code||service.name);if(!code||existing.has(code))continue;const slot=slots.find(s=>!String(s.r[s.index]||'').trim());if(!slot){pending.push(service);continue;}const displayCode=catalog.find(x=>String(x.code).toUpperCase()===code)?.code||service.code||code;slot.r[slot.index]=[displayCode,service.name].filter(Boolean).join(' ');slot.r[slot.index+1]=service.units??'';existing.add(code)}
 d.evaluations=d.evaluations||[];while(d.evaluations.length<4)d.evaluations.push(['','','','','']);
 const all=new Map();for(const s of slots)for(const code of codesOf(s.r[s.index]))if(!all.has(code))all.set(code,String(s.r[s.index]));
 const unmatched=[];
 for(const [code,label]of all){let row=d.evaluations.find(r=>codesOf(r[0]).includes(code));if(!row)row=d.evaluations.find(r=>!r.some(v=>String(v||'').trim()));if(!row){unmatched.push(label);continue;}
  if(!row[0])row[0]=label;const item=catalog.find(x=>String(x.code).toUpperCase()===code)||catalog.find(x=>code.startsWith(String(x.code).toUpperCase()+'-')&&label.includes(x.name));
  if(item){if(!row[1])row[1]=item.goal||'';if(!row[2])row[2]=item.plan||'';}
  // An outcome is never inferred from a catalog goal or from a completed upload.
 }
 d.pendingServiceItems=pending.map(x=>[x.code,x.name].filter(Boolean).join(' '));d.pendingEvaluationItems=unmatched;
 return d;
}
function visitEvaluations(data,visit){
 const d=clone(data),text=[visit.execution?'整體服務觀察：'+visit.execution:'',visit.familyResponse?'家屬整體回應：'+visit.familyResponse:''].filter(Boolean).join('\n');if(!text)return d;
 const codes=new Set((visit.services||[]).map(x=>codeOf(x.code))),source=(visit.date?'家訪 '+visit.date+'\n':'家訪\n')+text;
 const previous=d.evaluationSources||{};
 for(const r of d.evaluations||[]){const code=codeOf(r[0]);if(!codes.has(code))continue;if(!r[3])r[3]=source;else if(previous[code]&&r[3]===previous[code])r[3]=source;else continue;previous[code]=source;}
 d.evaluationSources=previous;return d;
}
return {iso,nextReview,reviewProblem,key,seedCase,matches,join,add,legacyText,selectionTargets,selectionLabels,legacyMerge,selectionMerge,visitMerge,continueServices,visitEvaluations,codeOf};
});
