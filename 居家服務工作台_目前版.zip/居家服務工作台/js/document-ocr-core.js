/* Independent document parser. No network, Floot, DOM or storage dependencies. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.YhnDocumentParser=api})(typeof window==='object'?window:globalThis,function(){
'use strict';
const TYPES=['照會單','異動通報','電話訪視紀錄','個別督導紀錄','照護計畫','居服員查核表','異常事件報告','緊急申請單'];
const RENBAO=typeof module==='object'&&module.exports?require('./care-plan-renbao.js'):window.YhnRenbaoCarePlan;
const TITLES=[/照會單|服務照會通知|照會通知單/,/異動通報|服務異動通知/,/電話訪視紀錄|電訪紀錄|電話訪視表|電話紀錄表|電話記錄表/,/個別督導紀錄|個別督導表/,/照護計[畫劃]|照顧計[畫劃]/,/居服員查核表|居家服務員查核表/,/異常事件報告|服務異常事件報告/,/緊急申請單|緊急服務申請/];
const COMMON={personName:['個案姓名','個霧姓名','個案姓各','案主姓名'],caseNumber:['衛福部案號','個案案號','案號'],supervisor:['主責督導','督導姓名','督導'],reportProcessing:['處理情形','處理內容'],reportAdminNote:['行政備註'],reportSupplementary:['其他說明','補充說明','補充'],details:['必要補充','備註內容','備註'],reportFixCompleted:['修正完成'],reportFollowup:['後續追蹤','後續事項'],submittedDate:['回交日期','送件日期','繳交日'],completionNote:['完成備註']};
const MAPS={
 '照會單':{...COMMON,receivedDate:['照會日期','照曾日期'],responseDate:['回覆日期'],responseStatus:['回覆結果','回覆情形'],currentStatus:['目前狀態','服務現況','現況'],subject:['照會項目','照會項日','服務碼及服務內容','服務內容'],sourceOrReporter:['照會來源']},
 '異動通報':{...COMMON,caseNumber:['個案編號','案號'],receivedDate:['通報日期'],noticeType:['通報類型','異動類型','異動通報類型'],subject:['通報主旨'],serviceTarget:['通報目標','通報對象','通報照管中心','同時通報單位'],sourceOrReporter:['通報人員','通報人'],details:['備註','通報內容','異動說明','異動原因'],reportSupplementary:['異動發生日','異動生效日期']},
 '電話訪視紀錄':{phoneClientName:['個案姓名','案主姓名'],phoneCaseNo:['衛福部案號','案號'],phoneCallDate:['電訪日期','電話訪視日期'],phoneClientPhone:['個案電話'],phoneClientId:['身分證／統一編號','身分證字號','統一編號'],phoneRecipient:['電訪對象']},
 '照護計畫':{...RENBAO.scalarMap},
 '異常事件報告':{incidentName:['個案姓名','事發人員姓名'],incidentDate:['事發日','事件日期'],incidentReportDate:['填表日'],incidentGender:['性別'],incidentLocation:['事故地點'],incidentReporter:['填表人'],actualHandling:['實際已完成處置','實際處理情形']},
 // These are extraction labels only, NOT invented website form keys.
 '個別督導紀錄':{姓名:['受督導者'],日期:['督導日期'],督導者:['督導者'],內容:['討論與指導內容'],追蹤:['處理決議','追蹤事項']},
 '居服員查核表':{姓名:['居服員姓名'],日期:['查核日期'],查核者:['查核者'],內容:['查核項目'],結果:['查核結果'],追蹤:['改善及追蹤']},
 '緊急申請單':{姓名:['個案姓名'],日期:['申請日期'],申請人:['申請人'],原因:['緊急原因'],事項:['申請事項'],聯絡方式:['聯絡方式']}
};
function uuid(){if(crypto.randomUUID)return crypto.randomUUID();const b=crypto.getRandomValues(new Uint8Array(16));b[6]=(b[6]&15)|64;b[8]=(b[8]&63)|128;const h=[...b].map(x=>x.toString(16).padStart(2,'0')).join('');return h.slice(0,8)+'-'+h.slice(8,12)+'-'+h.slice(12,16)+'-'+h.slice(16,20)+'-'+h.slice(20)}
const nativeTypes={'照會單':'照會','異動通報':'異動'};
const normalize=s=>String(s||'').normalize('NFKC').replace(/\r\n?/g,'\n').replace(/\u00a0/g,' ');
const compact=s=>normalize(s).replace(/\s+/g,'');
function classify(text){const t=compact(text);let matches=TYPES.filter((_,i)=>TITLES[i].test(t));
 // Some agency forms use a generic cover title. Require multiple table-specific labels before classifying.
 if(!matches.length&&/(居服員|居家服務員)/.test(t)&&/(查核項目|缺失說明)/.test(t)&&/(符合|不符合)/.test(t))matches=['居服員查核表'];
 const unsupported=/獎懲申請單|獎勵申請單|懲處申請單/.test(t);
 return {type:matches.length===1?matches[0]:null,candidates:matches,unsupported,archiveCategory:matches.length===1?matches[0]:unsupported?'其他文件｜獎懲申請單':'待人工分類',reason:matches.length===0?(unsupported?'辨識到未設定對應表單的文件；保留原圖，請勿填入其他表單':'找不到明確文件標題，請選擇類型'):matches.length>1?'同時出現多種文件標題，請人工確認':''}}
function dateValue(value){let s=normalize(value).trim().replace(/[（(][一二三四五六日天][）)]$/,'').trim();if(/^\d{7}$/.test(s))s=s.slice(0,3)+'/'+s.slice(3,5)+'/'+s.slice(5);const m=s.match(/^(?:民國\s*)?(\d{2,4})\s*[年/.-]\s*(\d{1,2})\s*[月/.-]\s*(\d{1,2})\s*日?$/);if(!m)return null;let y=+m[1];if(y<1911)y+=1911;const d=new Date(Date.UTC(y,+m[2]-1,+m[3]));return d.getUTCFullYear()===y&&d.getUTCMonth()===+m[2]-1&&d.getUTCDate()===+m[3]?`${y}-${m[2].padStart(2,'0')}-${m[3].padStart(2,'0')}`:null}
function escape(s){return s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}
// A printed timestamp is acceptable only after an explicit business date label.
function labelledDate(raw){
 const line=normalize(raw).split('\n')[0].trim();
 const stamped=line.match(/^(\d{2,4}[\/.-]\d{1,2}[\/.-]\d{1,2})[ T]*((?:[01]?\d|2[0-3]):[0-5]\d(?::[0-5]\d)?)(?=\s|$)/);
 return stamped?dateValue(stamped[1]):dateValue(line);
}
function extract(text,type){
 const t=normalize(text),map=MAPS[type]||{},aliases=Object.entries(map).flatMap(([key,labels])=>labels.map(label=>({key,label:normalize(label)}))).sort((a,b)=>b.label.length-a.label.length);
 const lookup=new Map(aliases.map(x=>[compact(x.label),x.key]));
 if(!aliases.length)return {fields:{},evidence:{},uncertain:[]};
 const boundaries=[...new Set(Object.values(MAPS).flatMap(m=>Object.values(m).flat()).concat(['目前照管中心','評估照專','列印日期','列印日','身分證字號','聯絡電話','服務提供單位','承辦人','地址','居服員','居服員2','居服員3','服務頻率及估計時間','服務項目','次數','問題與需求','照護服務執行計劃','評值','評值日期']).map(compact))].sort((a,b)=>b.length-a.length);
 const regex=new RegExp('(^|[\\n\\t|│ ]+|[一二三四五六][、.．][ \\t]*)('+boundaries.map(label=>[...label].map(escape).join('[ \\t]*')).join('|')+')(?:[ \\t]*[:：][ \\t]*|[ \\t]+|(?=\\n)|(?=\\d{2,4}[年/.-])|(?=\\d{1,2}[/-]\\d{1,2}))','g');
 const chapterTitles=new Set(RENBAO.sections.map(s=>compact(s.title)));let offset=0;const chapterStarts=[];for(const line of t.split('\n')){if(chapterTitles.has(compact(line)))chapterStarts.push(offset);offset+=line.length+1}const hits=[...t.matchAll(regex)],found={},evidence={},uncertain=[];
 for(let i=0;i<hits.length;i++){
  const hit=hits[i],key=lookup.get(compact(hit[2]));if(!key)continue;const begin=hit.index+hit[0].length,nextChapter=chapterStarts.find(at=>at>=begin);let raw=t.slice(begin,Math.min(i+1<hits.length?hits[i+1].index:t.length,nextChapter??t.length)).trim().replace(/^[|│]+|[|│]+$/g,'').trim();
  if(!raw||/^(待確認|不詳|無資料|未填|[_＿—-]+)$/.test(raw)){uncertain.push(key);continue}
  // A short scalar cannot consume a paragraph or a second unlabeled table cell.
  const short=/Name|Number|supervisor|Date|Status|Reporter|Target|Type|Phone|Id|Recipient|Gender|Time|姓名|日期|督導者|查核者|申請人/.test(key);
  if(short&&!/Date$|^日期$/.test(key)&&(raw.includes('\n')||raw.length>60)){uncertain.push(key);continue}
  if([['[',']'],['(',')'],['{','}'],['「','」'],['【','】']].some(([a,b])=>raw.split(a).length!==raw.split(b).length)){uncertain.push(key);continue}
  let value=raw;if(/personName|phoneClientName|cpName|incidentName|^姓名$/.test(key))value=raw.replace(/([\u3400-\u9fff]) +(?=[\u3400-\u9fff])/g,'$1');
  if(/Date$|^日期$/.test(key)){value=labelledDate(raw);if(!value){uncertain.push(key);continue}}
  if(/personName|phoneClientName|cpName|incidentName|^姓名$/.test(key)&&(!/^[\p{L}·．・\s]{1,30}$/u.test(raw))){uncertain.push(key);continue}
  if(/caseNumber|phoneCaseNo/.test(key)){value=raw.replace(/[（(][\u3400-\u9fff·．・\s]{1,20}[）)]$/,'').replace(/[ \t]/g,'');if(/^[A-Z][12]\d{8}$/.test(value)||!/^[A-Za-z0-9-]{1,50}$/.test(value)){uncertain.push(key);continue}}
  if(key==='phoneRecipient'&&!['案主','家屬'].includes(value)){uncertain.push(key);continue}
  if(Object.hasOwn(found,key)&&found[key]!==value){delete found[key];delete evidence[key];uncertain.push(key);continue}
  if(uncertain.includes(key))continue;
  found[key]=value;evidence[key]={label:hit[2],raw,start:hit.index,end:hit.index+hit[0].length+raw.length};
 }
 // Referral tables put the label in a vertically merged cell: service rows can precede it.
 // Use only literal, valid codes between the actual table heading and remarks boundary.
 if(type==='照會單'){
  const heading=/^[ \t|│]*項[ \t]*目[ \t|│]*$/m.exec(t);
  if(heading){const start=heading.index+heading[0].length,tail=t.slice(start),end=tail.search(/備[ \t]*註|備[ \t]*注|建[ \t]*檔[ \t]*日期|回[ \t]*覆[ \t]*情形/),area=tail.slice(0,end<0?tail.length:end),rows=area.split('\n').map(x=>x.trim()).filter(x=>/^(?:BA\d{2}(?:-\d+)?|GA\d{2}|SC\d{2}|AA\d{2}|EB\d{2})[ \t[（(]/.test(x));
   if(rows.length){found.subject=[...new Set(rows)].join('；');evidence.subject={label:'照會項目表格（依原列順序）',raw:area,start,end:start+area.length};const at=uncertain.indexOf('subject');if(at>=0)uncertain.splice(at,1)}
  }
 }
 if(type==='照護計畫'){
  const spaced=x=>[...x].map(escape).join('[ \\t]*');
  const caregiver=new RegExp(spaced('居服員')+'([23])?[ \\t]*[:：][ \\t]*([^\\n]*)','g'),blocks=[...t.matchAll(caregiver)];
  for(let i=0;i<blocks.length;i++){const m=blocks[i],idx=m[1]||'1',body=t.slice(m.index+m[0].length,blocks[i+1]?.index??t.length),name=m[2].trim().replace(/([\u3400-\u9fff]) +(?=[\u3400-\u9fff])/g,'$1');if(/^[\u3400-\u9fff·．・]{2,12}$/.test(name)){found['rbPlanCaregiver'+idx]=name;evidence['rbPlanCaregiver'+idx]={label:m[0],raw:m[2],start:m.index,end:m.index+m[0].length}}
   const freq=body.match(new RegExp(spaced('服務頻率及估計時間')+'[ \\t]*[:：][ \\t]*([^\\n]*)'));if(freq?.[1].trim())found['rbPlanFrequency'+idx]=freq[1].trim();
  }
  const signatures=[...t.matchAll(/督[ \t]*導[ \t]*[:：][ \t]*([\u3400-\u9fff·．・]{2,12})(?=\s|$)/g)];if(signatures.length===2)signatures.forEach((m,i)=>{found['rbPlanSupervisor'+(i+1)]=m[1];evidence['rbPlanSupervisor'+(i+1)]={label:'督導（依原欄位順序）',raw:m[1],start:m.index,end:m.index+m[0].length}});
  for(const [key,label]of [['rbPlanInitial','初評'],['rbPlanReassessment','複評']])if(new RegExp('[■☑✓][ \\t]*'+label).test(t))found[key]=true;
 }
 // Hospital referral header combines a name and a national ID. Never map the ID to caseNumber.
 if(nativeTypes[type]){
  const combined=/(?:個[ \t]*[案霧][ \t]*(?:姓[ \t]*[名各]|編[ \t]*號)|案[ \t]*號)[ \t]*\/[ \t]*([^\n:：]{1,18})[:：][ \t]*([\u3400-\u9fff·．・ \t]{2,30})[ \t]*\/[ \t]*([A-Z][12]\d{8})(?=\s|$)/g;
  for(const m of t.matchAll(combined)){
   if(!/[身證证]/.test(m[1]))continue;
   const value=m[2].replace(/[ \t]/g,'');if(!/^[\u3400-\u9fff·．・]{2,12}$/.test(value))continue;
   if((found.personName&&found.personName!==value)||uncertain.includes('personName')){delete found.personName;delete evidence.personName;uncertain.push('personName');continue}
   found.personName=value;evidence.personName={label:'個案姓名／身分證字號（只取姓名）',raw:m[2],start:m.index,end:m.index+m[0].length};
  }
  const combinedCaseIdentity=/(?:個[ \t]*案[ \t]*編[ \t]*號|案[ \t]*號)[ \t]*[／/][ \t]*身[ \t]*分[ \t]*證[ \t]*字[ \t]*號[ \t]*[:：]?[ \t]*([A-Z][12]\d{8})[ \t]*[（(]([\u3400-\u9fff·．・]{2,12})[）)]/g;
  for(const m of t.matchAll(combinedCaseIdentity)){const value=m[2];if((found.personName&&found.personName!==value)||uncertain.includes('personName')){delete found.personName;delete evidence.personName;uncertain.push('personName');continue}found.personName=value;evidence.personName={label:'個案編號／身分證字號（僅取括號內姓名）',raw:m[0],start:m.index,end:m.index+m[0].length}}
 }
 for(const key of (type==='照會單'||type==='異動通報'?['personName','receivedDate','subject']:[]))if(!Object.hasOwn(found,key))uncertain.push(key);
 return {fields:found,evidence,uncertain:[...new Set(uncertain)]};
}
function parse(text,selectedType){const detected=classify(text),manual=TYPES.includes(selectedType),type=manual?selectedType:detected.type,classification=manual?{...detected,type,unsupported:false,archiveCategory:type,manual:true}:detected;return {type,classification,...extract(text,type),nativeType:nativeTypes[type]||null}}
function linesFromTSV(tsv){
 const rows=String(tsv||'').split(/\r?\n/).slice(1).map(l=>l.split('\t')).filter(c=>c.length>=12&&+c[0]===5&&c.slice(11).join('\t').trim());
 const map=new Map();for(const c of rows){const id=c.slice(1,5).join(':');if(!map.has(id))map.set(id,[]);map.get(id).push({left:+c[6],top:+c[7],width:+c[8],height:+c[9],confidence:+c[10],text:c.slice(11).join('\t')})}
 // Keep engine block/paragraph order; reconstruct each line in x order and retain boxes.
 return [...map.values()].map(words=>{words.sort((a,b)=>a.left-b.left);return {text:words.map(x=>x.text).join(' '),words,bbox:{left:Math.min(...words.map(x=>x.left)),top:Math.min(...words.map(x=>x.top)),right:Math.max(...words.map(x=>x.left+x.width)),bottom:Math.max(...words.map(x=>x.top+x.height))}}});
}
function merge(pages){const fields={},evidence={},conflicts=new Set(),types=new Set(pages.map(x=>x.type).filter(Boolean));for(const p of pages)for(const [k,v]of Object.entries(p.fields)){if(Object.hasOwn(fields,k)&&fields[k]!==v)conflicts.add(k);else{fields[k]=v;evidence[k]=p.evidence[k]}}for(const k of conflicts){delete fields[k];delete evidence[k]}return {type:types.size===1?[...types][0]:null,fields,evidence,uncertain:[...conflicts],mixedTypes:types.size>1}}
function sameDocumentType(parsedPages,categories){return parsedPages.length>0&&parsedPages.length===categories.length&&parsedPages.every(p=>p.type&&!p.classification?.unsupported)&&new Set(parsedPages.map(p=>p.type)).size===1&&new Set(categories.filter(Boolean)).size===1&&categories.every(Boolean)}
function fill(form,parsed,{touched=new Set(),saved=false,previous={},onField=()=>{}}={}){
 const applied=[],skipped=[];if(!parsed.nativeType)return {applied,skipped,reason:'此類文件不是照會／異動，未套用'};
 const typeControl=form.elements.namedItem('recordType');if(!typeControl||typeControl.value!==parsed.nativeType)return {applied,skipped,reason:'請先在原表單確認文件類型，避免混填'};
 for(const key of ['personName','caseNumber']){const input=form.elements.namedItem(key),value=parsed.fields[key];if(input?.value&&value&&input.value!==value&&!(Object.hasOwn(previous,key)&&previous[key]===input.value&&!touched.has(key)))return {applied,skipped,reason:'照片與原表單的個案身分不同，未填入；請確認案件後再操作'};}
 for(const [key,value]of Object.entries(parsed.fields)){
  const input=form.elements.namedItem(key);if(!input||touched.has(key)||(String(input.value||'').trim()&&!(Object.hasOwn(previous,key)&&previous[key]===input.value))||saved){skipped.push(key);continue}
  if(input.tagName==='SELECT'&&![...input.options].some(x=>x.value===String(value))){skipped.push(key);continue}
  input.value=value;if(input.type==='date'&&input.value!==value){skipped.push(key);continue}onField(key,value);input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));applied.push(key);
 }
 return {applied,skipped,reason:''};
}
return {TYPES,MAPS,uuid,normalize,classify,dateValue,extract,parse,linesFromTSV,merge,sameDocumentType,fill};
});
