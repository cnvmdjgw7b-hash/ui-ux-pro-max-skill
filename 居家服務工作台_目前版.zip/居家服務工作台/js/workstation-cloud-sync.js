(()=>{'use strict';
  const KEYS=['yhn_director_workstation_v1','yhn_supervisor_daily_plans_v1','yhn_supervisor_habits_v1','yhn_workstation_case_roster_v1','yhn_workstation_selected_case_v1','yhn_workstation_visit_activity_v1','yhn_workstation_visit_records_v1','yhn_care_plan_generator_v1','yhn_care_plan_draft_v1'];
  const RAW_KEYS=new Set(['yhn_workstation_selected_case_v1']);
  const STATUS='yhn_workstation_cloud_sync_status_v1';let busy=false,timer=null;
  const setStatus=value=>{try{localStorage.setItem(STATUS,JSON.stringify({text:value,at:new Date().toISOString()}))}catch{}};
  const localData=()=>Object.fromEntries(KEYS.map(k=>[k,localStorage.getItem(k)]));
  const validateData=data=>{if(!data||typeof data!=='object'||Array.isArray(data))throw Error('同步資料格式異常，未套用雲端資料。');for(const key of KEYS){const raw=data[key];if(raw!==null&&raw!==undefined){if(typeof raw!=='string')throw Error('同步資料格式異常，未套用雲端資料。');if(!RAW_KEYS.has(key)){try{JSON.parse(raw)}catch{throw Error('本機或雲端資料格式異常，本次未同步。')}}}}return data};
  const parse=(raw,fallback)=>{try{return raw==null?fallback:JSON.parse(raw)}catch{return fallback}};
  const json=async(action,payload={})=>{const r=await fetch('/api/director',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({action,payload})});let out;try{out=await r.json()}catch{throw Error('雲端回應無法讀取。')}if(!r.ok||out.error)throw Object.assign(Error(out.error||'雲端同步失敗。'),{status:r.status});return out};
  const keyId=x=>String(x?.id||x?.caseNo||x?.caseNumber||x?.name||JSON.stringify(x));
  function mergeArray(localRaw,remoteRaw){const local=parse(localRaw,[]),remote=parse(remoteRaw,[]);if(!Array.isArray(local))return remoteRaw;if(!Array.isArray(remote))return localRaw;const out=new Map(remote.map(x=>[keyId(x),x]));for(const x of local){const id=keyId(x);out.set(id,{...(out.get(id)||{}),...x})}return JSON.stringify([...out.values()])}
  function mergePlans(localRaw,remoteRaw){const local=parse(localRaw,{}),remote=parse(remoteRaw,{});if(!local||typeof local!=='object'||Array.isArray(local))return remoteRaw;if(!remote||typeof remote!=='object'||Array.isArray(remote))return localRaw;const out={...remote};for(const [date,day]of Object.entries(local)){const other=out[date];if(!other){out[date]=day;continue}const tasks=new Map((Array.isArray(other.tasks)?other.tasks:[]).map(x=>[String(x.id||keyId(x)),x]));for(const task of Array.isArray(day?.tasks)?day.tasks:[]){const id=String(task.id||keyId(task));tasks.set(id,{...(tasks.get(id)||{}),...task})}out[date]={...other,...day,tasks:[...tasks.values()],focus:day.focus||other.focus||'',reflection:day.reflection||other.reflection||'',tomorrow:Array.from({length:3},(_,i)=>day.tomorrow?.[i]||other.tomorrow?.[i]||''),habitDone:[...new Set([...(other.habitDone||[]),...(day.habitDone||[])])]}}return JSON.stringify(out)}
  function mergeDirector(localRaw,remoteRaw){const local=parse(localRaw,{}),remote=parse(remoteRaw,{});if(!local||typeof local!=='object'||Array.isArray(local))return remoteRaw;if(!remote||typeof remote!=='object'||Array.isArray(remote))return localRaw;const deletedCases=[...new Set([...(remote._deletedCases||[]),...(local._deletedCases||[])].map(String))],deletedStaff=[...new Set([...(remote._deletedStaff||[]),...(local._deletedStaff||[])].map(String))],cases=JSON.parse(mergeArray(JSON.stringify(local.cases||[]),JSON.stringify(remote.cases||[]))).filter(x=>!deletedCases.includes(String(x.id))),staff=JSON.parse(mergeArray(JSON.stringify(local.staff||[]),JSON.stringify(remote.staff||[]))).filter(x=>!deletedStaff.includes(String(x.id)));return JSON.stringify({...remote,...local,cases,staff,_deletedCases:deletedCases,_deletedStaff:deletedStaff,kpi:{...(remote.kpi||{}),...(local.kpi||{})},monthNotes:{...(remote.monthNotes||{}),...(local.monthNotes||{})}})}
  function merge(local,remote){const out={...remote};for(const k of KEYS){const l=local[k],r=remote?.[k];if(k==='yhn_director_workstation_v1')out[k]=mergeDirector(l,r);else if(k==='yhn_supervisor_daily_plans_v1')out[k]=mergePlans(l,r);else if(['yhn_supervisor_habits_v1','yhn_workstation_case_roster_v1','yhn_workstation_visit_activity_v1','yhn_workstation_visit_records_v1'].includes(k))out[k]=mergeArray(l,r);else out[k]=l||r||null;}return out}
  function same(a,b){return JSON.stringify(a||{})===JSON.stringify(b||{})}
  function apply(data){for(const k of KEYS){const next=data?.[k]??null;if(next===null)localStorage.removeItem(k);else if(localStorage.getItem(k)!==next)localStorage.setItem(k,next)}}
  function hasData(data){return Object.values(data).some(raw=>{if(!raw)return false;const value=parse(raw,raw);return Array.isArray(value)?value.length>0:value&&typeof value==='object'?Object.keys(value).length>0:String(value).trim()!==''})}
  async function sync(){if(busy)return;busy=true;try{
    const auth=await fetch('/api/auth/status',{cache:'no-store',credentials:'same-origin'}).then(r=>r.json());if(!auth.authenticated){setStatus('登入後同步至此帳號的雲端工作區');return}
    for(let attempt=0;attempt<2;attempt++){
      const local=validateData(localData()),remote=await json('workstation-sync-read');if(remote.data)validateData(remote.data);const merged=merge(local,remote.data||{});
      if(!remote.data&&!hasData(merged)){setStatus('已登入；新增資料後會同步');return}
      let saved=remote;
      if(!same(merged,remote.data||{})){
        try{saved=await json('workstation-sync-write',{data:merged,expectedEtag:remote.etag??null})}
        catch(error){if(error.status===409&&attempt===0)continue;throw error}
      }
      apply(saved.data||merged);setStatus('跨裝置同步完成');return;
    }
    throw Error('其他裝置正在更新資料，請稍後再試。');
  }catch(error){setStatus(error.message||'雲端同步未完成；本機資料仍保留。')}finally{busy=false}}
  function schedule(){clearTimeout(timer);timer=setTimeout(sync,1500)}
  async function downloadBackup(){const out=await json('workstation-sync-read');const blob=new Blob([JSON.stringify({format:'yhn-workstation-cloud-backup',version:1,exportedAt:new Date().toISOString(),data:out.data||{}},null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='牛馬吃肉命工作站_雲端備份.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);setStatus('雲端備份已下載')}
  async function restoreLatest(){const list=await json('workstation-sync-history');if(!list.snapshots?.length){alert('目前沒有可還原的雲端歷史版本。');return}const lines=list.snapshots.map((x,i)=>`${i+1}. ${new Date(x.savedAt).toLocaleString('zh-TW')}`).join('\n');const answer=prompt('選擇要還原的版本編號：\n'+lines,'1');if(answer===null)return;const index=Number(answer)-1,snapshot=list.snapshots[index];if(!snapshot){alert('版本編號不正確。');return}if(!confirm(`要還原 ${new Date(snapshot.savedAt).toLocaleString('zh-TW')} 的工作台資料嗎？目前雲端資料會先保留成一份歷史版本。`))return;const out=await json('workstation-sync-restore',{snapshotId:snapshot.id,expectedEtag:list.etag??null});validateData(out.data);apply(out.data);setStatus('雲端資料已還原');}
  window.yhnWorkstationCloud={sync,downloadBackup,restoreLatest};
  const nativeSet=Storage.prototype.setItem,nativeRemove=Storage.prototype.removeItem;
  Storage.prototype.setItem=function(key,value){nativeSet.call(this,key,value);if(this===localStorage&&KEYS.includes(String(key)))schedule()};
  Storage.prototype.removeItem=function(key){nativeRemove.call(this,key);if(this===localStorage&&KEYS.includes(String(key)))schedule()};
  window.addEventListener('storage',e=>{if(KEYS.includes(e.key))schedule()});window.addEventListener('yhn:plans-updated',schedule);window.addEventListener('yhn:case-roster-updated',schedule);window.addEventListener('focus',schedule);document.addEventListener('visibilitychange',()=>{if(!document.hidden)schedule()});
  document.addEventListener('DOMContentLoaded',()=>{sync();setInterval(sync,30000)});
})();
