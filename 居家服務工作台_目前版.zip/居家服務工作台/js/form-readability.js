(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else{root.YhnFormContrast=api;document.addEventListener('DOMContentLoaded',api.apply);window.addEventListener('yhn-theme-change',api.apply)}})(typeof window==='object'?window:globalThis,function(){
'use strict';
function rgb(s){const h=String(s).trim().match(/^#([a-f\d]{6})$/i);if(h)return [0,2,4].map(i=>parseInt(h[1].slice(i,i+2),16));const m=String(s).match(/^rgba?\(\s*(\d+)[, ]+\s*(\d+)[, ]+\s*(\d+)/);return m?[+m[1],+m[2],+m[3]]:null}
function luminance(color){const r=rgb(color);if(!r)return null;const x=r.map(c=>{const v=c/255;return v<=.04045?v/12.92:((v+.055)/1.055)**2.4});return x[0]*.2126+x[1]*.7152+x[2]*.0722}
function ratio(a,b){const x=luminance(a),y=luminance(b);return x===null||y===null?0:(Math.max(x,y)+.05)/(Math.min(x,y)+.05)}
function onBrand(color){return ratio(color,'#000000')>=ratio(color,'#ffffff')?'#000000':'#ffffff'}
function apply(){const brand=getComputedStyle(document.documentElement).getPropertyValue('--brand').trim();for(const root of document.querySelectorAll('#yhnCarePlanTool,#phoneAssistTool,#mutationTool,#visitTool,#directorForm,.mobile-bottom-nav'))root.style.setProperty('--component-on-brand',onBrand(brand))}
return {rgb,luminance,ratio,onBrand,apply};
});
