(() => {
  'use strict';
  const PLANS_KEY = 'yhn_supervisor_daily_plans_v1';
  const SENT_KEY = 'yhn_case_reminder_notifications_v1';
  const $ = id => document.getElementById(id);
  const today = () => new Date().toLocaleDateString('sv-SE', { timeZone: 'Asia/Taipei' });
  const parseDate = value => {
    const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(value || ''));
    return match ? new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]), 12) : null;
  };
  const iso = date => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
  const addMonths = (value, months) => {
    const source = parseDate(value);
    if (!source) return '';
    const day = source.getDate();
    const target = new Date(source.getFullYear(), source.getMonth() + months, 1, 12);
    target.setDate(Math.min(day, new Date(target.getFullYear(), target.getMonth() + 1, 0).getDate()));
    return iso(target);
  };
  const addVisitWeekday = value => {
    const date = parseDate(addMonths(value, 3));
    if (!date) return '';
    if (date.getDay() === 6) date.setDate(date.getDate() + 2);
    if (date.getDay() === 0) date.setDate(date.getDate() + 1);
    return iso(date);
  };
  const esc = value => String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
  function readPlans() {
    try { const value = JSON.parse(localStorage.getItem(PLANS_KEY) || '{}'); return value && typeof value === 'object' && !Array.isArray(value) ? value : {}; }
    catch (_) { return {}; }
  }
  function savePlans(plans) {
    try { localStorage.setItem(PLANS_KEY, JSON.stringify(plans)); window.dispatchEvent(new CustomEvent('yhn:plans-updated')); return true; }
    catch (_) { toast('提醒無法儲存：此裝置儲存空間不足。'); return false; }
  }
  function identify(client) {
    const key = String(client?.clientId || client?.caseNo || client?.id || client?.name || '').trim();
    return key ? { key, name: String(client.name || '個案'), caseNo: String(client.caseNo || ''), clientId: String(client.clientId || '') } : null;
  }
  function isShortStay(client) {
    const type = `${client?.type || ''} ${client?.status || ''}`;
    return /喘息|短照|短期照顧|短期住宿/.test(type);
  }
  function removeFuture(plans, caseRef, reminderType, sourceDate) {
    Object.keys(plans).forEach(date => {
      if (date <= sourceDate || !Array.isArray(plans[date]?.tasks)) return;
      plans[date].tasks = plans[date].tasks.filter(task => !(task.caseRef === caseRef && task.caseReminderType === reminderType && task.status !== '已完成'));
    });
  }
  function schedule({ client, sourceDate, reminderType, dueDate, title, category, note }) {
    const person = identify(client);
    if (!person || !parseDate(sourceDate) || !parseDate(dueDate)) return { ok: false, message: '個案或日期資料不足，未建立提醒。' };
    let plans = readPlans();
    removeFuture(plans, person.key, reminderType, sourceDate);
    const target = plans[dueDate] && typeof plans[dueDate] === 'object' ? plans[dueDate] : { focus: '', tasks: [], reflection: '', tomorrow: ['', '', ''], habitDone: [] };
    const tasks = Array.isArray(target.tasks) ? target.tasks : [];
    const existing = tasks.find(task => task.caseRef === person.key && task.caseReminderType === reminderType && task.caseReminderSourceDate === sourceDate);
    if (!existing) {
      tasks.push({
        id: `case-reminder-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        title: `${title}｜${person.name}`, start: '09:00', end: reminderType === 'home-visit' ? '10:00' : '09:30', category,
        priority: '重要', status: '未開始',
        note: `${note}｜來源日期：${sourceDate}｜個案：${person.name}${person.caseNo ? `｜案號：${person.caseNo}` : ''}`,
        caseRef: person.key, caseName: person.name, caseNo: person.caseNo, caseTaskType: reminderType,
        caseReminderType: reminderType, caseReminderSourceDate: sourceDate, caseReminderDueDate: dueDate
      });
    }
    plans = { ...plans, [dueDate]: { ...target, tasks } };
    if (!savePlans(plans)) return { ok: false, message: '每日工作台未能保存提醒。' };
    return { ok: true, dueDate, title: `${title}｜${person.name}` };
  }
  function toast(message) {
    let root = $('caseReminderToast');
    if (!root) {
      root = document.createElement('div'); root.id = 'caseReminderToast'; root.className = 'case-reminder-toast'; root.setAttribute('role', 'status'); root.setAttribute('aria-live', 'polite'); document.body.append(root);
    }
    root.textContent = message; root.classList.add('is-visible'); clearTimeout(toast.timer); toast.timer = setTimeout(() => root.classList.remove('is-visible'), 6000);
  }
  function recordActivity({ kind, client, date }) {
    if (isShortStay(client)) return { ok: true, skipped: true };
    const dueDate = kind === '家訪' ? addVisitWeekday(date) : addMonths(date, 1);
    if (!dueDate) return { ok: false, message: '紀錄日期無效，未建立提醒。' };
    const type = kind === '家訪' ? 'home-visit' : 'phone-visit';
    const title = kind === '家訪' ? '安排家訪' : '安排電訪';
    const note = kind === '家訪' ? '依家訪日期加三個月推算，週末順延至下一個平日；國定假日請人工確認' : '依電訪日期加一個月推算，請確認聯繫日期';
    return schedule({ client, sourceDate: date, reminderType: type, dueDate, title, category: kind === '家訪' ? '家訪' : '電訪', note });
  }
  function recordPlanSaved({ client, date }) {
    const dueDate = addMonths(date, 3);
    if (!dueDate) return { ok: false, message: '計畫日期無效，未建立評值提醒。' };
    return schedule({ client, sourceDate: date, reminderType: 'care-plan-review', dueDate, title: '照顧計畫評值／重新評估', category: '計畫核對', note: '照顧計畫完成後三個月內辦理評值與重新評估' });
  }
  function requestPermission() {
    if (!('Notification' in window)) { toast('此瀏覽器不支援桌面推播；工作台內仍會保留日曆提醒。'); return; }
    if (Notification.permission === 'granted') { toast('已開啟工作提醒推播。須保持工作台開啟，才能在排定時間收到提醒。'); return; }
    if (Notification.permission === 'denied') { toast('瀏覽器已封鎖通知，請到網站權限設定允許通知；提醒仍會列在工作台日曆。'); return; }
    Notification.requestPermission().then(permission => toast(permission === 'granted' ? '推播已開啟。須保持工作台開啟，才能在排定時間收到提醒。' : '尚未允許推播，工作台日曆提醒仍會保留。'));
  }
  function fireDue() {
    if (!('Notification' in window) || Notification.permission !== 'granted') return;
    const now = new Date(), date = today(), minute = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    const tasks = readPlans()[date]?.tasks || [];
    let sent = [];
    try { sent = JSON.parse(localStorage.getItem(SENT_KEY) || '[]'); if (!Array.isArray(sent)) sent = []; } catch (_) {}
    let changed = false;
    tasks.filter(task => task && task.status !== '已完成' && task.caseReminderType && String(task.start || '') <= minute).forEach(task => {
      const key = `${date}|${task.id}`;
      if (sent.includes(key)) return;
      const notification = new Notification('永護寧工作提醒', { body: `${task.title}（${date} ${task.start || ''}）`, tag: key, renotify: false });
      notification.onclick = () => { window.focus(); window.yhnDailyWorkbench?.openTask(date, task.id); notification.close(); };
      sent.push(key); changed = true;
      toast(`提醒：${task.title}`);
    });
    if (changed) { try { localStorage.setItem(SENT_KEY, JSON.stringify(sent.slice(-300))); } catch (_) {} }
  }
  window.yhnCaseReminders = { recordActivity, recordPlanSaved, requestPermission, addVisitWeekday, addMonths };
  document.addEventListener('DOMContentLoaded', () => {
    $('reminderPushSetup')?.addEventListener('click', requestPermission);
    window.addEventListener('yhn:case-reminder-created', event => {
      const result=event.detail;
      if(result?.ok)toast(`已加入工作安排：${result.title}｜${result.dueDate}`);
    });
    fireDue(); setInterval(fireDue, 30000); document.addEventListener('visibilitychange', () => { if (!document.hidden) fireDue(); });
  });
})();
