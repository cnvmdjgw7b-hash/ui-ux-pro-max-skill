(() => {
  const workspace = document.querySelector('.workspace');
  const toggle = document.getElementById('layoutToggle');
  if (!workspace || !toggle) return;
  const key = 'yhn_planner_layout_v1';
  const mobile = window.matchMedia('(max-width: 660px)');
  let single = localStorage.getItem(key);
  single = single === null ? mobile.matches : single === 'single';
  const update = () => {
    workspace.classList.toggle('single-column', single);
    toggle.setAttribute('aria-pressed', String(single));
    toggle.textContent = single ? '▤ 切換雙列' : '▤ 切換單列';
  };
  toggle.addEventListener('click', () => {
    single = !single;
    localStorage.setItem(key, single ? 'single' : 'double');
    update();
  });
  update();
})();
