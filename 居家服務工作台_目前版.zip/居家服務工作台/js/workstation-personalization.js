(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const KEY = 'yhn_workstation_personalization_v1';
  const defaults = {name:'居家服務工作站',backgroundOpacity:40,petAppearance:'photo',petSize:124};
  let settings = load();
  function load(){try{return {...defaults,...JSON.parse(localStorage.getItem(KEY)||'{}')}}catch{return {...defaults}}}
  function persist(message='設定已儲存於這台裝置。'){
    try{localStorage.setItem(KEY,JSON.stringify(settings));status(message);return true}
    catch{status('儲存空間不足，請先移除較大的背景或角色圖片。',true);return false}
  }
  function status(text,error=false){const el=$('personalSettingsStatus');if(el){el.textContent=text;el.dataset.error=String(error)}}
  function rgb(hex){const m=/^#?([\da-f]{2})([\da-f]{2})([\da-f]{2})$/i.exec(hex.trim());return m?m.slice(1).map(v=>parseInt(v,16)):[255,249,240]}
  function applyName(){
    const name=(settings.name||defaults.name).trim()||defaults.name;
    document.querySelectorAll('[data-workstation-name],.dir-head h1').forEach(el=>el.textContent=name);
    document.title=name;document.querySelector('meta[name="apple-mobile-web-app-title"]')?.setAttribute('content',name);
  }
  function applyAvatar(){
    const img=$('profileAvatarImage'),fallback=$('profileAvatarFallback');
    if(!img||!fallback)return;
    if(settings.avatar){img.src=settings.avatar;img.hidden=false;fallback.hidden=true}
    else{img.removeAttribute('src');img.hidden=true;fallback.hidden=false}
  }
  function applyBackground(){
    const body=document.body;
    if(!settings.background){body.classList.remove('personal-background');body.style.removeProperty('--personal-background');body.style.removeProperty('--personal-bg-overlay');return}
    const color=getComputedStyle(document.documentElement).getPropertyValue('--bg');
    const [r,g,b]=rgb(color);const alpha=Math.min(0.85,Math.max(0,Number(settings.backgroundOpacity??40)/100));
    body.style.setProperty('--personal-background',`url("${settings.background}")`);
    body.style.setProperty('--personal-bg-overlay',`rgba(${r},${g},${b},${alpha})`);
    body.classList.add('personal-background');
  }
  function applyPet(){
    const img=$('fairyCat'),glyph=$('fairyGlyph'),toggle=$('fairyToggle'),select=$('petAppearanceSelect');
    if(!img||!glyph||!toggle)return;
    const mode=settings.petAppearance||'photo';
    const size=Math.min(220,Math.max(48,Number(settings.petSize)||124));
    toggle.style.setProperty('--pet-size',size+'px');
    const sizeInput=$('petSize');if(sizeInput)sizeInput.value=String(size);
    const sizeValue=$('petSizeValue');if(sizeValue)sizeValue.textContent=size+' px';
    if(mode==='custom'&&settings.petImage){img.src=settings.petImage;img.alt='自訂小精靈角色';img.hidden=false;glyph.hidden=true;toggle.removeAttribute('data-glyph')}
    else if(mode!=='photo'&&mode!=='custom'){img.hidden=true;glyph.hidden=false;glyph.textContent=mode;img.alt='';toggle.dataset.glyph=mode}
    else{img.src='workstation-pet.png';img.alt='虎斑貓小精靈';img.hidden=false;glyph.hidden=true;toggle.removeAttribute('data-glyph')}
    if(select)select.value=mode==='custom'&&!settings.petImage?'photo':mode;
  }
  function applyAll(){applyName();applyAvatar();applyBackground();applyPet();const name=$('personalWorkstationName');if(name)name.value=settings.name||defaults.name;const opacity=$('personalBackgroundOpacity');if(opacity)opacity.value=String(settings.backgroundOpacity??40);const value=$('personalBackgroundValue');if(value)value.textContent=`${settings.backgroundOpacity??40}%`;}
  function imageData(file,maxEdge,quality=.84){
    return new Promise((resolve,reject)=>{
      const url=URL.createObjectURL(file),img=new Image();
      img.onload=()=>{try{const scale=Math.min(1,maxEdge/Math.max(img.naturalWidth,img.naturalHeight));const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(img.naturalWidth*scale));canvas.height=Math.max(1,Math.round(img.naturalHeight*scale));const ctx=canvas.getContext('2d');ctx.drawImage(img,0,0,canvas.width,canvas.height);const type=file.type==='image/png'?'image/png':'image/jpeg';resolve(canvas.toDataURL(type,quality))}catch(error){reject(error)}finally{URL.revokeObjectURL(url)}};
      img.onerror=()=>{URL.revokeObjectURL(url);reject(new Error('image-read-failed'))};img.src=url;
    });
  }
  async function handleImage(input,kind){
    const file=input.files?.[0];if(!file)return;
    if(!file.type.startsWith('image/')){status('請選擇圖片檔。',true);return}
    try{
      const data=await imageData(file,kind==='background'?1800:512,kind==='background'?.78:.86);
      if(kind==='avatar')settings.avatar=data;else if(kind==='background')settings.background=data;else{settings.petImage=data;settings.petAppearance='custom'}
      if(persist(kind==='pet'?'小精靈角色已更換。':'照片設定已更新。'))applyAll();
    }catch{status('圖片讀取失敗，請換一張圖片再試。',true)}
    input.value='';
  }
  function init(){
    applyAll();window.addEventListener('load',applyName,{once:true});
    $('personalWorkstationName')?.addEventListener('input',e=>{settings.name=e.target.value.slice(0,32);applyName();persist()});
    $('personalAvatarFile')?.addEventListener('change',e=>handleImage(e.target,'avatar'));
    $('personalBackgroundFile')?.addEventListener('change',e=>handleImage(e.target,'background'));
    $('petSize')?.addEventListener('input',e=>{settings.petSize=Math.min(220,Math.max(48,Number(e.target.value)||124));applyPet();persist('小精靈大小已儲存。');window.dispatchEvent(new Event('resize'))});
    $('petAppearanceFile')?.addEventListener('change',e=>handleImage(e.target,'pet'));
    $('personalBackgroundOpacity')?.addEventListener('input',e=>{settings.backgroundOpacity=Number(e.target.value);applyBackground();const value=$('personalBackgroundValue');if(value)value.textContent=`${settings.backgroundOpacity}%`;persist()});
    $('petAppearanceSelect')?.addEventListener('change',e=>{settings.petAppearance=e.target.value;if(e.target.value==='custom'&&!settings.petImage){status('請選擇下方「上傳角色圖片」。');e.target.value='photo';settings.petAppearance='photo';return}persist('小精靈外觀已更新。');applyPet()});
    $('themeChooserDialog')?.addEventListener('click',e=>{const clear=e.target.closest('[data-personal-clear]');if(clear){const kind=clear.dataset.personalClear;if(kind==='avatar')delete settings.avatar;if(kind==='background'){delete settings.background;document.body.classList.remove('personal-background')}persist(kind==='avatar'?'已移除頭像。':'已移除背景圖片。');applyAll();return}if(e.target.closest('[data-pet-appearance-reset]')){delete settings.petImage;settings.petAppearance='photo';persist('已恢復預設虎斑貓。');applyPet()}});
    window.addEventListener('yhn-theme-change',applyBackground);
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
