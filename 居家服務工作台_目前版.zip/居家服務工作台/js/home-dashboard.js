(() => {
  'use strict';
  const PLAN_KEY = 'yhn_supervisor_daily_plans_v1';
  const $ = id => document.getElementById(id);
  const themes = {
    pomegranate: {mode:'light',name:'石榴氣泡水',bg:'#F0F8FC',card:'#FFFFFF',ink:'#17344F',muted:'#697D8B',line:'#D0F2FC',brand:'#C63054',brandDark:'#9F2442',soft:'#E2E1FF',accent:'#AF717E'},
    redbean: {mode:'light',name:'紅豆糯糯糕',bg:'#FFF9E9',card:'#FFFFFF',ink:'#17344F',muted:'#7B7180',line:'#F4D9C7',brand:'#D36384',brandDark:'#A84766',soft:'#FFF1C5',accent:'#A9D3B3'},
    watermelon: {mode:'light',name:'西瓜碎奶沙',bg:'#F3FBEF',card:'#FFFFFF',ink:'#17344F',muted:'#6F7D89',line:'#DCEBCF',brand:'#FF929A',brandDark:'#C95C6B',soft:'#EAFCDE',accent:'#C9F794'},
    midnight: {mode:'dark',name:'午夜海鹽藍',bg:'#15283D',card:'#233B54',ink:'#EAF4FB',muted:'#B5C7D4',line:'#3A536B',brand:'#8CCCF0',brandDark:'#A8DFFA',soft:'#304D68',accent:'#B8E1F5'},
    caramel: {mode:'dark',name:'焦糖夕陽橘',bg:'#34251D',card:'#4B3528',ink:'#FFF0E2',muted:'#D2B8A2',line:'#6C4C39',brand:'#FFB66E',brandDark:'#FFD0A0',soft:'#614431',accent:'#F2C28C'},
    matcha: {mode:'dark',name:'抹茶森林綠',bg:'#192D28',card:'#2A4439',ink:'#EDF7EF',muted:'#B9CBBF',line:'#456657',brand:'#B6DFC0',brandDark:'#D0EED7',soft:'#375849',accent:'#A9D3B3'}
  };
  Object.assign(themes,window.YhnThemePalettes.themes);
  let activeDate = '';
  let selectedThemeMode = 'light';
  let selectedNoticeTab = 'important';
  let activeTask = null;
  const today = () => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  };
  const parseDate = value => {
    const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(value||''));
    return match ? new Date(Number(match[1]),Number(match[2])-1,Number(match[3]),12) : new Date();
  };
  const isoDate = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  const addDays = (value,amount) => {const d=parseDate(value);d.setDate(d.getDate()+amount);return isoDate(d)};
  const mondayOf = value => {const d=parseDate(value);const offset=(d.getDay()+6)%7;d.setDate(d.getDate()-offset);return isoDate(d)};
  const fmtDay = value => {const d=parseDate(value);return `${d.getMonth()+1}/${d.getDate()}`};
  const fmtWeekday = value => ['日','一','二','三','四','五','六'][parseDate(value).getDay()];
  const esc = value => String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const timeMinutes = value => {const [h,m]=String(value||'').split(':').map(Number);return Number.isFinite(h)&&Number.isFinite(m)?h*60+m:0};
  const duration = task => Math.max(0,timeMinutes(task.end)-timeMinutes(task.start));
  function readPlans(){try{const data=JSON.parse(localStorage.getItem(PLAN_KEY)||'{}');return data&&typeof data==='object'&&!Array.isArray(data)?data:{}}catch(_){return {}}}
  function tasksFor(date,plans=readPlans()){const day=plans[date];return day&&Array.isArray(day.tasks)?day.tasks.filter(t=>t&&typeof t==='object'&&typeof t.title==='string'):[]}
  function selected(){return $('plannerDate')?.value||today()}
  function setDate(date){if(!/^\d{4}-\d{2}-\d{2}$/.test(date))return;const input=$('plannerDate');if(input.value===date){renderAll();return}input.value=date;input.dispatchEvent(new Event('change',{bubbles:true}))}
  function categoryClass(value){const v=String(value||'');return v.includes('家訪')?'cat-home':v.includes('電訪')?'cat-phone':v.includes('個案')?'cat-case':v.includes('計畫')||v.includes('服務紀錄')?'cat-care':'cat-admin'}
  function statusLabel(task){return task.status||'未開始'}
  function openThemeDialog(){const d=$('themeChooserDialog');renderThemes();if(typeof d.showModal==='function')d.showModal();else d.setAttribute('open','')}
  function closeDialog(dialog){if(typeof dialog.close==='function'&&dialog.open)dialog.close();else dialog.removeAttribute('open')}
  const skinPairs={pomegranate:'midnight',redbean:'caramel',watermelon:'matcha',...window.YhnThemePalettes.pairs};
  const themeKey='yhn_workstation_theme_v2';
  let selectedSkin='pomegranate';
  const systemTheme=window.matchMedia('(prefers-color-scheme: dark)');
  function resolvedMode(){return selectedThemeMode==='system'?(systemTheme.matches?'dark':'light'):selectedThemeMode}
  function renderThemes(){
    const root=$('themeChoices');if(!root)return;
    root.innerHTML=Object.keys(skinPairs).map(id=>{const t=themes[resolvedMode()==='dark'?skinPairs[id]:id],swatches=window.YhnThemePalettes.palettes[id]?'<span class="theme-swatches" aria-label="圖片參考配色">'+window.YhnThemePalettes.palettes[id].colors.map(color=>'<i style="background:'+color+'" title="'+color+'"></i>').join('')+'</span>':'';return `<button class="theme-choice" type="button" data-theme-id="${id}" aria-pressed="${selectedSkin===id}"><span class="theme-mini" style="--mini-bg:${t.bg};--mini-card:${t.card};--mini-brand:${t.brand};--mini-ink:${t.ink}"><i></i><b></b><em></em><strong></strong><small></small></span><span><strong>${themes[id].name}</strong><small>${resolvedMode()==='light'?'淺色模式':'深色模式'}${selectedThemeMode==='system'?' · 跟隨系統':''}</small>${swatches}</span><i class="theme-check" aria-hidden="true">✓</i></button>`}).join('');
    document.querySelectorAll('[data-theme-mode]').forEach(b=>b.classList.toggle('is-active',b.dataset.themeMode===selectedThemeMode));
  }
  function applyTheme(id){
    if(!skinPairs[id])return;selectedSkin=id;
    const key=resolvedMode()==='dark'?skinPairs[id]:id;
    document.documentElement.dataset.theme=key;
    document.documentElement.style.colorScheme=resolvedMode();
    document.documentElement.dataset.readableTheme=resolvedMode();
    document.querySelector?.('meta[name="theme-color"]')?.setAttribute('content',themes[key].bg);
    for(const [name,value]of Object.entries(window.YhnThemePalettes.tokens(themes[key])))document.documentElement.style.setProperty(name,value);
    try{localStorage.setItem(themeKey,JSON.stringify({skin:selectedSkin,mode:selectedThemeMode}))}catch(_){}
    renderThemes();window.dispatchEvent(new CustomEvent('yhn-theme-change',{detail:{skin:selectedSkin,mode:resolvedMode()}}));
  }
  function resetTheme(){selectedThemeMode='light';applyTheme('pomegranate')}
  try{const saved=JSON.parse(localStorage.getItem(themeKey)||'null');if(saved&&skinPairs[saved.skin]&&['light','dark','system'].includes(saved.mode)){selectedSkin=saved.skin;selectedThemeMode=saved.mode}}catch(_){}
  applyTheme(selectedSkin);
  systemTheme.addEventListener('change',()=>{if(selectedThemeMode==='system')applyTheme(selectedSkin)});
  function renderWeek(){
    const date=selected(),monday=mondayOf(date),dates=Array.from({length:7},(_,i)=>addDays(monday,i)),plans=readPlans();
    const range=$('weekCalendarRange');if(range)range.textContent=`${fmtDay(dates[0])}（週一）–${fmtDay(dates[6])}（週日）｜依此裝置已保存的每日工作`;
    $('weekMobileStrip').innerHTML=dates.map(d=>`<button type="button" class="week-date-chip ${d===date?'is-selected':''} ${d===today()?'is-today':''}" data-week-date="${d}"><small>週${fmtWeekday(d)}</small><strong>${parseDate(d).getDate()}</strong><em>${tasksFor(d,plans).length} 項</em></button>`).join('');
    const labels=Array.from({length:15},(_,i)=>`<span>${String(8+i).padStart(2,'0')}:00</span>`).join('');
    const columns=dates.map(d=>{
      const tasks=tasksFor(d,plans).slice().sort((a,b)=>timeMinutes(a.start)-timeMinutes(b.start));
      const lanes=[];let maxLane=1;const assigned=tasks.map(task=>{const start=timeMinutes(task.start),end=timeMinutes(task.end);let lane=lanes.findIndex(until=>until<=start);if(lane<0){lane=lanes.length;lanes.push(end)}else lanes[lane]=end;maxLane=Math.max(maxLane,lanes.length);return {task,lane,start,end}});
      return `<div class="week-day-column ${d===date?'is-selected':''} ${d===today()?'is-today':''}" role="gridcell" data-week-column="${d}">${assigned.map(({task,lane,start,end})=>{const clippedStart=Math.max(480,start),clippedEnd=Math.min(1320,end);if(clippedEnd<=clippedStart)return '';const top=(clippedStart-480)/60*44,height=Math.max(27,(clippedEnd-clippedStart)/60*44),width=100/maxLane;return `<button type="button" class="week-task-block ${categoryClass(task.category)} ${task.status==='已完成'?'is-done':''}" style="top:${top}px;left:calc(${lane*width}% + 2px);width:calc(${width}% - 4px);height:${height}px" data-dash-task="${esc(task.id||'')}" data-date="${d}" aria-label="${esc(task.start)} 至 ${esc(task.end)}，${esc(task.title)}，${esc(task.category||'其他')}，${esc(statusLabel(task))}"><time>${esc(task.start)}–${esc(task.end)}</time><strong>${esc(task.title)}</strong></button>`}).join('')}</div>`;
    }).join('');
    $('weekGrid').innerHTML=`<div class="week-grid-head"><span></span>${dates.map(d=>`<button type="button" class="week-grid-day ${d===today()?'is-today':''} ${d===date?'is-selected':''}" data-week-date="${d}"><small>週${fmtWeekday(d)}</small><strong>${fmtDay(d)}</strong><em>${tasksFor(d,plans).length} 項</em></button>`).join('')}</div><div class="week-grid-body"><div class="week-time-axis">${labels}</div>${columns}</div>`;
    const agendaTasks=tasksFor(date,plans).slice().sort((a,b)=>timeMinutes(a.start)-timeMinutes(b.start));
    $('weekAgenda').innerHTML=agendaTasks.length?agendaTasks.map(task=>`<button class="agenda-task ${categoryClass(task.category)} ${task.status==='已完成'?'is-done':''}" type="button" data-dash-task="${esc(task.id||'')}" data-date="${date}"><time>${esc(task.start)}–${esc(task.end)}</time><span><strong>${esc(task.title)}</strong><small>${esc(task.category||'其他')}・${esc(statusLabel(task))}</small></span><i>查看</i></button>`).join(''):'<p class="week-empty">這天尚無已保存的工作安排。可使用「新增工作」建立安排。</p>';
    $('weekOverlapNote').hidden=!dates.some(d=>{const ts=tasksFor(d,plans);return ts.some((a,i)=>ts.slice(i+1).some(b=>timeMinutes(a.start)<timeMinutes(b.end)&&timeMinutes(b.start)<timeMinutes(a.end)))});
  }
  function renderKpis(){
    const date=selected(),tasks=tasksFor(date),done=tasks.filter(t=>t.status==='已完成').length,progress=tasks.filter(t=>t.status==='進行中').length,pending=tasks.filter(t=>t.status!=='已完成').length;
    $('kpiTotal').textContent=tasks.length;$('kpiDone').textContent=done;$('kpiProgress').textContent=progress;$('kpiPending').textContent=pending;
    $('kpiTotalLabel').textContent=date===today()?'本日工作':`${parseDate(date).getMonth()+1}/${parseDate(date).getDate()} 工作`;
    $('kpiPendingLabel').textContent=date===today()?'待處理':'未完成';$('kpiPendingHint').textContent='項尚未完成';
  }
  function renderQuadrants(){
    const tasks=tasksFor(selected()).slice().sort((a,b)=>timeMinutes(a.start)-timeMinutes(b.start));
    const groups=[['重要・待完成',tasks.filter(t=>t.priority==='重要'&&t.status!=='已完成')],['一般／次要・待完成',tasks.filter(t=>t.priority!=='重要'&&t.status!=='已完成')],['重要・已完成',tasks.filter(t=>t.priority==='重要'&&t.status==='已完成')],['一般／次要・已完成',tasks.filter(t=>t.priority!=='重要'&&t.status==='已完成')]];
    $('taskQuadrants').innerHTML=groups.map(([label,list])=>`<section class="task-quadrant"><h4>${esc(label)} <span>${list.length}</span></h4>${list.length?list.slice(0,4).map(t=>`<button type="button" data-dash-task="${esc(t.id||'')}" data-date="${selected()}">${esc(t.title)}</button>`).join(''):'<small>目前沒有項目</small>'}</section>`).join('');
  }
  function renderActivity(){
    const monday=mondayOf(selected()),plans=readPlans(),dates=Array.from({length:7},(_,i)=>addDays(monday,i));let total=0;
    const activity=dates.map(date=>({date,tasks:tasksFor(date,plans)})).filter(item=>item.tasks.length).reverse();
    activity.forEach(item=>item.tasks.forEach(t=>total+=duration(t)));
    const hours=total/60;$('weekHoursTotal').textContent=`${Number.isInteger(hours)?hours:hours.toFixed(1)} 小時`;
    $('weekActivity').innerHTML=activity.length?activity.map(item=>`<button type="button" class="week-activity-row" data-week-date="${item.date}"><span class="activity-date"><strong>${fmtDay(item.date)}</strong><small>週${fmtWeekday(item.date)}</small></span><span class="activity-bar"><i style="width:${Math.min(100,Math.max(6,item.tasks.length*12))}%"></i></span><span class="activity-count">${item.tasks.length} 項・${item.tasks.filter(t=>t.status==='已完成').length} 完成</span></button>`).join(''):'<p class="week-empty">本週尚無已保存的工作安排。</p>';
  }
  function renderNotices(){
    const tasks=tasksFor(today()).slice().sort((a,b)=>timeMinutes(a.start)-timeMinutes(b.start)),now=new Date(),nowMins=now.getHours()*60+now.getMinutes();
    const count=tasks.filter(t=>t.status!=='已完成'&&timeMinutes(t.end)<nowMins).length;
    const badge=$('noticeCount');badge.hidden=count===0;badge.textContent=count>9?'9+':String(count);
    const visible=selectedNoticeTab==='important'?tasks.filter(t=>t.status!=='已完成'):tasks.filter(t=>t.status==='已完成');
    $('noticeItems').innerHTML=visible.length?visible.map(t=>`<button type="button" class="notice-item ${t.status!=='已完成'&&timeMinutes(t.end)<nowMins?'is-overdue':''}" data-dash-task="${esc(t.id||'')}" data-date="${today()}"><span class="notice-item-time">${esc(t.start)}–${esc(t.end)}</span><span><strong>${esc(t.title)}</strong><small>${esc(t.category||'其他')}・${esc(statusLabel(t))}${t.status!=='已完成'&&timeMinutes(t.end)<nowMins?'・已超過排定時間':''}</small></span><i>查看</i></button>`).join(''):'<p class="week-empty">目前沒有此類今日工作。</p>';
  }
  function showTask(date,id){
    const task=tasksFor(date).find(t=>String(t.id||'')===String(id));if(!task)return;
    activeTask={date,id};const root=$('dashboardTaskDetail');root.replaceChildren();
    const fields=[['日期',date],['時間',`${task.start||'--:--'}–${task.end||'--:--'}`],['類型',task.category||'其他'],['優先程度',task.priority||'一般'],['狀態',statusLabel(task)],['備註',task.note||'無']];
    fields.forEach(([label,value])=>{const row=document.createElement('div');row.className='dashboard-task-field';const key=document.createElement('small');key.textContent=label;const val=document.createElement('strong');val.textContent=value;row.append(key,val);root.append(row)});
    $('dashboardTaskTitle').textContent=task.title;$('dashboardTaskEdit').hidden=!task.id;
    const d=$('dashboardTaskDialog');if(typeof d.showModal==='function')d.showModal();else d.setAttribute('open','');
  }
  function renderAll(){
    // Keep one malformed/missing dashboard panel from breaking the rest of the app.
    for(const render of [renderKpis,renderQuadrants,renderActivity,renderNotices]){
      try{render()}catch(error){console.error('工作台區塊更新失敗',error)}
    }
  }
  function goToCalendar(){
    const target=$('weekCalendar');if(!target)return;
    if(document.body.classList.contains('tool-page-open')){
      document.querySelector('[data-yhn-home]')?.click();
      window.setTimeout(()=>goToCalendar(),120);
      return;
    }
    document.body.classList.remove('mobile-calendar-focus');
    requestAnimationFrame(()=>{
      target.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'start'});
      document.body.classList.add('mobile-calendar-focus');
      window.setTimeout(()=>document.body.classList.remove('mobile-calendar-focus'),1400);
    });
  }
  function init(){
    // Bind navigation before rendering; a dashboard data issue must not disable the nav.
    document.querySelectorAll('[data-mobile-home]').forEach(b=>b.addEventListener('click',()=>document.querySelector('[data-yhn-home]')?.click()));
    $('mobileAddTask')?.addEventListener('click',()=>$('plannerAddTask')?.click());
    document.querySelectorAll('[data-mobile-case]').forEach(b=>b.addEventListener('click',()=>$('casePickerOpen')?.click()));
    document.querySelectorAll('[data-mobile-tools]').forEach(b=>b.addEventListener('click',()=>$('yhnMenuToggle')?.click()));
    activeDate=selected();renderAll();
    $('plannerDate')?.addEventListener('change',()=>{activeDate=selected();renderAll()});
    window.addEventListener('yhn:plans-updated',()=>{activeDate=selected();renderAll()});
    $('weekViewToggle')?.addEventListener('click',event=>{const expanded=$('weekCalendar').classList.toggle('is-expanded');event.currentTarget.setAttribute('aria-expanded',String(expanded));event.currentTarget.textContent=expanded?'收合週曆':'完整週曆'});
    $('weekGrid')?.addEventListener('click',event=>{const day=event.target.closest('[data-week-date]');if(day&&!event.target.closest('[data-dash-task]'))setDate(day.dataset.weekDate);const task=event.target.closest('[data-dash-task]');if(task)showTask(task.dataset.date,task.dataset.dashTask)});
    $('weekMobileStrip')?.addEventListener('click',event=>{const button=event.target.closest('[data-week-date]');if(button)setDate(button.dataset.weekDate)});
    $('weekAgenda')?.addEventListener('click',event=>{const button=event.target.closest('[data-dash-task]');if(button)showTask(button.dataset.date,button.dataset.dashTask)});
    $('taskQuadrants')?.addEventListener('click',event=>{const button=event.target.closest('[data-dash-task]');if(button)showTask(button.dataset.date,button.dataset.dashTask)});
    $('weekActivity')?.addEventListener('click',event=>{const button=event.target.closest('[data-week-date]');if(button)setDate(button.dataset.weekDate)});
    $('dashboardTaskDialog')?.addEventListener('click',event=>{if(event.target===$('dashboardTaskDialog')||event.target.closest('[data-dashboard-task-close]'))closeDialog($('dashboardTaskDialog'))});
    $('dashboardTaskEdit')?.addEventListener('click',()=>{if(!activeTask)return;const task=activeTask;closeDialog($('dashboardTaskDialog'));window.yhnDailyWorkbench?.openTask(task.date,task.id)});
    $('dashboardSearch')?.addEventListener('input',event=>{const input=$('plannerTaskSearch');if(input){input.value=event.target.value;input.dispatchEvent(new Event('input',{bubbles:true}))}});
    $('themeChooserOpen')?.addEventListener('click',openThemeDialog);
    $('themeChooserDialog')?.addEventListener('click',event=>{const choice=event.target.closest('[data-theme-id]');if(choice)applyTheme(choice.dataset.themeId);if(event.target===$('themeChooserDialog')||event.target.closest('[data-theme-close]'))closeDialog($('themeChooserDialog'));if(event.target.closest('[data-theme-reset]'))resetTheme()});
    document.querySelectorAll('[data-theme-mode]').forEach(button=>button.addEventListener('click',()=>{selectedThemeMode=button.dataset.themeMode;applyTheme(selectedSkin)}));
    $('noticeCenterOpen')?.addEventListener('click',()=>{renderNotices();const d=$('noticeCenterDialog');if(typeof d.showModal==='function')d.showModal();else d.setAttribute('open','')});
    $('noticeCenterDialog')?.addEventListener('click',event=>{const close=event.target.closest('[data-notice-close]');if(event.target===$('noticeCenterDialog')||close)closeDialog($('noticeCenterDialog'));const tab=event.target.closest('[data-notice-tab]');if(tab){selectedNoticeTab=tab.dataset.noticeTab;document.querySelectorAll('[data-notice-tab]').forEach(b=>b.classList.toggle('is-active',b===tab));renderNotices()}const task=event.target.closest('[data-dash-task]');if(task){closeDialog($('noticeCenterDialog'));showTask(task.dataset.date,task.dataset.dashTask)}});
    document.querySelectorAll('.dashboard-kpi').forEach(card=>{const filter=()=>{const status=card.dataset.statusFilter;if($('plannerStatusFilter'))$('plannerStatusFilter').value=status||'all';$('plannerTaskSearch').value='';$('plannerTaskSearch').dispatchEvent(new Event('input',{bubbles:true}));$('plannerListTitle').scrollIntoView({behavior:'smooth',block:'start'})};card.addEventListener('click',filter);card.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();filter()}})});
    $('profileShortcut')?.addEventListener('click',()=>$('yhnSwitchUser')?.click());
    const copyName=()=>{$('profileShortcutName').textContent=$('yhnSideName')?.textContent||'使用者'};copyName();new MutationObserver(copyName).observe($('yhnSideName'),{childList:true,characterData:true,subtree:true});
    const collapseKey='yhn_workstation_sidebar_collapsed_v1';
    if(window.matchMedia('(min-width: 761px)').matches&&localStorage.getItem(collapseKey)==='true'){document.body.classList.add('tools-menu-collapsed');$('yhnMenuToggle')?.setAttribute('aria-expanded','false')}
    $('yhnMenuToggle')?.addEventListener('click',()=>{if(window.matchMedia('(min-width: 761px)').matches){setTimeout(()=>localStorage.setItem(collapseKey,String(document.body.classList.contains('tools-menu-collapsed'))),0)}});
    window.matchMedia('(min-width: 761px)').addEventListener?.('change',()=>{if(!window.matchMedia('(min-width: 761px)').matches)document.body.classList.remove('tools-menu-collapsed')});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
