(() => {
 'use strict';
 const $=s=>document.querySelector(s),$$=s=>document.querySelectorAll(s);
 const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const dayKey=d=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
 let selected=dayKey(new Date()),currentView='dashboard',tasks=[],cloud=null;
 function announce(text){$('#notification').textContent=text;$('#notification').hidden=false;clearTimeout(announce.timer);announce.timer=setTimeout(()=>$('#notification').hidden=true,4000);}
 function openTool(tool){if(parent===window){announce('請由工作站首頁登入後使用此功能');return;}parent.postMessage({type:'yhn:open-existing-tool',tool},location.origin);}
 function load(){try{tasks=window.yhnPlanBridge.load();}catch{announce('待辦資料無法讀取，原資料已保留');tasks=[];}render();}
 const todays=()=>tasks.filter(t=>t.date===selected).sort((a,b)=>String(a.start||'').localeCompare(String(b.start||'')));
 function identity(){try{const name=parent.document.getElementById('profileShortcutName')?.textContent;if(name)$('#userName').textContent=name;const avatar=parent.document.getElementById('profileAvatarImage');if(avatar&&!avatar.hidden&&avatar.getAttribute('src')){const img=document.createElement('img');img.src=avatar.src;img.alt='使用者頭像';$('.avatar').replaceChildren(img);}}catch{}}
 function render(){
  const now=new Date();$('#date').innerHTML=new Intl.DateTimeFormat('zh-TW',{year:'numeric',month:'2-digit',day:'2-digit'}).format(now)+'<small>'+new Intl.DateTimeFormat('zh-TW',{weekday:'long'}).format(now)+'</small>';
  $('#greeting').textContent=(now.getHours()<11?'☀️ 早安，今天也要好好照顧自己':now.getHours()<17?'☀️ 午安，今天也要好好照顧自己':'🌙 晚安，今天也辛苦了');identity();
  const query=$('#search').value.trim().toLowerCase(),all=todays(),visible=all.filter(t=>[t.title,t.note,t.category].join(' ').toLowerCase().includes(query)),done=all.filter(t=>t.done).length;
  $('#countCases').textContent=cloud?cloud.cases.filter(c=>c.queueStatus!=='done'&&(c.queueStatus==='today'||String(c.dueDate||'').startsWith(selected))).length:'—';
  $('#countFollow').textContent=all.length-done;$('#countDone').textContent=done;$('#countAlerts').textContent=all.filter(t=>!t.done&&t.priority==='high').length;
  $('#completionRate').textContent=`完成率 ${all.length?Math.round(done/all.length*100):0}%`;
  $('#todoTitle').textContent=`📋 今日待辦 · ${all.filter(t=>!t.done).length}項`;
  $('#events').innerHTML=visible.filter(t=>t.start).map(t=>`<div class="event"><time>${esc(t.start)}</time><div><strong>${esc(t.title)}</strong><small>${esc(t.category||'工作安排')}</small></div></div>`).join('')||'<div class="empty">今天尚無行程<br>點「新增」開始安排</div>';
  $('#todos').innerHTML=visible.map(t=>`<label class="todo ${t.done?'done':''}"><input type="checkbox" data-check="${esc(t.id)}" ${t.done?'checked':''}><span>${esc(t.title)}</span></label>`).join('')||'<div class="empty">今天尚無待辦事項</div>';
  if(currentView!=='dashboard')renderSubview();
 }
 function row(t){return `<button class="task-row" data-edit="${esc(t.id)}"><span>${t.done?'✓':'○'}</span><span>${esc(t.title)}<small>${esc(t.start||'未排時間')}–${esc(t.end||'')} · ${esc(t.category||'其他')}</small></span></button>`;}
 function renderSubview(){
  document.body.classList.add('direct-workspace');const all=todays(),title={board:'工作看板',list:'工作列表',table:'工作表格'}[currentView];$('#subTitle').textContent=title;
  $('#subDesc').innerHTML=`<div class="sub-toolbar"><button class="btn" data-shift="-1" aria-label="前一天">‹</button><input id="viewDate" type="date" value="${esc(selected)}" aria-label="工作日期"><button class="btn" data-shift="1" aria-label="後一天">›</button><button class="btn" data-today>今天</button><button class="btn primary" data-add-task>＋ 新增工作</button></div>`;
  let html='';
  if(currentView==='board')html='<div class="board">'+['未開始','進行中','已完成'].map(status=>`<section><h3>${status}</h3>${all.filter(t=>(t.done?'已完成':t.status||'未開始')===status).map(row).join('')||'<button class="add-task-card" data-add-task>＋ 新增工作</button>'}</section>`).join('')+'</div>';
  if(currentView==='list')html=all.map(row).join('')||'<button class="add-task-card" data-add-task>＋ 新增這一天的工作</button>';
  if(currentView==='table')html='<table class="data-table"><thead><tr><th>時間</th><th>工作事項</th><th>狀態</th></tr></thead><tbody>'+all.map(t=>`<tr><td>${esc(t.start)}</td><td><button class="btn" data-edit="${esc(t.id)}">${esc(t.title)}</button></td><td>${esc(t.done?'已完成':t.status||'未開始')}</td></tr>`).join('')+(all.length?'':'<tr><td colspan="3"><button class="add-task-card" data-add-task>＋ 新增工作</button></td></tr>')+'</tbody></table>';
  if(currentView==='calendar'){
   const [y,m]=selected.split('-').map(Number),count=new Date(y,m,0).getDate(),offset=new Date(y,m-1,1).getDay();
   html=`<div class="month-heading"><button class="btn" data-month="-1" aria-label="上個月">‹</button><strong>${y}年${m}月</strong><button class="btn" data-month="1" aria-label="下個月">›</button></div><div class="month-grid">${['日','一','二','三','四','五','六'].map(x=>'<small>'+x+'</small>').join('')}${'<span></span>'.repeat(offset)}`;
   for(let n=1;n<=count;n++){const date=`${y}-${String(m).padStart(2,'0')}-${String(n).padStart(2,'0')}`;html+=`<button data-day="${date}" class="${tasks.some(t=>t.date===date)?'has':''}" ${date===selected?'aria-current="date"':''}><b>${n}</b>${tasks.filter(t=>t.date===date).slice(0,3).map(t=>`<span class="calendar-task">${esc(t.start||'')} ${esc(t.title)}</span>`).join('')}</button>`;}
   html+='</div>'+ (all.map(row).join('')||'<button class="add-task-card" data-add-task>＋ 新增選定日期的行程</button>');
  }
  $('#subContent').innerHTML=html;
 }
 function tab(view){

  if(view==='cases'){openTool('dir:cases');return;}if(view==='tools'){openTool('all');return;}
  currentView=view;document.body.classList.toggle('direct-workspace',view!=='dashboard');$('#dashboard').hidden=view!=='dashboard';$('#subView').hidden=view==='dashboard';
  $$('.tabs button').forEach(b=>b.setAttribute('aria-selected',String(b.dataset.tab===view)));
  $$('[data-nav]').forEach(b=>{if(b.dataset.nav===view)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');});render();window.scrollTo({top:0,behavior:'smooth'});
 }
 let time=1500,focusMinutes=25,end=0,interval=null;
 function draw(){const m=Math.floor(time/60),s=time%60;$('#clock').textContent=String(m).padStart(2,'0')+':'+String(s).padStart(2,'0');}
 function stop(){clearInterval(interval);interval=null;$('#start').textContent='▶ 開始';}
 function setMinutes(n){stop();focusMinutes=n;time=n*60;draw();$$('[data-minutes]').forEach(b=>b.classList.toggle('selected',Number(b.dataset.minutes)===n));}
 function settings(){const v=prompt('設定倒數時間（分鐘，1～120）',String(focusMinutes));if(v===null)return;const n=Number(v);if(Number.isInteger(n)&&n>=1&&n<=120)setMinutes(n);else announce('請輸入1～120分鐘');}
 $('#start').addEventListener('click',()=>{if(interval){time=Math.max(0,Math.ceil((end-Date.now())/1000));stop();draw();}else{end=Date.now()+time*1000;$('#start').textContent='Ⅱ 暫停';interval=setInterval(()=>{time=Math.max(0,Math.ceil((end-Date.now())/1000));draw();if(!time){stop();announce('專注時間結束，記得休息一下。');}},250);}});
 $('#reset').addEventListener('click',()=>setMinutes(focusMinutes));$('#timerSettings').addEventListener('click',settings);$('#countdownMode').addEventListener('click',settings);$$('[data-minutes]').forEach(b=>b.addEventListener('click',()=>setMinutes(Number(b.dataset.minutes))));
 $$('[data-tab]').forEach(b=>b.addEventListener('click',()=>tab(b.dataset.tab)));$$('[data-tabgoto]').forEach(b=>b.addEventListener('click',()=>tab(b.dataset.tabgoto)));$$('[data-nav]').forEach(b=>b.addEventListener('click',()=>tab(b.dataset.nav)));
 $$('[data-area]').forEach(b=>b.addEventListener('click',()=>{const v=b.dataset.area;if(v==='今日應處理')tab('list');else openTool({'照會／異動':'dir:records','人力承接':'dir:caregivers','工具箱':'all'}[v]);}));
 $('#menu').addEventListener('click',()=>openTool('all'));$('#addTodo').addEventListener('click',()=>openTask());$('#search').addEventListener('input',render);
 document.addEventListener('click',e=>{const edit=e.target.closest('[data-edit]'),day=e.target.closest('[data-day]'),shift=e.target.closest('[data-shift]'),month=e.target.closest('[data-month]');if(edit)openTask(edit.dataset.edit);if(e.target.closest('[data-add-task]'))openTask();if(day){selected=day.dataset.day;render();}if(shift){const d=new Date(selected+'T12:00:00');d.setDate(d.getDate()+Number(shift.dataset.shift));selected=dayKey(d);render()}if(month){const d=new Date(selected+'T12:00:00');d.setDate(1);d.setMonth(d.getMonth()+Number(month.dataset.month));selected=dayKey(d);render()}if(e.target.closest('[data-today]')){selected=dayKey(new Date());render()}});
 document.addEventListener('change',e=>{if(e.target.id==='viewDate'&&e.target.value){selected=e.target.value;render();}if(e.target.hasAttribute('data-check')){const t=tasks.find(t=>String(t.id)===e.target.dataset.check&&t.date===selected);if(t){t.done=e.target.checked;try{tasks=window.yhnPlanBridge.save(tasks);render();}catch{announce('儲存失敗，請先備份資料');}}}});
 window.addEventListener('storage',e=>{if(e.key==='yhn_supervisor_daily_plans_v1')load();});window.addEventListener('focus',()=>{try{const next=window.yhnPlanBridge.load();if(JSON.stringify(next)!==JSON.stringify(tasks)){tasks=next;render()}}catch{announce('待辦資料無法讀取，請稍後重試')}});
 let editingTask=null;
 function openTask(id){const task=tasks.find(t=>String(t.id)===String(id));editingTask=task?.id||null;$('#taskEditorTitle').textContent=task?'編輯工作':'新增工作';const form=$('#directTaskForm');form.reset();form.elements.title.value=task?.title||'';form.elements.note.value=task?.note||'';form.elements.date.value=task?.date||selected;form.elements.start.value=task?.start||'09:00';form.elements.end.value=task?.end||'09:30';form.elements.status.value=task?.done?'已完成':task?.status||'未開始';$('#taskEditorError').textContent='';$('#directTaskDialog').showModal();}
 $('#directTaskForm').addEventListener('submit',event=>{event.preventDefault();const form=event.currentTarget;const values=Object.fromEntries(new FormData(form));if(!values.title.trim()||!values.date||values.end<=values.start){$('#taskEditorError').textContent='請填寫工作名稱，結束時間須晚於開始時間。';return}const previous=tasks,existing=tasks.find(t=>t.id===editingTask),value={...existing,...values,title:values.title.trim(),id:existing?.id||'task-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2),done:values.status==='已完成',period:values.start<'12:00'?'morning':values.start<'18:00'?'afternoon':'evening',category:existing?.category||'行政工作',priority:existing?.priority||'normal'};tasks=existing?tasks.map(t=>t.id===existing.id?value:t):[...tasks,value];try{tasks=window.yhnPlanBridge.save(tasks);selected=value.date;$('#directTaskDialog').close();render();announce('工作已儲存')}catch{tasks=previous;$('#taskEditorError').textContent='儲存失敗，輸入內容已保留，請重試。'}});
 document.querySelectorAll('[data-close-task]').forEach(button=>button.addEventListener('click',()=>$('#directTaskDialog').close()));
 window.addEventListener('message',event=>{if(event.origin!==location.origin||event.source!==parent)return;if(event.data?.type==='yhn:add-task')openTask()});
 const initialView=new URLSearchParams(location.search).get('view');if(['board','list','table'].includes(initialView))tab(initialView);
 load();if(new URLSearchParams(location.search).has('add'))openTask();
 function readCloud(){if(parent!==window)fetch('/api/director',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'read'})}).then(r=>r.ok?r.json():Promise.reject()).then(d=>{cloud={cases:Array.isArray(d.cases)?d.cases:[]};render();}).catch(()=>{$('#countCases').textContent='—';});}
 window.addEventListener('message',event=>{if(event.origin===location.origin&&event.source===parent&&event.data?.type==='yhn:dashboard-active'){load();readCloud();}});readCloud();
})();
