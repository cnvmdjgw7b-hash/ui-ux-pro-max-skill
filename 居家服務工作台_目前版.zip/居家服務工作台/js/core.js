const $ = (id) => document.getElementById(id);
let lastVisitSections = {};


