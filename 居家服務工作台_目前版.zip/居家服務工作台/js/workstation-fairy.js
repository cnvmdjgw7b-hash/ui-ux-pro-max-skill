(() => {
'use strict';
const $=id=>document.getElementById(id);
const guides={home:['先看現在要處理的事','首頁集中顯示照會、異動與需要跟進的工作。'],records:['照會／異動分三區處理','A區保留原始資料，B區人工複核與班表佐證，異常才接續C區督導作業。'],caregivers:['先看適配，再看班量','真正卡在人力時，再依區域、時段、能力與限制找可承接人員。'],supervisors:['追到實際落實','確認督導已完成的處理與佐證，再做複核。']};
let step=-1,target=null,previousFocus=null,dragState=null,ignoreNextClick=false;
const PET_KEY='yhn-workstation-pet-v1';
function petPrefs(){try{return JSON.parse(localStorage.getItem(PET_KEY)||'{}')}catch{return {}}}
function petSave(v){try{localStorage.setItem(PET_KEY,JSON.stringify({...petPrefs(),...v}))}catch{}}
function petAction(action){const c=$('fairyToggle');if(!c)return;c.dataset.pose=action;c.classList.remove('pet-lick','pet-lie','pet-wave');void c.offsetWidth;c.classList.add(action==='lick'?'pet-lick':action==='lie'?'pet-lie':'pet-wave');const words={lick:'呼嚕～舔舔手手，再陪你工作。',lie:'我先躺一下，點我就能繼續操作。',wave:'喵～今天的工作一起慢慢完成！'};message(words[action]||words.wave);if(action!=='lie')setTimeout(()=>c.classList.remove('pet-lick','pet-wave'),1900);}
const steps=[
 ['#yhnSidebar [data-open-tool="visitTool"]','家訪紀錄','填寫訪視評估與紀錄。'],
 ['#yhnSidebar [data-open-tool="phoneAssistTool"]','電訪紀錄','填寫電話聯繫內容並預覽紀錄。'],
 ['#yhnSidebar [data-open-tool="mutationTool"]','異動通報','填寫服務異動並生成通報文字。'],
 ['#yhnSidebar [data-open-tool="yhnCarePlanTool"]','照顧計畫','整理照顧需求、目標與服務計畫。'],
];
function message(text){$('fairyMessage').textContent=text;}
function clear(){target?.classList.remove('fairy-target');target=null;}
function context(){clear();step=-1;const state=window.YhnDirector?.helpState();const info=guides[state?.view]||guides.home;$('fairyHeading').textContent=info[0];message(info[1]);$('fairyTour').hidden=true;}
function fitPanel(){if(matchMedia('(max-width:760px)').matches)return;const root=$('workstationFairy'),panel=$('fairyPanel');if(!root||!panel)return;const rect=root.getBoundingClientRect(),maxLeft=Math.max(6,innerWidth-panel.getBoundingClientRect().width-6),left=Math.max(6,Math.min(rect.left,maxLeft));root.style.left=left+'px';root.style.right='auto';petSave({x:left,y:rect.top});}
function show(){petSave({hidden:false});$('workstationFairy').hidden=false;previousFocus=document.activeElement;$('fairyPanel').hidden=false;$('fairyToggle').setAttribute('aria-expanded','true');requestAnimationFrame(fitPanel);context();$('fairyClose').focus();}
function close(){clear();step=-1;$('fairyPanel').hidden=true;$('fairyToggle').setAttribute('aria-expanded','false');previousFocus?.focus();}
function tour(){clear();if(step>=steps.length){context();message('導覽完成。可直接使用下方快捷工具開始處理。');return;}const [selector,title,text]=steps[step];target=document.querySelector('#directorTabs '+selector)||document.querySelector('#yhnSidebar '+selector);if(target){target.classList.add('fairy-target');target.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'nearest'});}$('fairyHeading').textContent=(step+1)+'／'+steps.length+' '+title;message(text);$('fairyTour').hidden=false;$('fairyNext').textContent=step===steps.length-1?'完成導覽':'下一步';}
function petBounds(){const toggle=$('fairyToggle'),nav=document.querySelector('.mobile-bottom-nav'),mobile=matchMedia('(max-width:760px)').matches;const navHeight=mobile&&nav?nav.getBoundingClientRect().height:0;return {maxX:Math.max(6,innerWidth-toggle.offsetWidth-6),maxY:Math.max(6,innerHeight-toggle.offsetHeight-navHeight-(mobile?10:6))};}
function placePet(x,y){const bounds=petBounds();x=Math.max(6,Math.min(bounds.maxX,x));y=Math.max(6,Math.min(bounds.maxY,y));Object.assign($('workstationFairy').style,{left:x+'px',top:y+'px',right:'auto',bottom:'auto'});return {x,y};}
async function quick(action){clear();step=-1;$('fairyTour').hidden=true;
 if(action==='find'){const button=$('casePickerOpen');if(!button){message('個案名冊尚未就緒，請重新整理。');return;}close();button.click();return;}
 if(action==='template'){const text='【處理事項】\n卡在哪裡：\n下一步：\n負責人：\n截止日：\n完成佐證：';$('fairyTemplate').hidden=false;$('fairyTemplate').value=text;try{await navigator.clipboard.writeText(text);message('已複製交辦範本，補上實際內容即可使用。');}catch{message('可從下方選取並複製交辦範本。');$('fairyTemplate').select();}return;}
 const result=window.YhnDirector?.quick(action);if(!result?.ok){message(result?.message||'工具尚未就緒，請稍後再試。');return;}
 if(action.startsWith('new:')){close();return;}
 message(action==='focus'?'番茄專注已開始，可在首頁暫停或重設。':'已開啟指定工作區，請依畫面處理。');}
function initFairy(){
 if($('workstationFairy'))return;
 const root=document.createElement('aside');root.id='workstationFairy';root.setAttribute('aria-label','工作站小精靈');root.innerHTML=`<section id="fairyPanel" hidden aria-label="小精靈操作幫手"><header><span>🐾 虎斑貓小精靈</span><button id="fairyClose" type="button" aria-label="收起小精靈">×</button></header><div class="fairy-pet-actions"><button type="button" data-pet-action="lick">舔舔手</button><button type="button" data-pet-action="lie">躺一下</button><button type="button" data-pet-action="wave">揮揮手</button><button type="button" data-fairy-hide>暫時隱藏</button></div><h3 id="fairyHeading"></h3><p id="fairyMessage" role="status" aria-live="polite"></p><div id="fairyTour" hidden><button id="fairyPrev" type="button">上一步</button><button id="fairyNext" type="button">下一步</button><button id="fairyEnd" type="button">結束導覽</button></div><div class="fairy-options"><button type="button" data-fairy="explain">這頁怎麼用</button><button type="button" data-fairy="tour">帶我走一遍</button></div><h4>快速處理</h4><div class="fairy-tools">${[['queue:today','今日待辦'],['queue:director','待主任確認'],['queue:supervisor','待督導完成'],['queue:admin','待行政複核'],['find','找個案名冊'],['new:case','新增案件'],['new:照會','新增照會'],['new:異動','新增異動'],['new:caregiver','新增人力'],['calendar','查看期限'],['focus','開始專注'],['template','複製交辦範本']].map(([a,l])=>'<button type="button" data-fairy-quick="'+a+'">'+l+'</button>').join('')}</div><textarea id="fairyTemplate" hidden readonly aria-label="交辦範本" rows="6"></textarea><small>電腦版：點右下角小精靈，按「這頁怎麼用」或「帶我走一遍」；也可拖曳小精靈避開工作內容。快捷工具會開啟原有流程，填寫後請自行確認儲存。</small></section><button id="fairyToggle" type="button" aria-label="開啟貓咪小精靈與操作幫手" aria-controls="fairyPanel" aria-expanded="false"><img id="fairyCat" src="workstation-pet.png" alt="虎斑貓小精靈" draggable="false"><span id="fairyGlyph" aria-hidden="true" hidden></span><span id="fairyLabel">小幫手</span></button>`;document.body.append(root);
 const prefs=petPrefs();if(prefs.hidden)$('workstationFairy').hidden=true;if(Number.isFinite(prefs.x)&&Number.isFinite(prefs.y))placePet(prefs.x,prefs.y);
 const toggle=$('fairyToggle');toggle.addEventListener('pointerdown',e=>{if(e.button!==0&&e.pointerType==='mouse')return;const r=toggle.getBoundingClientRect();dragState={id:e.pointerId,sx:e.clientX,sy:e.clientY,left:r.left,top:r.top,moved:false};toggle.setPointerCapture(e.pointerId);});toggle.addEventListener('pointermove',e=>{if(!dragState||dragState.id!==e.pointerId)return;const dx=e.clientX-dragState.sx,dy=e.clientY-dragState.sy;if(Math.abs(dx)+Math.abs(dy)>8)dragState.moved=true;if(dragState.moved)placePet(dragState.left+dx,dragState.top+dy);});toggle.addEventListener('pointerup',e=>{if(!dragState||dragState.id!==e.pointerId)return;if(dragState.moved){const r=$('workstationFairy').getBoundingClientRect();petSave({x:r.left,y:r.top});ignoreNextClick=true;setTimeout(()=>ignoreNextClick=false,350);}dragState=null;});toggle.onclick=()=>{if(ignoreNextClick){ignoreNextClick=false;return;}$('fairyPanel').hidden?show():close();};$('fairyClose').onclick=close;
 window.addEventListener('resize',()=>{const r=$('workstationFairy').getBoundingClientRect();if(r.width&&r.height){const p=placePet(r.left,r.top);petSave(p);}});
 root.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;if(b.hasAttribute('data-fairy-hide')){close();$('workstationFairy').hidden=true;petSave({hidden:true});return;}if(b.dataset.petAction){petAction(b.dataset.petAction);return;}if(b.dataset.fairy==='explain')context();if(b.dataset.fairy==='tour'){step=0;tour();}if(b.dataset.fairyQuick)quick(b.dataset.fairyQuick);});
 $('fairyNext').onclick=()=>{step++;tour();};$('fairyPrev').onclick=()=>{step=Math.max(0,step-1);tour();};$('fairyEnd').onclick=context;
 root.addEventListener('keydown',e=>{if(e.key==='Escape'){e.stopPropagation();close();}});
 document.addEventListener('click',e=>{if(e.target.closest('[data-fairy-open]'))show();if(e.target.closest('[data-pet-show]')){petSave({hidden:false});$('workstationFairy').hidden=false;close();}if(e.target.closest('[data-pet-hide]')){close();$('workstationFairy').hidden=true;petSave({hidden:true});}if(e.target.closest('[data-pet-reset]')){$('workstationFairy').style.cssText='';petSave({x:null,y:null});}});
 window.YhnFairy={open:show,close};
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initFairy,{once:true});else initFairy();
})();
