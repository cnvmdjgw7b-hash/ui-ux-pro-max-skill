(function () {
  'use strict';

  const PROFILE_KEY = 'yhn_ltcnotes_profile_v1';
  const PLAN_KEY = 'yhn_care_plan_draft_v1';

  const $ = (id) => document.getElementById(id);
  const value = (id) => ($(id)?.value || '').trim();
  const escapeHtml = (input) => String(input || '')
    .replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;').replaceAll("'", '&#039;');
  const multiline = (input) => escapeHtml(input || '—').replaceAll('\n', '<br>');
  const today = () => new Date().toISOString().slice(0, 10);

  function readJson(key, fallback) {
    try { return JSON.parse(localStorage.getItem(key) || '') || fallback; } catch (_) { return fallback; }
  }

  function profile() { return readJson(PROFILE_KEY, {}); }

  function collect(ids) {
    return ids.reduce((result, id) => {
      const element = $(id);
      if (element) result[id] = element.value;
      return result;
    }, {});
  }

  function restore(key, ids) {
    const data = readJson(key, {});
    ids.forEach((id) => { if ($(id) && data[id] != null) $(id).value = data[id]; });
  }

  function saveDraft(key, ids, statusText) {
    localStorage.setItem(key, JSON.stringify(collect(ids)));
    window.alert(statusText);
  }

  function documentShell(title, meta, rows, sections) {
    return '<header class="yhn-doc-header"><img src="logo.png" alt=""><div><small>永護寧居家長照機構</small><h1>' + escapeHtml(title) + '</h1></div></header>' +
      '<div class="yhn-doc-meta">' + meta.map((item) => '<div><b>' + escapeHtml(item[0]) + '</b><span>' + escapeHtml(item[1] || '—') + '</span></div>').join('') + '</div>' +
      (rows || []).map((row) => '<p class="yhn-doc-line"><b>' + escapeHtml(row[0]) + '：</b>' + multiline(row[1]) + '</p>').join('') +
      sections.map((section) => '<section><h2>' + escapeHtml(section[0]) + '</h2><div>' + multiline(section[1]) + '</div></section>').join('') +
      '<footer>本表內容應依實際訪視、核定資料及機構規範確認後使用。</footer>';
  }

  const planIds = ['yhnPlanClient','yhnPlanCaseNo','yhnPlanCms','yhnPlanDate','yhnPlanWorker','yhnPlanInstitution','yhnPlanAssessment','yhnPlanGoals','yhnPlanServices','yhnPlanSchedule','yhnPlanRisk','yhnPlanReview'];

  function renderPlan() {
    const target = $('yhnCarePlanPreview');
    if (!target) return;
    target.innerHTML = documentShell('照顧計畫', [
      ['個案姓名', value('yhnPlanClient')], ['案號', value('yhnPlanCaseNo')],
      ['CMS 等級', value('yhnPlanCms')], ['生效日', value('yhnPlanDate')],
      ['計畫擬定人', value('yhnPlanWorker')], ['機構', value('yhnPlanInstitution')]
    ], [], [
      ['一、需求評估摘要', value('yhnPlanAssessment')], ['二、照顧目標', value('yhnPlanGoals')],
      ['三、核定／預計服務項目', value('yhnPlanServices')], ['四、服務排程與注意事項', value('yhnPlanSchedule')],
      ['五、風險管理與緊急處置', value('yhnPlanRisk')], ['六、追蹤與檢討方式', value('yhnPlanReview')]
    ]);
  }

  function printDocument(kind) {
    document.body.classList.add(kind);
    window.print();
    setTimeout(() => document.body.classList.remove(kind), 500);
  }

  function seedForms() {
    const p = profile();
    if ($('yhnPlanDate') && !$('yhnPlanDate').value) $('yhnPlanDate').value = today();
    if ($('yhnPlanWorker') && !$('yhnPlanWorker').value) $('yhnPlanWorker').value = p.name || '';
    if (p.institution) {
      if ($('yhnPlanInstitution')) $('yhnPlanInstitution').value = p.institution;
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    restore(PLAN_KEY, planIds);
    seedForms();
    renderPlan();

    $('yhnPlanPreviewBtn')?.addEventListener('click', renderPlan);
    $('yhnPlanSaveBtn')?.addEventListener('click', () => saveDraft(PLAN_KEY, planIds, '照顧計畫草稿已儲存在目前裝置。'));
    $('yhnPlanPrintBtn')?.addEventListener('click', () => { if (!$('yhnCarePlanPreview')?.textContent.trim()) renderPlan(); printDocument('printing-yhn-plan'); });


  });
})();
