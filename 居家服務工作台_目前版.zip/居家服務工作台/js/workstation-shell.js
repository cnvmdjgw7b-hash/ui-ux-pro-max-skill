(() => {
 'use strict';
 const $=id=>document.getElementById(id);
 const scrolls=new Map();let current='home';
 function showPlatform(view){window.YhnDirector?.open(view)}
 function homeView(view){document.querySelector('[data-yhn-home]')?.click();document.body.dataset.workView=view;current=view;$('activeToolTitle').textContent={home:'首頁／今日待辦',worklog:'工作日誌',schedule:'排班與服務',analytics:'統計分析'}[view]||'首頁';$('toolHome').scrollTop=scrolls.get(view)||0}
 window.addEventListener('load',()=>setTimeout(()=>{
  const nav=document.querySelector('#yhnSidebar nav');if(!nav)return;
  document.querySelector('.yhn-nav-heading')?.remove();
  const categories=[
   ['個案紀錄',[['open','visitTool'],['open','phoneAssistTool'],['open','caseReportsTool']]],
   ['照顧支持',[['open','yhnCarePlanTool'],['open','companionTool']]],
   ['額度與申報',[['open','quotaTool'],['open','codeTool']]],
    ['異動通報與法規',[['open','mutationTool'],['open','renewalTool'],['link','law/']]],
  ];
  const groups=[];
  categories.forEach(([label,items],index)=>{
   const details=document.createElement('details');details.className='shell-group';details.open=index===0;
   const summary=document.createElement('summary');summary.textContent=label;details.append(summary);
   items.forEach(([type,id])=>{
    let node;
    if(type==='view')node=nav.querySelector(`[data-dir-view="${id}"]`);
    else if(type==='open')node=nav.querySelector(`[data-open-tool="${id}"]`);
    else if(type==='link')node=nav.querySelector(`a[href="${id}"]`);
    if(!node)return;
    if(node.matches('button,a')){node.title=node.textContent.trim();node.setAttribute('aria-label',node.title)}
    details.append(node);
   });
   groups.push(details);nav.append(details);
  });
  nav.addEventListener('click',e=>{const b=e.target.closest('[data-open-tool],[data-yhn-home]');if(!b||b.tagName==='A')return;scrolls.set(current,$('toolModalContainer').scrollTop||$('toolHome').scrollTop);document.body.dataset.workView='home';current=b.dataset.openTool||'home';requestAnimationFrame(()=>{$('toolModalContainer').scrollTop=scrolls.get(current)||0;nav.querySelectorAll('.shell-group').forEach(d=>{d.classList.toggle('has-current',!!d.querySelector('.is-current'));if(d.classList.contains('has-current'))d.open=true})})});
  new ResizeObserver(entries=>{document.documentElement.style.setProperty('--shell-top',Math.ceil(entries[0].target.getBoundingClientRect().height)+'px')}).observe(document.querySelector('.workstation-nav'));
  const input=$('dashboardSearch'),results=document.createElement('div');results.className='shell-search-results';results.hidden=true;input.parentElement.append(results);
  input.addEventListener('input',()=>{results.replaceChildren();const q=input.value.trim();if(!q){results.hidden=true;return}Array.from(nav.querySelectorAll('button,a')).filter(n=>n.textContent.includes(q)).slice(0,8).forEach(n=>{const b=document.createElement('button');b.type='button';b.textContent=n.textContent.trim();b.addEventListener('click',()=>{n.click();results.hidden=true});results.append(b)});results.hidden=!results.children.length});
  document.addEventListener('click',e=>{if(!input.parentElement.contains(e.target))results.hidden=true});
  document.querySelector('.yhn-nav-home small').textContent='首頁／今日待辦';document.body.dataset.workView='home';
 },0));
})();
