(() => {
  'use strict';
  const KEY='yhn_supervisor_daily_plans_v1';
  let baseline=[];
  const read=()=>{const value=JSON.parse(localStorage.getItem(KEY)||'{}');if(!value||typeof value!=='object'||Array.isArray(value))throw Error('無效工作資料');return value;};
  function load(){
    const plans=read(),tasks=[];
    for(const [date,day] of Object.entries(plans))for(const task of day.tasks||[])tasks.push({...task,date,period:task.period||(String(task.start||'09:00')<'12:00'?'morning':String(task.start||'09:00')<'18:00'?'afternoon':'evening'),priority:task.priority==='重要'?'high':task.priority==='次要'?'low':'normal',done:task.status==='已完成'});
    baseline=structuredClone(tasks);return tasks;
  }
  function save(tasks){
    const plans=read();
    const before=new Map(baseline.map(t=>[t.date+'|'+t.id,t]));
    const after=new Map(tasks.map(t=>[t.date+'|'+t.id,t]));
    // Only apply this page's changed records; retain concurrent work and all day metadata.
    for(const [key,old] of before)if(!after.has(key)){
      const day=plans[old.date];if(day)day.tasks=(day.tasks||[]).filter(t=>String(t.id)!==String(old.id));
    }
    for(const [key,task] of after){
      const old=before.get(key);if(old&&JSON.stringify(old)===JSON.stringify(task))continue;
      const day=plans[task.date]||{focus:'',tasks:[],reflection:'',tomorrow:['','',''],habitDone:[]};
      const list=day.tasks||[],index=list.findIndex(t=>String(t.id)===String(task.id));
      const {date,done,demo,...body}=task;
      const saved={...(index>=0?list[index]:{}),...body,priority:task.priority==='high'?'重要':task.priority==='low'?'次要':'一般',status:done?'已完成':old?.done?'未開始':task.status||'未開始'};
      if(index>=0)list[index]=saved;else list.push(saved);day.tasks=list;plans[task.date]=day;
    }
    localStorage.setItem(KEY,JSON.stringify(plans));return load();
  }
  window.yhnPlanBridge={load,save};
})();
