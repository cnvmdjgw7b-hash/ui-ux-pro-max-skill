(() => {
  'use strict';
  const safe = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const tone = value => {
    const text = String(value || '').toLowerCase();
    if (/回覆|電話|追蹤/.test(text)) return 'green';
    if (/異動|通報|變更/.test(text)) return 'pink';
    if (/送件|送交|公所/.test(text)) return 'purple';
    if (/附約|期限|契約/.test(text)) return 'violet';
    if (/家訪|電訪|訪視/.test(text)) return 'teal';
    return 'blue';
  };
  const keyDate = date => [date.getFullYear(), String(date.getMonth()+1).padStart(2,'0'), String(date.getDate()).padStart(2,'0')].join('-');
  const atNoon = key => new Date(`${key}T12:00:00`);
  const weekday = key => '日一二三四五六'[atNoon(key).getDay()];
  const dateLabel = key => `${atNoon(key).getFullYear()}年${atNoon(key).getMonth()+1}月${atNoon(key).getDate()}日（週${weekday(key)}）`;
  const sorted = tasks => [...tasks].sort((a,b) => `${a.date} ${a.time||'99:99'}`.localeCompare(`${b.date} ${b.time||'99:99'}`));
  const summary = items => {
    const counts = new Map();
    items.forEach(task => counts.set(task.category || '其他', (counts.get(task.category || '其他') || 0) + 1));
    if (!counts.size) return '<div class="calendar-summary-empty">本月尚無行程</div>';
    return `<div class="calendar-summary-grid">${[...counts].sort((a,b)=>b[1]-a[1]).map(([category,count])=>`<button type="button" class="calendar-summary-card tone-${tone(category)}" data-category-shortcut="${safe(category)}"><span class="calendar-summary-dot"></span><b>${safe(category)}</b><strong>${count}</strong></button>`).join('')}</div>`;
  };
  const card = (task, timeLabel = task.time || '全天', compact = false) => {
    const color = tone(task.category), done = task.status === '已完成';
    return `<article class="calendar-task-card tone-${color} ${done?'is-done':''} ${compact?'is-compact':''}"><div class="calendar-task-main"><button class="calendar-task-check" type="button" data-mark="${safe(task.id)}" aria-label="${done?'標記未完成':'勾選完成'}：${safe(task.title)}">${done?'✓':'○'}</button><div class="calendar-task-copy"><div class="calendar-task-top"><span class="calendar-category-tag tone-${color}">${safe(task.category||'其他')}</span><span class="calendar-task-time">${safe(timeLabel)}</span></div><button type="button" class="calendar-task-title" data-detail="${safe(task.id)}">${safe(task.title)}</button><div class="calendar-task-meta">${safe(task.person||'未指定')}${task.note?`<span>・${safe(task.note)}</span>`:''}</div></div></div><div class="calendar-task-actions"><button type="button" data-edit="${safe(task.id)}">編輯</button><button type="button" data-delete="${safe(task.id)}">刪除</button></div></article>`;
  };
  function render({tasks, mode, date, cursor, query='', category='all', expandedDate='', agendaExpanded=false}) {
    const year=cursor.getFullYear(), month=cursor.getMonth(), monthKey=`${year}-${String(month+1).padStart(2,'0')}`;
    const matches=sorted(tasks.filter(t=>(!query||[t.title,t.category,t.person,t.note].join(' ').toLowerCase().includes(query.toLowerCase()))&&(category==='all'||t.category===category)));
    const monthItems=matches.filter(t=>String(t.date||'').startsWith(monthKey)), selected=matches.filter(t=>t.date===date);
    const weekFirst=atNoon(date); weekFirst.setDate(weekFirst.getDate()-weekFirst.getDay());
    const weekLast=new Date(weekFirst); weekLast.setDate(weekLast.getDate()+6);
    let title=`${year} 年 ${month+1} 月`;
    if(mode==='day') title=dateLabel(date);
    if(mode==='week') title=`${keyDate(weekFirst).replaceAll('-','/')}－${keyDate(weekLast).replaceAll('-','/')}`;
    if(mode==='year') title=`${year} 年`;
    if(mode==='table') title=`${year} 年 ${month+1} 月行程`;
    let html='';
    if(mode==='month'||mode==='agenda') {
      const first=new Date(year,month,1),offset=first.getDay(),days=new Date(year,month+1,0).getDate();
      html='<div class="calendar-month-grid" role="grid" aria-label="月行事曆"><div class="calendar-weekdays">'+['日','一','二','三','四','五','六'].map(x=>`<span>${x}</span>`).join('')+'</div>';
      for(let i=0;i<42;i++) {
        const d=new Date(year,month,1-offset+i),key=keyDate(d),items=matches.filter(t=>t.date===key),outside=d.getMonth()!==month,expanded=expandedDate===key,preview=expanded?items:items.slice(0,2);
        html+=`<section class="calendar-month-cell ${outside?'is-outside':''} ${date===key?'is-selected':''}"><button type="button" class="calendar-day-select" data-day="${key}" aria-label="${dateLabel(key)}，${items.length} 項行程"><strong>${d.getDate()}</strong>${items.length?`<span>${items.length}項</span>`:''}</button><div class="calendar-day-dots" aria-hidden="true">${[...new Set(items.map(t=>tone(t.category)))].slice(0,5).map(color=>`<i class="tone-${color}"></i>`).join('')}</div>${items.length?`<div class="calendar-day-preview">${preview.map(t=>`<button type="button" class="calendar-mini-event tone-${tone(t.category)}" data-detail="${safe(t.id)}"><span>${safe(t.time||'全天')}</span>${safe(t.title)}</button>`).join('')}</div>`:''}${items.length>2?`<button type="button" class="calendar-more" data-expand-day="${key}" aria-expanded="${expanded}">${expanded?'收合':`另 ${items.length-2} 項`}</button>`:''}</section>`;
      }
      html+='</div>';
      if(mode==='agenda') html+=selectedAgenda(selected,date,agendaExpanded);
    } else if(mode==='day') {
      html=`<div class="calendar-day-view">${selectedAgenda(selected,date,agendaExpanded)}</div>`;
    } else if(mode==='week') {
      const start=keyDate(weekFirst),dates=Array.from({length:7},(_,i)=>{const d=atNoon(start);d.setDate(d.getDate()+i);return keyDate(d)});
      html=`<div class="calendar-week-scroll"><div class="calendar-week-grid"><div class="calendar-week-spacer"></div>${dates.map(key=>`<button type="button" class="calendar-week-head ${key===date?'is-current':''}" data-day="${key}"><small>週${weekday(key)}</small><strong>${atNoon(key).getDate()}</strong><span>${matches.filter(t=>t.date===key).length}項</span></button>`).join('')}${Array.from({length:15},(_,h)=>{const hour=String(h+7).padStart(2,'0')+':00';return `<span class="calendar-week-hour">${hour}</span>${dates.map(key=>{const items=matches.filter(t=>t.date===key&&t.time?.slice(0,2)===String(h+7).padStart(2,'0'));return `<div class="calendar-week-slot" data-day="${key}">${items.map(t=>`<article class="calendar-week-event-card tone-${tone(t.category)}"><button type="button" class="calendar-week-event-title" data-detail="${safe(t.id)}">${safe(t.category)}｜${safe(t.title)}</button><div><button type="button" data-mark="${safe(t.id)}" aria-label="${t.status==='已完成'?'取消完成':'勾選完成'}">${t.status==='已完成'?'✓':'○'}</button><button type="button" data-edit="${safe(t.id)}" aria-label="編輯行程">✎</button><button type="button" data-delete="${safe(t.id)}" aria-label="刪除行程">×</button></div></article>`).join('')}</div>`}).join('')}`}).join('')}</div></div><p class="calendar-scroll-hint">手機可左右滑動查看完整週行程</p>`;
    } else if(mode==='table') {
      html=`<div class="calendar-table-wrap"><table class="calendar-table"><thead><tr><th>日期</th><th>時間</th><th>類型</th><th>行程</th><th>負責人</th><th>狀態</th><th>操作</th></tr></thead><tbody>${monthItems.length?monthItems.map(t=>`<tr><td>${safe(String(t.date||'').slice(5).replace('-','/'))}</td><td>${safe(t.time||'全天')}</td><td><span class="calendar-category-tag tone-${tone(t.category)}">${safe(t.category||'其他')}</span></td><td>${safe(t.title)}${t.note?`<small>${safe(t.note)}</small>`:''}</td><td>${safe(t.person||'未指定')}</td><td><button type="button" class="calendar-status ${t.status==='已完成'?'is-done':''}" data-mark="${safe(t.id)}">${t.status==='已完成'?'已完成':'待處理'}</button></td><td><div class="calendar-table-actions"><button type="button" data-edit="${safe(t.id)}">編輯</button><button type="button" data-delete="${safe(t.id)}">刪除</button></div></td></tr>`).join(''):'<tr><td colspan="7" class="blank">這個月份沒有符合條件的行程。</td></tr>'}</tbody></table></div>`;
    } else if(mode==='year') {
      html=`<div class="calendar-year-grid">${Array.from({length:12},(_,m)=>{const first=new Date(year,m,1),offset=first.getDay(),days=new Date(year,m+1,0).getDate(),items=matches.filter(t=>String(t.date||'').startsWith(`${year}-${String(m+1).padStart(2,'0')}`));let cells='';for(let i=0;i<42;i++){const n=i-offset+1,has=items.some(t=>Number(String(t.date).slice(8))===n);cells+=n>0&&n<=days?`<i class="${has?'has-event':''}">${n}</i>`:'<i class="is-empty"></i>'}return `<button type="button" class="calendar-year-month ${m===month?'is-current':''}" data-year-month="${m+1}"><strong>${m+1}月</strong><span class="calendar-year-weekdays">日一二三四五六</span><span class="calendar-year-days">${cells}</span><small>${items.length}項行程</small></button>`}).join('')}</div>`;
    }
    return {title,html,summary:mode==='month'?summary(monthItems):'',selectedCount:selected.length,categoryOptions:[...new Set(tasks.map(t=>t.category).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'zh-Hant'))};
  }
  function selectedAgenda(items,date,expanded){const visible=expanded?items:items.slice(0,4);return `<section class="calendar-selected-agenda"><div class="calendar-selected-heading"><h3>${dateLabel(date)}</h3><strong>共 ${items.length} 項</strong></div>${items.length?visible.map(t=>card(t)).join(''):'<div class="blank">當日尚無行程，可直接新增。</div>'}${items.length>4?`<button type="button" class="calendar-agenda-more" data-calendar-expand-agenda="true" aria-expanded="${expanded}">${expanded?'收合行程':`展開全部 ${items.length} 項行程`}</button>`:''}</section>`}
  window.yhnWorkCalendarUI={render,tone,keyDate};
})();
