/* Move existing phone and care plan controls instead of cloning forms. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.YhnDocumentForms=api})(typeof window==='object'?window:globalThis,function(){
'use strict';
const targets={'電話訪視紀錄':'phoneAssistTool','照護計畫':'yhnCarePlanTool'};
const simple={'個別督導紀錄':[['姓名','受督導者'],['日期','督導日期','date'],['督導者','督導者'],['內容','討論與指導內容','textarea'],['追蹤','處理決議／追蹤事項','textarea']],'居服員查核表':[['姓名','居服員姓名'],['日期','查核日期','date'],['查核者','查核者'],['內容','查核項目','textarea'],['結果','查核結果','textarea'],['追蹤','改善及追蹤','textarea']],'緊急申請單':[['姓名','個案姓名'],['日期','申請日期','date'],['申請人','申請人'],['原因','緊急原因','textarea'],['事項','申請事項','textarea'],['聯絡方式','聯絡方式']]};
function fillControls(find,fields,{touched=new Set(),eventFactory=()=>new Event('input',{bubbles:true})}={}){const applied=[],skipped=[];for(const [key,value]of Object.entries(fields)){const input=find(key);if(!input||touched.has(key)||(input.type==='checkbox'?input.checked:String(input.value||'').trim())){skipped.push(key);continue}if(input.type==='checkbox'){if(typeof value!=='boolean'){skipped.push(key);continue}input.checked=value;input.dispatchEvent(eventFactory('input'));input.dispatchEvent(eventFactory('change'));applied.push(key);continue}if(input.tagName==='SELECT'&&![...input.options].some(o=>o.value===String(value))){skipped.push(key);continue}const before=input.value;input.value=value;if(input.type==='date'&&input.value!==value){input.value=before;skipped.push(key);continue}input.dispatchEvent(eventFactory('input'));input.dispatchEvent(eventFactory('change'));applied.push(key)}return {applied,skipped}}
function mount(host,parsed){
 const doc=host.ownerDocument,touched=new Set(),section=doc.createElement('section');section.className='ocr-linked-form';const heading=doc.createElement('h4');heading.textContent=parsed.type+'｜可編輯欄位';section.append(heading);host.append(section);let placeholder,original,originalHidden,originalStyle;
 const mark=e=>{const key=e.target.dataset.ocrDocumentKey||e.target.id;if(key)touched.add(key)};section.addEventListener('input',mark);let find;
 if(simple[parsed.type]){
  for(const [key,label,type='text']of simple[parsed.type]){const l=doc.createElement('label');l.textContent=label;const input=doc.createElement(type==='textarea'?'textarea':'input');if(type!=='textarea')input.type=type;input.dataset.ocrDocumentKey=key;input.dataset.simpleField='true';l.append(input);section.append(l)}
  find=k=>[...section.querySelectorAll('[data-simple-field]')].find(n=>n.dataset.ocrDocumentKey===k);
  const hint=doc.createElement('p');hint.textContent='此文件尚無雲端儲存對應；可編輯及下載草稿，不會寫成照會／異動案件。';section.append(hint);
  const save=doc.createElement('button');save.type='button';save.textContent='下載可編輯 JSON 草稿（非雲端儲存）';save.onclick=()=>{const fields={};for(const n of section.querySelectorAll('[data-simple-field]'))fields[n.dataset.ocrDocumentKey]=n.value;const blob=new Blob([JSON.stringify({documentType:parsed.type,fields},null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=doc.createElement('a');a.href=url;a.download=parsed.type+'草稿.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),60000)};section.append(save);
 }else{
  const id=targets[parsed.type];original=id&&doc.getElementById(id);if(!original){section.remove();throw Error('找不到此文件的既有表單，未建立替代頁面。')}
  placeholder=doc.createComment('ocr-original-form-position');original.before(placeholder);originalHidden=original.hidden;originalStyle=original.style.display;original.hidden=false;original.style.display='block';section.append(original);
  find=k=>doc.getElementById(k);
  const hint=doc.createElement('p');hint.textContent='以下為原本表單，請人工核對並使用該表單既有操作；不會自動按下儲存。';if(parsed.type==='照護計畫')hint.textContent+=' 服務項目／次數與評值表可直接編輯；無法定位的表格欄位不會推測填入。';heading.after(hint);
 }
 return {type:parsed.type,section,apply:p=>fillControls(find,p.fields,{touched,eventFactory:type=>new Event(type,{bubbles:true})}),dispose(){if(placeholder?.parentNode){placeholder.replaceWith(original);original.hidden=originalHidden;original.style.display=originalStyle}section.remove()}};
}
return {targets,simple,fillControls,mount};
});
