(() => {
  'use strict';
  const KEY='yhn_supervisor_daily_plans_v1';
  const HABIT_KEY='yhn_supervisor_habits_v1';
  const DEFAULT_HABITS=[{id:'food',title:'飲食與喝水'},{id:'movement',title:'活動／伸展'},{id:'sleep',title:'睡眠照顧'},{id:'mood',title:'情緒關照'},{id:'self-care',title:'自我照顧'},{id:'social',title:'社交聯繫'}];
  const $=id=>document.getElementById(id);
  const escapeHtml=value=>String(value||'').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  const localDate=()=>{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`};
  const emptyDay=()=>({focus:'',tasks:[],reflection:'',tomorrow:['','',''],habitDone:[]});
  let plans={};let day=emptyDay();let activeDate='';let currentPage=1;
  try{const saved=JSON.parse(localStorage.getItem(KEY)||'{}');if(saved&&typeof saved==='object'&&!Array.isArray(saved))plans=saved}catch(_){plans={}}
  let habits=DEFAULT_HABITS;
  try{const saved=JSON.parse(localStorage.getItem(HABIT_KEY)||'null');if(Array.isArray(saved))habits=saved.filter(h=>h&&typeof h.id==='string'&&typeof h.title==='string').slice(0,40)}catch(_){habits=DEFAULT_HABITS}
  function saveHabits(){try{localStorage.setItem(HABIT_KEY,JSON.stringify(habits))}catch(_){$('plannerSaveStatus').textContent='裝置儲存空間不足，請匯出備份'}}
  function readFormState(){day.focus=$('plannerFocus').value;day.reflection=$('plannerReflection').value;day.tomorrow=[1,2,3].map(i=>$(`tomorrow${i}`).value)}
  function saveDay(showStatus=true){
    const date=activeDate||$('plannerDate').value;if(!date)return;readFormState();plans[date]=day;
    try{localStorage.setItem(KEY,JSON.stringify(plans));if(showStatus)$('plannerSaveStatus').textContent=`已保存於此裝置 ${new Date().toLocaleTimeString('zh-TW',{hour:'2-digit',minute:'2-digit'})}`}
    catch(_){$('plannerSaveStatus').textContent='裝置儲存空間不足，請匯出 CSV 備份'}
    window.dispatchEvent(new CustomEvent('yhn:plans-updated',{detail:{date}}));
  }
  function loadDay(date){
    activeDate=date;currentPage=1;$('plannerDate').value=date;const data=plans[date];day=data&&typeof data==='object'?{...emptyDay(),...data,tasks:Array.isArray(data.tasks)?data.tasks:[],tomorrow:Array.isArray(data.tomorrow)?[...data.tomorrow,'','',''].slice(0,3):['','',''],habitDone:Array.isArray(data.habitDone)?data.habitDone:[]}:emptyDay();
    $('plannerFocus').value=day.focus||'';$('plannerReflection').value=day.reflection||'';[1,2,3].forEach(i=>$(`tomorrow${i}`).value=day.tomorrow[i-1]||'');render();
  }
  function minutes(value){const [h,m]=String(value||'').split(':').map(Number);return h*60+m}
  function conflictIds(tasks){const ids=new Set();const sorted=[...tasks].sort((a,b)=>minutes(a.start)-minutes(b.start));for(let i=0;i<sorted.length;i++)for(let j=i+1;j<sorted.length;j++){if(minutes(sorted[j].start)<minutes(sorted[i].end)){ids.add(sorted[i].id);ids.add(sorted[j].id)}}return ids}
  function periodOf(task){const t=minutes(task.start);return t<12*60?'morning':t<18*60?'afternoon':'evening'}
  function render(){
    const allTasks=[...day.tasks].sort((a,b)=>minutes(a.start)-minutes(b.start));
    const query=$('plannerTaskSearch')?.value.trim().toLocaleLowerCase()||'';
    const statusFilter=$('plannerStatusFilter')?.value||'all',categoryFilter=$('plannerCategoryFilter')?.value||'all';
    const filtered=allTasks.filter(t=>(!query||[t.title,t.category,t.priority,t.status,t.note].join(' ').toLocaleLowerCase().includes(query))&&(statusFilter==='all'||t.status===statusFilter)&&(categoryFilter==='all'||t.category===categoryFilter));
    const pageSize=Math.max(1,Number($('plannerPageSize')?.value||10)),pageCount=Math.max(1,Math.ceil(filtered.length/pageSize));currentPage=Math.min(currentPage,pageCount);
    const tasks=filtered.slice((currentPage-1)*pageSize,currentPage*pageSize);const conflicts=conflictIds(allTasks);const done=allTasks.filter(t=>t.status==='已完成').length;const percent=allTasks.length?Math.round(done/allTasks.length*100):0;
    $('plannerProgressText').textContent=`${done} / ${allTasks.length} 項完成`;$('plannerProgressPercent').textContent=`${percent}%`;$('plannerProgressBar').style.width=`${percent}%`;$('timelineConflict').hidden=conflicts.size===0;
    if($('plannerResultCount'))$('plannerResultCount').textContent=query||statusFilter!=='all'||categoryFilter!=='all'?`顯示 ${filtered.length} / ${allTasks.length} 項工作`:`共 ${allTasks.length} 項工作`;
    if($('plannerPageLabel'))$('plannerPageLabel').textContent=`第 ${currentPage} / ${pageCount} 頁`;
    if($('plannerPagePrev'))$('plannerPagePrev').disabled=currentPage<=1;
    if($('plannerPageNext'))$('plannerPageNext').disabled=currentPage>=pageCount;
    const groups=[['morning','☀️ 上午'],['afternoon','🌤️ 下午'],['evening','🌙 晚上']];
    let taskHtml=tasks.length?groups.map(([key,label])=>{const group=tasks.filter(t=>periodOf(t)===key);if(!group.length)return '';return `<section class="planner-period"><div class="planner-period-heading"><span>${label}</span><small>${group.length} 項工作</small></div><div class="planner-task-list">${group.map(task=>{
      const conflict=conflicts.has(task.id),priorityClass=task.priority==='重要'?'priority-important':task.priority==='次要'?'priority-secondary':'';
      return `<article class="planner-task-card ${task.status==='已完成'?'is-done':''} ${conflict?'has-conflict':''}"><time class="planner-task-time">${escapeHtml(task.start)}–${escapeHtml(task.end)}</time><div class="planner-task-copy"><strong>${escapeHtml(task.title)}</strong><div class="planner-task-meta"><span class="planner-chip">${escapeHtml(task.category)}</span><span class="planner-chip ${priorityClass}">${escapeHtml(task.priority)}</span>${conflict?'<span class="planner-chip priority-important">時段重疊</span>':''}</div>${task.note?`<small class="planner-task-note">✎ ${escapeHtml(task.note)}</small>`:''}</div><div class="planner-task-controls"><select data-task-status="${escapeHtml(task.id)}" aria-label="${escapeHtml(task.title)}狀態">${['未開始','進行中','已完成'].map(s=>`<option ${task.status===s?'selected':''}>${s}</option>`).join('')}</select><button type="button" data-edit-task="${escapeHtml(task.id)}">編輯</button><button type="button" data-delete-task="${escapeHtml(task.id)}" aria-label="刪除${escapeHtml(task.title)}">刪除</button></div></article>`;
    }).join('')}</div></section>`}).join(''):'<div class="planner-period planner-empty">今天還沒有安排工作。按「新增工作」，加入家訪、電訪、個案追蹤或行政事項。</div>';
    if(!tasks.length&&allTasks.length)taskHtml='<div class="planner-period planner-empty">找不到符合條件的工作，請調整搜尋或篩選。</div>';
    $('plannerTaskGroups').innerHTML=taskHtml;
    renderHabits();
    renderTimeline(tasks,conflicts);
    window.dispatchEvent(new CustomEvent('yhn:plans-updated',{detail:{date:activeDate}}));
  }
  function renderHabits(){
    const done=new Set(day.habitDone||[]);$('plannerHabitProgress').textContent=`${done.size} / ${habits.length} 已完成`;
    $('plannerHabitList').innerHTML=habits.length?habits.map(h=>`<div class="planner-habit-row ${done.has(h.id)?'is-checked':''}"><label><input type="checkbox" data-habit-id="${escapeHtml(h.id)}" ${done.has(h.id)?'checked':''}><span class="planner-habit-check" aria-hidden="true">✓</span><strong>${escapeHtml(h.title)}</strong></label><button type="button" data-remove-habit="${escapeHtml(h.id)}" aria-label="移除習慣：${escapeHtml(h.title)}">移除</button></div>`).join(''):'<p class="planner-empty">尚未建立習慣，按「新增習慣」開始記錄。</p>';
  }
  function renderTimeline(tasks,conflicts){
    const root=$('plannerTimeline'),hourHeight=parseFloat(getComputedStyle(root).getPropertyValue('--hour-height'))||52;
    const labels=Array.from({length:15},(_,i)=>`<span class="timeline-hour" style="top:${i*hourHeight}px">${String(8+i).padStart(2,'0')}:00</span>`).join('');
    const blocks=tasks.map(task=>{const start=Math.max(8*60,minutes(task.start)),end=Math.min(22*60,minutes(task.end));if(end<=start)return '';const top=(start-8*60)/60*hourHeight,height=Math.max(24,(end-start)/60*hourHeight);return `<div class="timeline-block ${task.status==='已完成'?'is-done':''} ${conflicts.has(task.id)?'has-conflict':''}" style="top:${top}px;height:${height}px" title="${escapeHtml(task.start)}–${escapeHtml(task.end)} ${escapeHtml(task.title)}">${escapeHtml(task.title)}</div>`}).join('');
    let now='';if($('plannerDate').value===localDate()){const current=new Date(),mins=current.getHours()*60+current.getMinutes();if(mins>=480&&mins<=1320)now=`<i class="timeline-now" style="top:${(mins-480)/60*hourHeight}px" aria-hidden="true"></i>`}
    root.innerHTML=labels+blocks+now;
  }
  function openDialog(task){
    const form=$('plannerTaskForm');form.reset();$('plannerTaskId').value=task?.id||'';$('plannerDialogTitle').textContent=task?'編輯工作':'新增今日工作';
    $('plannerTaskTitle').value=task?.title||'';$('plannerTaskStart').value=task?.start||'09:00';$('plannerTaskEnd').value=task?.end||'09:30';$('plannerTaskCategory').value=task?.category||'個案追蹤';$('plannerTaskPriority').value=task?.priority||'一般';$('plannerTaskNote').value=task?.note||'';
    const dialog=$('plannerTaskDialog');if(typeof dialog.showModal==='function')dialog.showModal();else dialog.setAttribute('open','');setTimeout(()=>$('plannerTaskTitle').focus(),50);
  }
  function closeDialog(){const d=$('plannerTaskDialog');if(typeof d.close==='function'&&d.open)d.close();else d.removeAttribute('open')}
  function csvCell(value){return `"${String(value??'').replace(/"/g,'""')}"`}
  function exportCsv(){
    readFormState();const rows=[['日期',$('plannerDate').value],['今日重點',day.focus],[],['開始時間','結束時間','工作事項','分類','優先程度','狀態','備註'],...day.tasks.map(t=>[t.start,t.end,t.title,t.category,t.priority,t.status,t.note]),[],['今日複盤',day.reflection],['明日三件事',...day.tomorrow]];
    const csv='\uFEFF'+rows.map(row=>row.map(csvCell).join(',')).join('\r\n');const blob=new Blob([csv],{type:'text/csv;charset=utf-8'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`居督每日工作_${$('plannerDate').value}.csv`;a.click();URL.revokeObjectURL(url);
  }
  function downloadJson(){
    saveDay(false);const blob=new Blob([JSON.stringify({format:'yhn-daily-workbench',version:1,exportedAt:new Date().toISOString(),plans,habits},null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='居督每日工作台備份.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  }
  function renderHistory(){
    const dates=Object.keys(plans).filter(date=>/^\d{4}-\d{2}-\d{2}$/.test(date)).sort((a,b)=>b.localeCompare(a));
    $('plannerHistoryList').innerHTML=dates.length?dates.map(date=>{const saved=plans[date]||{},taskCount=Array.isArray(saved.tasks)?saved.tasks.length:0,doneCount=(Array.isArray(saved.tasks)?saved.tasks:[]).filter(t=>t.status==='已完成').length;return `<button type="button" class="planner-history-item" data-history-date="${date}"><strong>${date}</strong><span>${taskCount} 項工作・完成 ${doneCount} 項</span><i>開啟 →</i></button>`}).join(''):'<p class="planner-empty">目前沒有已保存的歷史日期。</p>';
  }
  function openHistory(){saveDay(false);renderHistory();const dialog=$('plannerHistoryDialog');if(typeof dialog.showModal==='function')dialog.showModal();else dialog.setAttribute('open','')}
  function closeHistory(){const dialog=$('plannerHistoryDialog');if(typeof dialog.close==='function'&&dialog.open)dialog.close();else dialog.removeAttribute('open')}
  function addCaseTask({date,start,end,type,client,note}={}){
    if(!/^\d{4}-\d{2}-\d{2}$/.test(String(date||''))||!/^\d{2}:\d{2}$/.test(String(start||''))||!/^\d{2}:\d{2}$/.test(String(end||''))||minutes(end)<=minutes(start)||!client?.name)return {ok:false,message:'請確認個案、日期與起訖時間。'};
    const caseRef=String(client.clientId||client.caseNo||client.id||client.name).trim();
    const taskType=['外訪','計畫修正','當月撰寫'].includes(type)?type:'外訪';
    const title=taskType==='外訪'?`外訪｜${client.name}`:taskType==='計畫修正'?`照顧計畫修正｜${client.name}`:`當月照顧計畫撰寫｜${client.name}`;
    const category=taskType==='外訪'?'家訪':'計畫核對';
    saveDay(false);
    const target=plans[date]&&typeof plans[date]==='object'?plans[date]:emptyDay();
    const existing=Array.isArray(target.tasks)?target.tasks:[];
    if(existing.some(task=>task.caseRef===caseRef&&task.caseTaskType===taskType))return {ok:false,duplicate:true};
    const caseDetails=[`關聯個案：${client.name}`,client.caseNo?`案號：${client.caseNo}`:'',note?`備註：${note}`:''].filter(Boolean).join('｜');
    const task={id:`task-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,title,start,end,category,priority:'一般',status:'未開始',note:caseDetails,caseRef,caseName:client.name,caseNo:client.caseNo||'',caseTaskType:taskType};
    const nextDay={...target,tasks:[...existing,task]},nextPlans={...plans,[date]:nextDay};
    try{localStorage.setItem(KEY,JSON.stringify(nextPlans))}catch(_){return {ok:false,message:'裝置儲存空間不足，未新增工作。'}}
    plans=nextPlans;
    if(activeDate===date){day=nextDay;render()}else{$('plannerDate').value=date;$('plannerDate').dispatchEvent(new Event('change',{bubbles:true}))}
    $('plannerSaveStatus').textContent=`已新增「${title}」至每日工作清單`;
    return {ok:true,title,date};
  }
  window.yhnDailyWorkbench={setDate(date){if(!/^\d{4}-\d{2}-\d{2}$/.test(date))return;saveDay(false);loadDay(date)},openTask(date,id){if(activeDate!==date){saveDay(false);loadDay(date)}const task=day.tasks.find(item=>item.id===id);if(task)openDialog(task)},addTask(){openDialog()},addCaseTask};
  document.addEventListener('DOMContentLoaded',()=>{
    if(!$('plannerDate'))return;$('plannerDate').value=localDate();loadDay(localDate());
    window.addEventListener('storage',event=>{if(event.key!==KEY)return;try{const next=JSON.parse(event.newValue||'{}');if(next&&typeof next==='object'&&!Array.isArray(next)){plans=next;loadDay(activeDate||localDate())}}catch(_){$('plannerSaveStatus').textContent='新版待辦資料讀取失敗，請先備份'}});
    $('plannerDate').addEventListener('change',()=>{saveDay(false);loadDay($('plannerDate').value)});
    ['plannerFocus','plannerReflection','tomorrow1','tomorrow2','tomorrow3'].forEach(id=>$(id).addEventListener('input',()=>saveDay()));
    $('plannerAddTask').addEventListener('click',()=>openDialog());$('plannerSave').addEventListener('click',()=>saveDay());$('plannerExport').addEventListener('click',exportCsv);
    ['plannerTaskSearch','plannerStatusFilter','plannerCategoryFilter','plannerPageSize'].forEach(id=>$(id)?.addEventListener(id==='plannerTaskSearch'?'input':'change',()=>{currentPage=1;render()}));
    $('plannerPagePrev')?.addEventListener('click',()=>{currentPage=Math.max(1,currentPage-1);render()});$('plannerPageNext')?.addEventListener('click',()=>{currentPage+=1;render()});
    $('plannerImportCases')?.addEventListener('click',()=>{const dialog=$('casePickerDialog'),details=document.querySelector('.case-import-details');if(typeof dialog.showModal==='function'&&!dialog.open)dialog.showModal();else dialog.setAttribute('open','');if(details)details.open=true});
    $('plannerHistory').addEventListener('click',openHistory);$('plannerHistoryClose').addEventListener('click',closeHistory);
    $('plannerHistoryList').addEventListener('click',event=>{const item=event.target.closest('[data-history-date]');if(item){saveDay(false);loadDay(item.dataset.historyDate);closeHistory()}});
    $('plannerAddHabit').addEventListener('click',()=>{const title=window.prompt('請輸入習慣名稱（最多 30 字）');if(title&&title.trim()){if(habits.length>=40){window.alert('最多可設定 40 項習慣。');return}habits.push({id:`habit-${Date.now()}-${Math.random().toString(36).slice(2,6)}`,title:title.trim().slice(0,30)});saveHabits();renderHabits()}});
    $('plannerHabitList').addEventListener('change',event=>{const id=event.target.dataset.habitId;if(!id)return;const done=new Set(day.habitDone||[]);event.target.checked?done.add(id):done.delete(id);day.habitDone=[...done];saveDay(false);renderHabits()});
    $('plannerHabitList').addEventListener('click',event=>{const button=event.target.closest('[data-remove-habit]');if(!button)return;const habit=habits.find(item=>item.id===button.dataset.removeHabit);if(habit&&window.confirm(`移除習慣「${habit.title}」？過去每日紀錄不會被刪除。`)){habits=habits.filter(item=>item.id!==habit.id);saveHabits();renderHabits()}});
    $('plannerBackup').addEventListener('click',downloadJson);$('plannerImport').addEventListener('click',()=>$('plannerImportFile').click());
    $('plannerImportFile').addEventListener('change',async event=>{const file=event.target.files?.[0];if(!file)return;try{const data=JSON.parse(await file.text());if(data?.format!=='yhn-daily-workbench'||!data.plans||typeof data.plans!=='object'||Array.isArray(data.plans))throw new Error('格式');if(!window.confirm('匯入備份會合併相同日期的資料，匯入內容較新的日期會取代該日期。要繼續嗎？'))return;plans={...plans,...data.plans};if(Array.isArray(data.habits))habits=data.habits.filter(h=>h&&typeof h.id==='string'&&typeof h.title==='string').slice(0,40);saveHabits();localStorage.setItem(KEY,JSON.stringify(plans));loadDay(activeDate);$('plannerSaveStatus').textContent='備份已匯入並儲存於此裝置'}catch(_){window.alert('無法匯入這個備份檔，請確認檔案來自每日工作台。')}finally{event.target.value=''}});
    $('plannerReview').addEventListener('click',()=>{$('plannerReflectionPanel').scrollIntoView({behavior:'smooth',block:'center'});$('plannerReflection').focus({preventScroll:true})});
    $('plannerTaskDialog').addEventListener('click',event=>{if(event.target===$('plannerTaskDialog'))closeDialog()});
    $('plannerDialogClose').addEventListener('click',closeDialog);$('plannerTaskCancel').addEventListener('click',closeDialog);
    $('plannerTaskForm').addEventListener('submit',event=>{event.preventDefault();const title=$('plannerTaskTitle').value.trim(),start=$('plannerTaskStart').value,end=$('plannerTaskEnd').value;if(!title){$('plannerTaskTitle').focus();return}if(minutes(end)<=minutes(start)){window.alert('結束時間需晚於開始時間。');return}const id=$('plannerTaskId').value,previous=id?day.tasks.find(t=>t.id===id):null;const task={id:id||`task-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,title,start,end,category:$('plannerTaskCategory').value,priority:$('plannerTaskPriority').value,status:previous?.status||'未開始',note:$('plannerTaskNote').value.trim(),...(previous?.caseRef?{caseRef:previous.caseRef,caseName:previous.caseName,caseNo:previous.caseNo,caseTaskType:previous.caseTaskType,...(previous.caseReminderType?{caseReminderType:previous.caseReminderType,caseReminderSourceDate:previous.caseReminderSourceDate,caseReminderDueDate:previous.caseReminderDueDate}:{})}:{})};day.tasks=id?day.tasks.map(t=>t.id===id?task:t):[...day.tasks,task];saveDay(false);render();closeDialog()});
    $('plannerTaskGroups').addEventListener('change',event=>{const id=event.target.dataset.taskStatus;if(!id)return;const task=day.tasks.find(t=>t.id===id);if(task){task.status=event.target.value;saveDay(false);render()}});
    $('plannerTaskGroups').addEventListener('click',event=>{const edit=event.target.closest('[data-edit-task]'),remove=event.target.closest('[data-delete-task]');if(edit){const task=day.tasks.find(t=>t.id===edit.dataset.editTask);if(task)openDialog(task)}if(remove){const task=day.tasks.find(t=>t.id===remove.dataset.deleteTask);if(task&&window.confirm(`刪除「${task.title}」？`)){day.tasks=day.tasks.filter(t=>t.id!==task.id);saveDay(false);render()}}});
  });
})();
