(() => {
  'use strict';
  document.addEventListener('DOMContentLoaded', () => {
    document.querySelector('[data-home-add-task]')?.addEventListener('click', () => document.getElementById('plannerAddTask')?.click());
    document.querySelector('[data-home-backup]')?.addEventListener('click', () => document.getElementById('plannerBackup')?.click());
    document.querySelectorAll('[data-home-scroll]').forEach(button => button.addEventListener('click', () => {
      document.getElementById(button.dataset.homeScroll)?.scrollIntoView({behavior:'smooth',block:'start'});
    }));
  });
})();
