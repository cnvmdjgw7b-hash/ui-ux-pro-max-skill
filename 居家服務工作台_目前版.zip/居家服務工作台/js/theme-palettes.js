/* Reference colors become optional skins; no records, files or business state are changed. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.YhnThemePalettes=api})(typeof window==='object'?window:globalThis,function(){
'use strict';
const palettes={
 mango:{name:'金芒橙・霧灰藍',colors:['#ADBCD1','#F58057','#98C691','#FBA11E'],base:'#ADBCD1',brand:'#FBA11E',accent:'#F58057'},
 lemon:{name:'檸檬黃・深海藍',colors:['#FFDE34','#2078DB','#FFD0B0','#336B4E'],base:'#FFDE34',brand:'#2078DB',accent:'#336B4E'},
 honey:{name:'蜜檸黃・松針綠',colors:['#F8E39E','#F8D9A1','#F47F49','#599580'],base:'#F8E39E',brand:'#599580',accent:'#F47F49'},
 apple:{name:'蘋果紅・活力橙',colors:['#FFBA3A','#85A1D4','#E92323','#FFA268'],base:'#FFA268',brand:'#E92323',accent:'#85A1D4'},
 sky:{name:'星空藍・活力橙',colors:['#FBE7C9','#315B94','#FAE773','#FFAE42'],base:'#FBE7C9',brand:'#315B94',accent:'#FFAE42'},
 tomato:{name:'番茄紅・陽光黃',colors:['#FCC81E','#2E271A','#F5DBA3','#CB5135'],base:'#F5DBA3',brand:'#CB5135',accent:'#FCC81E'}
};
const rgb=h=>h.slice(1).match(/../g).map(v=>parseInt(v,16));
function mix(a,b,t){const x=rgb(a),y=rgb(b);return '#'+x.map((v,i)=>Math.round(v*(1-t)+y[i]*t).toString(16).padStart(2,'0')).join('').toUpperCase()}
function lum(h){return rgb(h).map(v=>{v/=255;return v<=.04045?v/12.92:((v+.055)/1.055)**2.4}).reduce((a,v,i)=>a+v*[.2126,.7152,.0722][i],0)}
function contrast(a,b){return (Math.max(lum(a),lum(b))+.05)/(Math.min(lum(a),lum(b))+.05)}
function on(color){return contrast(color,'#000000')>=contrast(color,'#FFFFFF')?'#000000':'#FFFFFF'}
function readable(color,surfaces,mode,min=4.5){const target=mode==='dark'?'#FFFFFF':'#101820';for(let i=0;i<=20;i++){const v=mix(color,target,i/20);if(surfaces.every(s=>contrast(v,s)>=min))return v}return target}
function guard(t){const surfaces=[t.bg,t.card,t.soft],dark=t.mode==='dark';return {...t,muted:readable(t.muted,surfaces,t.mode,4.5),line:readable(mix(t.ink,t.card,.4),surfaces,t.mode,3),brandDark:readable(t.brandDark||t.brand,surfaces,t.mode,4.5),danger:readable(dark?'#FFAAA0':'#B42318',surfaces,t.mode),onBrand:on(t.brand)}}
function variant(id,mode){const p=palettes[id],dark=mode==='dark';if(!p)return null;const bg=dark?mix('#111820',p.base,.07):mix('#FFFFFF',p.base,.21),card=dark?mix('#202B36',p.base,.08):'#FFFFFF',soft=dark?mix(card,p.brand,.13):mix('#FFFFFF',p.base,.38);return guard({mode,name:p.name,bg,card,soft,ink:dark?'#F7FAFF':'#132337',muted:dark?'#CFD9E5':'#435369',brand:p.brand,brandDark:p.brand,accent:p.accent})}
const themes={},pairs={};for(const id of Object.keys(palettes)){themes[id]=variant(id,'light');themes[id+'-dark']=variant(id,'dark');pairs[id]=id+'-dark'}
function tokens(theme){const t=guard(theme),dark=t.mode==='dark';return {'--bg':t.bg,'--card':t.card,'--ink':t.ink,'--muted':t.muted,'--line':t.line,'--brand':t.brand,'--brand-dark':t.brandDark,'--soft':t.soft,'--danger':t.danger,'--on-brand':on(t.brand),'--on-brand-dark':on(t.brandDark),'--mint':dark?'#294B3C':'#E3F4EA','--sky':dark?'#2B435E':'#E5F0FE','--lilac':dark?'#443A5C':'#F0EAFB','--rose':dark?'#563741':'#FCE8EB'}}
return {palettes,themes,pairs,variant,guard,tokens,contrast,on,mix};
});
