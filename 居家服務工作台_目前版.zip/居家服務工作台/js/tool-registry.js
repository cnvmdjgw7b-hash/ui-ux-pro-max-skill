(() => {
  'use strict';
  const KEY = 'yhn_custom_tools_v1';
  const $ = id => document.getElementById(id);
  const escapeHtml = value => String(value || '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  const read = () => { try {
    const raw=JSON.parse(localStorage.getItem(KEY)||'[]');if(!Array.isArray(raw))return [];
    const valid=raw.filter(x=>x&&typeof x.id==='string');
    // The workstation already has a native contract-tracking workspace. Remove only duplicate custom links with that exact label, preserving unrelated tools.
    const clean=valid.filter(x=>String(x.name||'').trim().replace(/[\s　]/g,'')!=='附約追蹤');
    if(clean.length!==valid.length){localStorage.setItem(KEY,JSON.stringify(clean));sessionStorage.setItem('yhn_contract_duplicate_removed','1');}
    return clean;
  } catch (_) { return []; } };
  let tools = read();
  let pendingImage = '';
  function safeImage(value) { return /^data:image\/(?:jpeg|png|webp);base64,[a-z\d+/]+=*$/i.test(value || '') ? value : ''; }
  function resetForm(){ $('customToolForm').reset(); $('customToolId').value=''; pendingImage=''; $('customToolImageStatus').textContent='可選符號或上傳圖片；圖片會縮小後儲存在此裝置。'; $('customToolSave').textContent='新增工具'; $('customToolCancel').hidden=true; }
  function render(){
    const list=$('customToolsList'), nav=$('customToolNavList'); if(!list)return;
    const notice=$('customToolsNotice');if(notice&&sessionStorage.getItem('yhn_contract_duplicate_removed'))notice.hidden=false;
    list.innerHTML=tools.length ? tools.map(item=>`<article class="card custom-tool-card"><div><h3>${escapeHtml(item.name)}</h3><p>${escapeHtml(item.description)||'未填寫說明'}</p><a href="${escapeHtml(item.url)}" target="_blank" rel="noopener noreferrer">開啟工具</a></div><div class="custom-tool-actions"><button class="secondary-btn" type="button" data-edit-tool="${escapeHtml(item.id)}">編輯</button><button class="ghost-btn" type="button" data-delete-tool="${escapeHtml(item.id)}">移除入口</button></div></article>`).join('') : '<div class="card empty-state">尚未新增自研工具。填寫上方資料即可建立入口。</div>';
    if(nav){
      nav.innerHTML=tools.map(item=>{const image=safeImage(item.imageData);const icon=image?`<img class="yhn-nav-tool-image" src="${image}" alt="">`:`<span aria-hidden="true">${escapeHtml(item.icon||'🧰')}</span>`;return `<a data-tool-nav-item data-tool-category="custom" href="${escapeHtml(item.url)}" target="_blank" rel="noopener noreferrer">${icon}<small>${escapeHtml(item.name)}</small></a>`}).join('');
    }
  }
  function persist(){ try{localStorage.setItem(KEY,JSON.stringify(tools));render();}catch(_){window.alert('儲存空間不足，請移除較大的圖片或工具入口後再試。');} }
  function imageToDataUrl(file){
    return new Promise((resolve,reject)=>{
      if(!file||!file.type.startsWith('image/')){reject(new Error('請選擇圖片檔案。'));return;}
      const reader=new FileReader();reader.onerror=()=>reject(new Error('無法讀取這張圖片。'));
      reader.onload=()=>{const image=new Image();image.onerror=()=>reject(new Error('圖片格式無法讀取。'));image.onload=()=>{const max=420,scale=Math.min(1,max/Math.max(image.naturalWidth,image.naturalHeight));const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(image.naturalWidth*scale));canvas.height=Math.max(1,Math.round(image.naturalHeight*scale));canvas.getContext('2d').drawImage(image,0,0,canvas.width,canvas.height);resolve(canvas.toDataURL('image/jpeg',0.78));};image.src=reader.result;};reader.readAsDataURL(file);
    });
  }
  document.addEventListener('DOMContentLoaded',()=>{
    const form=$('customToolForm');if(!form)return;render();
    $('customToolImage').addEventListener('change',async event=>{const file=event.target.files?.[0];if(!file)return;try{pendingImage=await imageToDataUrl(file);$('customToolImageStatus').textContent=`已選取：${file.name}（已縮小並轉為 JPG）`;}catch(error){pendingImage='';$('customToolImageStatus').textContent=error.message;event.target.value='';}});
    form.addEventListener('submit',event=>{
      event.preventDefault();const id=$('customToolId').value,name=$('customToolName').value.trim(),rawUrl=$('customToolUrl').value.trim(),description=$('customToolDescription').value.trim();let url;
      try{url=new URL(rawUrl);if(!['https:','http:'].includes(url.protocol))throw new Error();}catch(_){window.alert('請輸入有效的 http 或 https 工具連結。');return;}if(!name)return;
      const previous=id?tools.find(item=>item.id===id):null;const entry={id:id||`tool-${Date.now()}-${Math.random().toString(36).slice(2,8)}`,name,url:url.href,description,icon:$('customToolIcon').value||'🧰',imageData:pendingImage||previous?.imageData||''};
      tools=id?tools.map(item=>item.id===id?entry:item):[entry,...tools];persist();resetForm();
    });
    $('customToolCancel').addEventListener('click',resetForm);
    $('customToolsList').addEventListener('click',event=>{
      const edit=event.target.closest('[data-edit-tool]'),remove=event.target.closest('[data-delete-tool]');
      if(edit){const item=tools.find(x=>x.id===edit.dataset.editTool);if(!item)return;$('customToolId').value=item.id;$('customToolName').value=item.name;$('customToolUrl').value=item.url;$('customToolDescription').value=item.description||'';$('customToolIcon').value=item.icon||'🧰';pendingImage='';$('customToolImageStatus').textContent=safeImage(item.imageData)?'目前使用已儲存圖片；選擇新圖片可取代。':'可選符號或上傳圖片；圖片會縮小後儲存在此裝置。';$('customToolSave').textContent='儲存更新';$('customToolCancel').hidden=false;$('customToolName').focus();}
      if(remove){const item=tools.find(x=>x.id===remove.dataset.deleteTool);if(!item||!window.confirm(`移除「${item.name}」的工具入口？`))return;tools=tools.filter(x=>x.id!==item.id);persist();if($('customToolId').value===item.id)resetForm();}
    });
  });
})();
