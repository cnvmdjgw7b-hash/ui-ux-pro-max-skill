(() => {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const today = () => new Date().toLocaleDateString('sv-SE');
  const escapeText = (value) => String(value || '').trim();
  const PLAN_KEY = 'yhn_care_plan_generator_v1';

  const assistiveItems = [
    ['氣墊床','臥床照護','床面支撐與減壓參考，選用前評估皮膚狀況、照護方式及設備維護。','air_mattress.png'],
    ['浴室止滑','沐浴如廁','浴室止滑改善參考；須檢查地面、排水及使用者移動能力。','bath_anti_slip.png'],
    ['床邊扶手','移位行走','上下床支撐參考；須確認床型、固定方式及跌倒風險。','bed_assist_rail.jpeg'],
    ['床欄','臥床照護','床邊防護參考；使用前評估夾困、攀爬與限制行動風險。','bed_rail.png'],
    ['手杖','移位行走','單點支撐用品參考，應由專業人員確認高度及步態適用性。','cane.png'],
    ['鋁製手杖','移位行走','手杖類參考；請依使用者握力、身高及行走能力選擇。','cane_aluminum.png'],
    ['鋼製手杖','移位行走','手杖類參考；請依使用者握力、身高及行走能力選擇。','cane_steel.png'],
    ['照顧床','臥床照護','照顧床型式參考；先確認照護空間、照顧者操作與移位動線。','care_bed.png'],
    ['便盆器具','沐浴如廁','如廁輔具參考；依個案移位能力及清潔需求評估。','commode.png'],
    ['便盆椅','沐浴如廁','床邊如廁輔具參考；使用前確認穩定、煞車及移位安全。','commode_chair.png'],
    ['減壓坐墊','移位行走','坐姿支撐與減壓用品參考；依姿勢及皮膚狀況評估。','cushion.png'],
    ['日常生活輔具','日常生活','日常活動輔具參考；先確認個案的實際操作能力與需求。','daily_aid.png'],
    ['生活自理輔具','日常生活','生活自理輔具參考；試用後再確認是否能安全、穩定使用。','daily_living_aids.png'],
    ['閃光門鈴','溝通警示','視覺提示設備參考；確認安裝位置及使用者可辨識性。','doorbell_flash.png'],
    ['穿衣輔具','日常生活','穿脫衣物輔具參考；依關節活動度與手部操作能力評估。','dressing_aids.png'],
    ['進食輔具','日常生活','進食用品參考；吞嚥安全疑慮應先由專業人員評估。','eating_aids.png'],
    ['電動照顧床','臥床照護','電動床型式參考；評估床邊空間、電源及照護者操作。','electric_bed.png'],
    ['火災閃光警報','溝通警示','警示設備參考；需搭配居家消防與緊急應變規劃。','fire_flash_alarm.png'],
    ['安全扶手','沐浴如廁','固定扶手參考；安裝位置、牆面結構及受力須由專業人員確認。','grab_bar.png'],
    ['高背輪椅','移位行走','輪椅型式參考；座姿、尺寸及移位方式需個別評估。','highback_wheelchair.png'],
    ['移位吊升設備','移位行走','吊升設備參考；需確認照護人力、空間及操作訓練。','hoist.png'],
    ['居家無障礙改善','居家環境','環境改善示意參考；依現場尺寸、動線及房屋條件評估。','home_mod.png'],
    ['吊升移位吊帶','移位行走','移位吊帶參考；型號及穿戴方式應符合設備與個案狀況。','lift_sling.png'],
    ['手動移位吊帶','移位行走','移位輔具參考；須由受訓人員示範與確認操作安全。','manual_lift_sling.png'],
    ['電動代步車','移位行走','代步車型式參考；評估視力、反應、路線與道路安全。','mobility_scooter.png'],
    ['病人移位機','移位行走','移位設備參考；需確認承重、空間、吊帶及照護者訓練。','patient_lift.png'],
    ['電話警示裝置','溝通警示','通訊警示設備參考；確認操作方式及緊急聯絡流程。','phone_alert.png'],
    ['電話擴音器','溝通警示','聽覺輔助設備參考；先確認音量、相容性及聽力需求。','phone_amplifier.png'],
    ['閃光震動電話提示','溝通警示','視覺／震動提示設備參考；確認使用者能辨識提示方式。','phone_flash_vibrator.png'],
    ['四腳手杖','移位行走','多點支撐手杖參考；底座穩定與步態適用性須個別確認。','quad_cane.png'],
    ['斜坡板','居家環境','高低差通行改善參考；坡度、防滑、寬度及固定方式需量測。','ramp.png'],
    ['助行車','移位行走','助行車型式參考；確認煞車、轉向及室內外路面適用性。','rollator.png'],
    ['沐浴椅','沐浴如廁','沐浴坐具參考；檢查腳墊、防滑、承重及浴室空間。','shower_chair.png'],
    ['樓梯爬升設備','移位行走','樓梯通行設備參考；須由合格人員評估樓梯結構及操作安全。','stair_climber.png'],
    ['科技輔具','溝通警示','科技輔具參考；確認操作負荷、維護方式及支援服務。','tech_aid.png'],
    ['馬桶增高器','沐浴如廁','如廁高度調整參考；確認穩固、尺寸與起身能力。','toilet_raiser.png'],
    ['移位腰帶','移位行走','移位輔具參考；使用前確認適應症、穿戴方式與照護者訓練。','transfer_belt.png'],
    ['移位板','移位行走','床椅轉位輔具參考；評估上肢能力、落差與固定狀況。','transfer_board.png'],
    ['移位轉盤','移位行走','站立轉位輔具參考；使用前確認承重、平衡及照護者協助方式。','transfer_disc.png'],
    ['移位滑布','移位行走','床上移位輔具參考；應由受訓人員示範正確施力方法。','transfer_sheet.png'],
    ['助行器','移位行走','步行支撐用品參考；調整高度並確認煞車／腳墊狀況。','walker.png'],
    ['輪椅','移位行走','輪椅型式參考；依尺寸、姿勢、活動環境及移位能力評估。','wheelchair.png'],
    ['輪椅減壓坐墊','移位行走','輪椅坐姿與減壓用品參考；依坐姿及皮膚狀況個別評估。','wheelchair_cushion.png'],
    ['門檻與地面高低差改善','居家環境','依現場量測檢視高低差、通行寬度與防滑需求。',''],
    ['照明與夜間動線改善','居家環境','檢視夜間照明、床邊至廁所動線及易絆倒物品。',''],
    ['門寬與通行動線改善','居家環境','依輪椅或助行器實際寬度量測通行空間。',''],
    ['對比標示與方向提示','溝通警示','以清楚、固定且符合使用者理解能力的標示輔助辨識。','']
  ].map(([name,category,description,image])=>({name,category,description,image}));

  const imageBase='https://yinyi114work-ai.github.io/ltc-case-manager/assets/assistive/';
  function initAssistiveCatalog(){
    const category=$('assistiveCategory'),search=$('assistiveSearch'),filter=$('assistiveImageFilter'),grid=$('assistiveCatalogGrid');
    if(!grid)return;
    const dialog=$('assistivePreviewDialog'),previewImage=$('assistivePreviewImage'),stage=$('assistivePreviewStage');
    let zoom=1;
    const setZoom=value=>{
      zoom=Math.min(3,Math.max(.5,value));
      previewImage.style.width=`${zoom*100}%`;
      $('assistiveZoomLevel').textContent=`${Math.round(zoom*100)}%`;
    };
    [...new Set(assistiveItems.map(x=>x.category))].forEach(name=>{const option=document.createElement('option');option.value=name;option.textContent=name;category.append(option);});
    const render=()=>{
      const q=(search.value||'').trim().toLowerCase(),cat=category.value,mode=filter.value;
      const items=assistiveItems.filter(item=>(cat==='all'||item.category===cat)&&(mode==='all'||(mode==='with'&&item.image)||(mode==='without'&&!item.image))&&(!q||`${item.name} ${item.category} ${item.description}`.toLowerCase().includes(q)));
      $('assistiveCatalogSummary').textContent=`顯示 ${items.length} 項｜有圖片 ${items.filter(x=>x.image).length} 項｜無圖片 ${items.filter(x=>!x.image).length} 項`;
      grid.innerHTML=items.map(item=>`<button type="button" class="assistive-card" data-assistive-index="${assistiveItems.indexOf(item)}"><span class="assistive-image">${item.image?`<img loading="lazy" src="${imageBase}${encodeURIComponent(item.image)}" alt="${item.name}示意圖" onerror="this.closest('.assistive-image').classList.add('image-missing');this.remove()">`:'<span>現場評估項目</span>'}</span><span class="assistive-card-copy"><span class="assistive-category">${item.category}</span><strong class="assistive-card-title">${item.name}</strong><span class="assistive-card-description">${item.description}</span><span class="assistive-card-hint">點開查看　⌕</span></span></button>`).join('')||'<div class="empty-state">找不到符合條件的項目。</div>';
    };
    grid.addEventListener('click',event=>{
      const card=event.target.closest('[data-assistive-index]');
      if(!card||!dialog)return;
      const item=assistiveItems[Number(card.dataset.assistiveIndex)];
      if(!item)return;
      $('assistivePreviewTitle').textContent=item.name;
      $('assistivePreviewCategory').textContent=item.category;
      $('assistivePreviewDescription').textContent=item.description;
      $('assistivePreviewNoImage').hidden=!!item.image;
      previewImage.hidden=!item.image;
      $('assistiveZoomControls').hidden=!item.image;
      previewImage.onerror=()=>{previewImage.hidden=true;$('assistivePreviewNoImage').hidden=false;$('assistiveZoomControls').hidden=true;};
      previewImage.alt=`${item.name}示意圖`;
      previewImage.src=item.image?`${imageBase}${encodeURIComponent(item.image)}`:'';
      setZoom(1);
      stage.scrollTo({top:0,left:0});
      dialog.showModal();
    });
    dialog?.addEventListener('click',event=>{if(event.target===dialog||event.target.closest('[data-assistive-close]'))dialog.close();});
    $('assistiveZoomIn')?.addEventListener('click',()=>setZoom(zoom+.25));
    $('assistiveZoomOut')?.addEventListener('click',()=>setZoom(zoom-.25));
    $('assistiveZoomReset')?.addEventListener('click',()=>{setZoom(1);stage.scrollTo({top:0,left:0,behavior:'smooth'});});
    [search,category,filter].forEach(el=>el.addEventListener(el===search?'input':'change',render));render();
  }

  document.addEventListener('DOMContentLoaded',()=>{ initAssistiveCatalog(); });
})();
