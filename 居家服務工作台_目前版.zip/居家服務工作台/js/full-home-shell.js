(() => {
  'use strict';
  document.addEventListener('DOMContentLoaded',()=>{
    const home=document.getElementById('toolHome');
    const frame=document.createElement('iframe');frame.id='zipHomepage';frame.title='牛馬吃肉命工作站';frame.src='dashboard-home.html?v=157';document.body.append(frame);
    const nav=document.querySelector('.mobile-bottom-nav');if(nav){nav.id='sharedBottomNav';nav.setAttribute('aria-label','工作站底部導覽');}
    let advanced=false;
    function sync(){const unlocked=!document.body.classList.contains('yhn-locked'),visible=!advanced&&!home.hidden&&unlocked;document.body.classList.toggle('site-shell-unified',unlocked);if(document.body.classList.contains('zip-home-visible')!==visible){document.body.classList.toggle('zip-home-visible',visible);if(visible)frame.contentWindow?.postMessage({type:'yhn:dashboard-active'},location.origin);}}
    function openExistingTool(id){if(id==='all'){document.getElementById('yhnMenuToggle')?.click();return;}if(id.startsWith('dir:')){advanced=true;document.querySelector('[data-yhn-home]')?.click();window.YhnDirector?.open(id.slice(4));sync();return;}const allowed=['visitTool','phoneAssistTool','mutationTool','yhnCarePlanTool','quotaTool','codeTool'];if(allowed.includes(id)){advanced=true;document.querySelector('[data-open-tool="'+id+'"]')?.click();sync();}}
    new MutationObserver(sync).observe(home,{attributes:true,attributeFilter:['hidden']});
    new MutationObserver(sync).observe(document.body,{attributes:true,attributeFilter:['class']});
    const activateNav=name=>nav?.querySelectorAll('button').forEach(button=>button.setAttribute('aria-current',String(button.dataset.mobileHome!==undefined&&name==='home'||button.classList.contains('mobile-add-action')&&name==='add'||button.dataset.mobileTools!==undefined&&name==='tools')));
    frame.addEventListener('load',()=>{try{const page=frame.contentWindow.location,path=page.pathname;const pageParams=new URLSearchParams(page.search);activateNav(path.endsWith('/planner-home.html')&&pageParams.has('add')?'add':'home');}catch{}});
    document.addEventListener('click',event=>{const button=event.target.closest('#sharedBottomNav button');if(!button||document.body.classList.contains('yhn-locked'))return;event.preventDefault();event.stopImmediatePropagation();if(!button.hasAttribute('data-mobile-tools'))setDrawer(false);if(button.hasAttribute('data-mobile-home')){activateNav('home');advanced=false;document.querySelector('[data-yhn-home]')?.click();frame.src='dashboard-home.html?v=157';sync();return;}if(button.classList.contains('mobile-add-action')){activateNav('add');advanced=false;document.querySelector('[data-yhn-home]')?.click();if(frame.contentWindow&&document.body.classList.contains('zip-home-visible'))frame.contentWindow.postMessage({type:'yhn:add-task'},location.origin);else frame.src='dashboard-home.html?v=157&add=1';sync();return;}if(button.hasAttribute('data-mobile-tools')){activateNav('tools');openExistingTool('all')}},true);
    const header=document.createElement('header');header.id='sharedSiteHeader';header.className='shared-site-header';header.innerHTML='<button id="sharedMenu" class="menu shared-menu" type="button" aria-label="開啟側邊選單">☰</button><img class="brand-heart shared-logo" src="logo.png" alt="永護寧 LOGO"><div class="site-name shared-brand">牛馬吃肉命工作站<small>業務負責人工作台</small></div><div class="user shared-user"><time class="shared-date" id="sharedDate"></time><div class="avatar shared-avatar" id="sharedAvatar" aria-label="使用者頭像">👤</div><strong class="shared-name" id="sharedName">使用者</strong></div>';document.body.append(header);
    const renderDate=()=>{const d=new Date(),date=new Intl.DateTimeFormat('zh-TW',{timeZone:'Asia/Taipei',year:'numeric',month:'2-digit',day:'2-digit'}).format(d),day=new Intl.DateTimeFormat('zh-TW',{timeZone:'Asia/Taipei',weekday:'short'}).format(d);header.querySelector('#sharedDate').innerHTML=date+'<small style="display:block">'+day+'</small>'};
    const syncIdentity=()=>{const name=document.getElementById('profileShortcutName')?.textContent?.trim();if(name)header.querySelector('#sharedName').textContent=name;const image=document.getElementById('profileAvatarImage');if(image&&!image.hidden&&image.getAttribute('src')){const copy=document.createElement('img');copy.src=image.src;copy.alt='使用者頭像';header.querySelector('#sharedAvatar').replaceChildren(copy)}};
    renderDate();syncIdentity();setInterval(renderDate,60000);window.addEventListener('storage',syncIdentity);
    const profileName=document.getElementById('profileShortcutName'),profileImage=document.getElementById('profileAvatarImage');
    if(profileName)new MutationObserver(syncIdentity).observe(profileName,{childList:true,characterData:true,subtree:true});
    if(profileImage)new MutationObserver(syncIdentity).observe(profileImage,{attributes:true,attributeFilter:['src','hidden']});
    const drawer=document.getElementById('yhnSidebar');
    const backdrop=document.createElement('button');backdrop.id='shellDrawerBackdrop';backdrop.type='button';backdrop.hidden=true;backdrop.setAttribute('aria-label','關閉導覽選單');document.body.append(backdrop);
    const menu=header.querySelector('#sharedMenu');menu.setAttribute('aria-controls','yhnSidebar');
    let returnFocus=null;
    function setDrawer(open){document.body.classList.toggle('shell-drawer-open',open);backdrop.hidden=!open;menu.setAttribute('aria-expanded',String(open));menu.setAttribute('aria-label',open?'關閉側邊選單':'開啟側邊選單');if(drawer){drawer.inert=!open;drawer.setAttribute('aria-hidden',String(!open))}if(open){returnFocus=document.activeElement;drawer?.querySelector('button,a,summary')?.focus()}else if(returnFocus){returnFocus.focus();returnFocus=null}}
    setDrawer(false);
    menu.addEventListener('click',()=>setDrawer(!document.body.classList.contains('shell-drawer-open')));
    document.addEventListener('click',event=>{if(event.target.closest('#yhnMenuToggle,[data-mobile-tools]')){event.preventDefault();event.stopImmediatePropagation();setDrawer(!document.body.classList.contains('shell-drawer-open'))}},true);
    backdrop.addEventListener('click',()=>setDrawer(false));
    document.addEventListener('keydown',event=>{if(!document.body.classList.contains('shell-drawer-open'))return;if(event.key==='Escape'){event.preventDefault();setDrawer(false)}if(event.key==='Tab'){const nodes=[...drawer.querySelectorAll('button,a,summary,[tabindex="0"]')].filter(x=>x.getClientRects().length);const first=nodes[0],last=nodes.at(-1);if(event.shiftKey&&document.activeElement===first){event.preventDefault();last?.focus()}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first?.focus()}}});
    drawer?.addEventListener('click',event=>{const target=event.target.closest('button,a');if(!target||target.matches('[data-yhn-home]')&&!event.isTrusted)return;if(target.matches('.yhn-side-close,[data-close-menu]')){setDrawer(false);return}advanced=!target.matches('[data-yhn-home]');setDrawer(false);queueMicrotask(sync)},true);
    const settingsButton=document.createElement('button');settingsButton.id='shellSettings';settingsButton.type='button';settingsButton.textContent='⚙';settingsButton.setAttribute('aria-label','外觀與背景設定');settingsButton.addEventListener('click',()=>{setDrawer(false);document.getElementById('themeChooserOpen')?.click()});header.insertBefore(settingsButton,header.querySelector('.shared-user'));
    function syncSkin(){const style=getComputedStyle(document.documentElement),bodyStyle=getComputedStyle(document.body);for(const [key,source] of Object.entries({'--shell-bg':'--bg','--shell-card':'--card','--shell-soft':'--soft','--shell-ink':'--ink','--shell-muted':'--muted','--shell-line':'--line','--shell-nav':'--card','--shell-accent':'--brand'})){const value=bodyStyle.getPropertyValue(source)||style.getPropertyValue(source);if(value.trim()){if(document.body.style.getPropertyValue(key)!==value.trim())document.body.style.setProperty(key,value.trim())}}try{const doc=frame.contentDocument;if(!doc?.body)return;doc.documentElement.dataset.workstationMode=document.documentElement.dataset.readableTheme||'light';doc.documentElement.style.colorScheme=getComputedStyle(document.documentElement).colorScheme;for(const [key,source] of Object.entries({'--bg':'--bg','--paper':'--card','--ink':'--ink','--muted':'--muted','--stroke':'--line','--line':'--line','--card':'--card','--field':'--card','--shell':'--soft','--accent-soft':'--soft','--soft':'--soft','--input':'--card','--nav':'--card','--tab':'--soft','--accent':'--brand','--accent-ink':'--on-brand'})){const value=bodyStyle.getPropertyValue(source);if(value.trim())doc.documentElement.style.setProperty(key,value.trim())}doc.body.classList.toggle('shell-has-background',document.body.classList.contains('personal-background'));for(const key of ['--personal-background','--personal-bg-overlay'])doc.documentElement.style.setProperty(key,bodyStyle.getPropertyValue(key));if(!doc.getElementById('shellBackgroundStyle')){const css=doc.createElement('style');css.id='shellBackgroundStyle';css.textContent='body,body.shell-has-background{background:var(--bg)!important;background-image:none!important}.topbar{display:none!important}.app{padding-top:0!important}body.shell-has-background .app,body.shell-has-background .shell{background:transparent}';doc.head.append(css)}}catch{}}
    frame.addEventListener('load',syncSkin);window.addEventListener('yhn-theme-change',syncSkin);new MutationObserver(syncSkin).observe(document.body,{attributes:true,attributeFilter:['class','style']});syncSkin();
    window.addEventListener('message',event=>{
      if(event.origin!==location.origin||event.source!==frame.contentWindow)return;
      if(event.data?.type==='yhn:home-action'){
        const action=event.data.action;
        if(action==='backup')document.getElementById('plannerBackup')?.click();
        else if(action==='restore')document.getElementById('plannerImport')?.click();
        else if(action==='cloudBackup')window.yhnWorkstationCloud?.downloadBackup().catch(error=>alert(error.message||'雲端備份失敗。'));
        else if(action==='cloudRestore')window.yhnWorkstationCloud?.restoreLatest().catch(error=>alert(error.message||'雲端還原失敗。'));
        else if(action==='addTask')document.getElementById('plannerAddTask')?.click();
        else if(action==='notices')document.getElementById('noticeCenterOpen')?.click();
        else if(action==='settings')document.getElementById('themeChooserOpen')?.click();
        else if(action==='filter'){const select=document.getElementById('plannerStatusFilter');if(select){select.value=event.data.status==='all'?'all':event.data.status==='待處理'?'未開始':event.data.status;select.dispatchEvent(new Event('change',{bubbles:true}));}}
        return;
      }
      if(event.data?.type==='yhn:work-view'){activateNav('home');return}if(event.data?.type!=='yhn:open-existing-tool')return;
      const id=event.data.tool;
      openExistingTool(id);
    });sync();
  });
})();
