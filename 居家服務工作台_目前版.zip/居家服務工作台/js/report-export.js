(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.YhnReportExport=api})(typeof window==='undefined'?globalThis:window,function(){
'use strict';
const schemas={
 '照會':[['項次',null],['案號','caseNumber'],['個案姓名','personName'],['督導','supervisor'],['照會日期','receivedDate'],['回覆日期','responseDate'],['回覆情形','responseStatus'],['現況','currentStatus'],['照會項目','subject'],['繳交日','submittedDate'],['處理情形','reportProcessing'],['行政校閱','adminReview'],['主管校閱','managerReview'],['行政備註','reportAdminNote'],['修正完成','reportFixCompleted'],['補充','reportSupplementary']],
 '異動':[['項次',null],['通報日期','receivedDate'],['通報類型','noticeType'],['通報主旨','subject'],['個案姓名2','personName'],['通報人','sourceOrReporter'],['繳交日','submittedDate'],['處理情形','reportProcessing'],['行政校閱','adminReview'],['主管校閱','managerReview'],['行政備註','reportAdminNote'],['後續追蹤','reportFollowup'],['補充','reportSupplementary']]
};
const dates=new Set(['receivedDate','responseDate','submittedDate']);
function rocDate(value){const s=String(value??'').trim();const m=/^(\d{4})-(\d{2})-(\d{2})(?:T.*)?$/.exec(s);if(!m)return s;return String(Number(m[1])-1911).padStart(3,'0')+m[2]+m[3]}
function monthOf(value){const s=String(value??'');const m=/^(\d{4})-(\d{2})(?:-|$)/.exec(s);if(m&&Number(m[2])>=1&&Number(m[2])<=12)return m[1]+'-'+m[2];return ''}
function reports(records,{month=''}={}){
 const groups=new Map();
 for(const r of records){if(!schemas[r.recordType])throw Error('有案件的文件類型尚未確認，請先核對後再匯出。');const period=monthOf(month)||monthOf(r.receivedDate);const key=period+'|'+r.recordType;if(!groups.has(key))groups.set(key,{period,type:r.recordType,records:[]});groups.get(key).records.push(r)}
 return [...groups.values()].sort((a,b)=>a.period.localeCompare(b.period)||['照會','異動'].indexOf(a.type)-['照會','異動'].indexOf(b.type)).map(g=>{
  const title=(g.period?(Number(g.period.slice(0,4))-1911)+'年'+Number(g.period.slice(5))+'月':'日期待確認')+g.type+'統計明細';const schema=schemas[g.type],headers=schema.map(([h])=>h);while(headers.length<16)headers.push('');
  const rows=g.records.map((r,i)=>{const row=schema.map(([,k])=>k==null?i+1:dates.has(k)?rocDate(r[k]):r[k]==null?'':String(r[k]));while(row.length<16)row.push('');return row});
  return {title,type:g.type,period:g.period,count:rows.length,matrix:[[title,...Array(15).fill('')],headers,...rows]};
 });
}
function csv(matrix){return '\uFEFF'+matrix.map(row=>row.map(value=>{let s=String(value??'');if(/^[\s]*[=+@-]/.test(s)||/^[\t\r]/.test(s))s="'"+s;return '"'+s.replace(/"/g,'""')+'"'}).join(',')).join('\r\n')+'\r\n'}
return {schemas,reports,csv,rocDate};
});
