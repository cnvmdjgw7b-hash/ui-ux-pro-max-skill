const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs');
const X=require('../js/care-plan-export'),R=require('../js/care-plan-renbao'),Zip=require('../quota/jszip.min.js');
const template=fs.readFileSync(__dirname+'/../templates/care-plan-renbao.xlsx');
const layout=require('../templates/care-plan-renbao-layout.json');
const draft={schemaVersion:2,fields:{cpName:'去識別測試甲',rbPlanGender:'女',rbPlanOpenDate:'2026-03-30',rbPlanAssessmentDate:'2026-10-13',rbPlanNextAssessmentDate:'2027-01-13',rbPlanDisabilityCause:'每位個案不同\n原始文字 <>& "',rbPlanModificationContent:'異動內容\n不改寫',rbPlanSupervisor1:'甲',rbPlanSupervisor2:'乙',rbPlanManager:'丙'},caregivers:[{name:'測試居服員',frequency:'週一至週五\n08:00–09:00',rows:[['BA05-1','13','GA09','42'],['BA07','9','BA13','51']]},{name:'測試居服員乙',frequency:'週日',rows:[['BA05-1','5','','']]}],evaluations:[['BA13','目標','完整執行計劃','完整評值','右側欄資料']]};
test('export writes exact template coordinates and keeps merges/styles/print configuration',async()=>{
 const zip=await Zip.loadAsync(template),xml=await zip.file('xl/worksheets/sheet1.xml').async('text'),values=X.cells(draft),filled=X.sheetXml(xml,values);
 assert.equal(values.D24,'BA13');assert.equal(values.F24,'51');assert.equal(values.A28,'BA05-1');assert.equal(values.E30,'完整評值');assert.equal(values.F30,'右側欄資料');assert.equal(values.A34,'督導：甲');assert.equal(values.C34,'督導：乙');assert.equal(values.E34,'主管：丙');
 for(const tag of ['mergeCells','cols'])assert.equal(filled.match(new RegExp('<'+tag+'[^>]*>[\\s\\S]*?</'+tag+'>'))[0],xml.match(new RegExp('<'+tag+'[^>]*>[\\s\\S]*?</'+tag+'>'))[0]);
 assert.equal(filled.match(/<pageSetup[^>]+/)[0],xml.match(/<pageSetup[^>]+/)[0]);
 assert.match(filled,/每位個案不同\n原始文字 &lt;&gt;&amp; &quot;/);assert.ok(!filled.includes('<f>'));
 zip.file('xl/worksheets/sheet1.xml',filled);const bytes=await zip.generateAsync({type:'nodebuffer'}),again=await Zip.loadAsync(bytes);
 assert.deepEqual(await again.file('xl/styles.xml').async('text'),await (await Zip.loadAsync(template)).file('xl/styles.xml').async('text'));
 const out='/tmp/yhn-care-plan-export-test.xlsx';fs.writeFileSync(out,bytes);
});
test('case-specific values do not leak from an earlier export; long text and XML are safe',async()=>{
 const xml=await (await Zip.loadAsync(template)).file('xl/worksheets/sheet1.xml').async('text');
 const second=X.sheetXml(xml,X.cells({fields:{cpName:'去識別測試乙',rbPlanModificationContent:'長文'.repeat(2000)}}));
 assert.ok(!second.includes('去識別測試甲'));assert.ok(!second.includes('測試居服員'));assert.ok(second.includes('長文'.repeat(2000)));assert.match(second,/督導：/);
 assert.throws(()=>X.sheetXml('<worksheet/>',X.cells(draft)),/範本缺少欄位/);
});
test('PDF print layout keeps source merges and full case content without adding table headers',()=>{
 const html=X.printHtml(layout,draft);assert.match(html,/colspan="2"/);assert.match(html,/完整執行計劃/);assert.match(html,/原始文字 &lt;&gt;&amp; &quot;/);assert.match(html,/size:A4 portrait/);assert.ok(!html.includes('<thead>'));assert.ok(!html.includes('問題與需求'));assert.match(html,/另存為 PDF/);
});
test('fixed-template overflow stops export, retaining old draft and values',()=>{
 const old={fields:{rbPlanDiseaseHistory:'病史原文',rbPlanDisabilityCause:'失能原文',rbPlanHousehold:'家況原文',rbPlanModificationDate:'2026-10-12',rbPlanModificationContent:'完整內容'},caregivers:[{}, {},{name:'舊稿居服員'}],evaluations:[['服務','目標','執行','評值','2026-10-19']]};
 const migrated=R.migrate(old);assert.deepEqual(migrated.legacySnapshot,old);assert.ok(migrated.fields.rbPlanDisabilityCause.includes('家況原文'));assert.ok(migrated.fields.rbPlanModificationContent.includes('2026-10-12'));assert.equal(migrated.evaluations[0][4],'2026-10-19');assert.throws(()=>X.cells(migrated),/第 3 組/);assert.equal(old.schemaVersion,undefined);
 assert.throws(()=>X.cells({...draft,evaluations:[...draft.evaluations,[],[],[],['第五列不丟棄']]}),/不會截掉/);
});
test('blank public template contains no source patient text or hidden original shared strings',async()=>{
 const zip=await Zip.loadAsync(template),text=(await Promise.all(Object.keys(zip.files).filter(n=>n.endsWith('.xml')).map(n=>zip.file(n).async('text')))).join('');
 for(const name of ['謝蔡秀雀','廖秋英','李龍生','李芯維','温玉秀'])assert.ok(!text.includes(name));
 assert.match(await zip.file('xl/sharedStrings.xml').async('text'),/count="0"/);
 assert.equal(layout.rows.at(-1).row,34);assert.equal(layout.merges.length,42);
});
