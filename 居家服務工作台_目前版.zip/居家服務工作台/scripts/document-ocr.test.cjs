const {test}=require('node:test'),assert=require('node:assert/strict');
const P=require('../js/document-ocr-core.js');
test('all eight explicit titles classify; ambiguity stays manual',()=>{for(const t of P.TYPES)assert.equal(P.classify(t).type,t);assert.equal(P.classify('照會單\n異動通報').type,null);assert.equal(P.classify('服務事項與姓名').type,null)});
test('photo inbox classifies agency title variants and safely shelves an unsupported reward form',()=>{
 assert.equal(P.classify('異動通報\n個案編號').type,'異動通報');
 assert.equal(P.classify('電話記錄表\n電訪日期：115.09.15').type,'電話訪視紀錄');
 assert.equal(P.classify('居家服務員查核表\n查核項目\n符合\n不符合\n缺失說明').type,'居服員查核表');
 const other=P.classify('花蓮縣私立永護寧居家長照機構\n獎懲申請單');assert.equal(other.type,null);assert.equal(other.unsupported,true);assert.equal(other.archiveCategory,'其他文件｜獎懲申請單');
 const manual=P.parse('獎懲申請單\n內容', '異動通報');assert.equal(manual.type,'異動通報');assert.equal(manual.classification.unsupported,false);assert.equal(manual.classification.manual,true);
});
test('batch archiving only combines pages with one explicit, supported type',()=>{
 const referral=P.parse('照會單\n照會日期：115/10/15','照會單'),change=P.parse('異動通報\n通報日期：115/10/15','異動通報'),unknown=P.parse('獎懲申請單');
 assert.equal(P.sameDocumentType([referral,referral],['照會單','照會單']),true);
 assert.equal(P.sameDocumentType([referral,change],['照會單','異動通報']),false);
 assert.equal(P.sameDocumentType([unknown,referral],['其他文件｜獎懲申請單','照會單']),false);
 assert.equal(P.sameDocumentType([P.parse('無標題'),'待人工分類'],['待人工分類']),false);
});
test('referral uses referral date and subject; no change fields',()=>{const r=P.parse('照會單\n個案姓名：測試甲\n案號：00012\n照會日期：115/10/18\n通報日期：115/10/19\n照會項目：BA07 協助沐浴\n通報主旨：不能混填');assert.equal(r.fields.receivedDate,'2026-10-18');assert.equal(r.fields.caseNumber,'00012');assert.ok(r.fields.subject.startsWith('BA07'));assert.equal(r.fields.serviceTarget,undefined)});
test('spaced OCR labels and supervisor in reporter name do not truncate',()=>{const r=P.parse('異動通報\n個 案 姓 名：測 試 乙\n通 報 日 期：115/10/19\n通報主旨：暫停服務\n通報人：測試督導\n通報目標：個管');assert.equal(r.fields.personName,'測試乙');assert.equal(r.fields.sourceOrReporter,'測試督導');assert.equal(r.fields.supervisor,undefined);assert.equal(r.fields.serviceTarget,'個管')});
test('real change-notice table labels map to existing form fields without AI or field invention',()=>{
 const r=P.parse('異動通報\n個案編號/身分證字號 U220508427（黃秀娥） 通報日期 115/10/12 異動發生日 115/10/05\n通報人 李芯慈 通報主旨 8/5-8/9請假 通報類型 其它\n目前照管中心 花蓮縣長期照顧管理中心\n通報照管中心 花蓮縣長期照顧管理中心\n備註 個案來電告知家人住院8/5-8/9期間請假');
 assert.equal(r.fields.caseNumber,undefined);assert.equal(r.fields.personName,'黃秀娥');assert.equal(r.fields.receivedDate,'2026-10-12');assert.equal(r.fields.reportSupplementary,'115/10/05');
 assert.equal(r.fields.sourceOrReporter,'李芯慈');assert.equal(r.fields.subject,'8/5-8/9請假');assert.equal(r.fields.noticeType,'其它');
 assert.equal(r.fields.serviceTarget,'花蓮縣長期照顧管理中心');assert.equal(r.fields.details,'個案來電告知家人住院8/5-8/9期間請假');
 assert.equal(r.fields.supervisor,undefined);
});
test('case-number and identity combined headers extract a visible name but never treat identity as case number',()=>{
 for(const raw of ['個案編號/身分證字號：黃秀娥/U220508427','個案編號/身分證字號 U220508427（黃秀娥）']){
  const r=P.parse('異動通報\n'+raw);assert.equal(r.fields.personName,'黃秀娥');assert.equal(r.fields.caseNumber,undefined);
 }
});
test('change notice never maps a national identity number into the case number field',()=>{
 const r=P.parse('異動通報\n案號 A123456789\n個案姓名：黃秀娥');assert.equal(r.fields.caseNumber,undefined);assert.ok(r.uncertain.includes('caseNumber'));
});
test('invalid dates, duplicate conflicts, and unknown document stay unfilled',()=>{assert.equal(P.dateValue('115/02/30'),null);assert.equal(P.dateValue('2026-10-19'),'2026-10-19');const r=P.parse('照會單\n個案姓名：測試甲\n個案姓名：測試乙\n照會日期：不詳');assert.equal(r.fields.personName,undefined);assert.equal(r.fields.receivedDate,undefined);assert.ok(r.uncertain.includes('personName'));assert.deepEqual(P.parse('姓名：某人').fields,{})});
test('OCR unmatched symbols and missing important fields require manual confirmation',()=>{const r=P.parse('照會單\n個案姓名：測試甲\n照會項目：BA07 [協助沐浴');assert.equal(r.fields.subject,undefined);assert.ok(r.uncertain.includes('subject'));assert.ok(r.uncertain.includes('receivedDate'))});
test('merge omits conflicts and never merges identities silently',()=>{const x=P.merge([P.parse('照會單\n個案姓名：測試甲'),P.parse('照會單\n個案姓名：測試乙')]);assert.ok(x.uncertain.includes('personName'));assert.equal(x.fields.personName,undefined);assert.equal(P.merge([P.parse('照會單'),P.parse('異動通報')]).mixedTypes,true)});
test('fill changes original controls, fires bookkeeping, protects manual and type',()=>{let events=0,changes=[];const control=(value,tag='INPUT')=>({value,tagName:tag,type:'text',dispatchEvent(){events++}});const controls={recordType:control('照會'),personName:control('測試甲'),subject:control(''),receivedDate:control('')};const form={elements:{namedItem:k=>controls[k]}};const r=P.parse('照會單\n個案姓名：測試甲\n照會日期：115/10/18\n照會項目：BA07');const out=P.fill(form,r,{touched:new Set(['receivedDate']),onField:(k,v)=>changes.push([k,v])});assert.deepEqual(out.applied,['subject']);assert.equal(controls.personName.value,'測試甲');assert.equal(controls.receivedDate.value,'');assert.equal(controls.subject.value,'BA07');assert.equal(events,2);assert.deepEqual(changes,[['subject','BA07']]);controls.recordType.value='異動';assert.ok(P.fill(form,r).reason)});
test('TSV retains geometry, columns and reading order',()=>{const s='level\tpage_num\tblock_num\tpar_num\tline_num\tword_num\tleft\ttop\twidth\theight\tconf\ttext\n5\t1\t1\t1\t1\t1\t10\t20\t30\t12\t90\t個案姓名\n5\t1\t1\t1\t1\t2\t60\t20\t30\t12\t85\t測試甲';const lines=P.linesFromTSV(s);assert.equal(lines[0].text,'個案姓名 測試甲');assert.deepEqual(lines[0].bbox,{left:10,top:20,right:90,bottom:32})});
test('recording regression: combined name/ID header fills only name, not case number',()=>{
 const r=P.parse('照會單\nSi RE 個案姓名/筆)證才號：測試甲/A123456789\n列印日期：115/10/16 08:44:02\n照會日期115/10/15 14:39 Na\n照會項目：BA07 協助沐浴');
 assert.equal(r.fields.personName,'測試甲');assert.equal(r.fields.caseNumber,undefined);assert.equal(r.fields.receivedDate,'2026-10-15');assert.equal(r.fields.subject,'BA07 協助沐浴');assert.ok(r.evidence.personName.label.includes('只取姓名'));
});
test('spaced combined label and timestamp remain separate from print day',()=>{
 const r=P.parse('照會單\n個 案 姓 名/身分證字號：測 試 乙/A123456789\n列印日期：115/10/19 08:00:00\n照 會 日 期115/10/1514:39\n照會項目：BA13 陪同外出');
 assert.equal(r.fields.personName,'測試乙');assert.equal(r.fields.receivedDate,'2026-10-15');assert.equal(P.parse('照會單\n列印日期：115/10/19 08:00:00').fields.receivedDate,undefined);
});
test('combined identities conflict safely; malformed values and invalid times stay manual',()=>{
 let r=P.parse('照會單\n個案姓名/身分證字號：測試甲/A123456789\n個案姓名/身分證字號：測試乙/B123456789');assert.equal(r.fields.personName,undefined);assert.ok(r.uncertain.includes('personName'));
 for(const v of ['115/02/30 14:39','115/10/15 99:99','115/1O/15 14:39'])assert.equal(P.parse('照會單\n照會日期：'+v).fields.receivedDate,undefined);
 r=P.parse('照會單\n個案姓名/身分證字號：測試甲/A12O456789');assert.equal(r.fields.personName,undefined);assert.equal(r.fields.caseNumber,undefined);
});
