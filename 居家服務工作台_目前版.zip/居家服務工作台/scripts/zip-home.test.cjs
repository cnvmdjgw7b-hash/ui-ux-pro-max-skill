const test=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),vm=require('vm');
const read=p=>fs.readFileSync(p,'utf8');
test('daily planner keeps its existing workflows while sharing only the outer navigation',()=>{
 const html=read('planner-home.html');
 for(const id of ['tasksSection','timelineSection','calendarSection','taskDialog','taskGroups','layoutToggle','backupBtn','newBtn','dateInput'])assert.ok(html.includes('id="'+id+'"'),id);
 assert.ok(html.includes('window.yhnPlanBridge.load()'));assert.ok(!html.includes('data=buildDemo()'));assert.ok(!html.includes('supervisor-actions'));assert.ok(!html.includes('<nav class="mobileNav"'));assert.ok(!/class="(?:supervisor-actions|legacy-tools|quick-tool-grid)"/.test(html));
 assert.match(html,/目前未啟用雙向同步/);assert.ok(!html.includes('src="js/shared-site-shell.js"'));
 for(const match of html.matchAll(/<script>([\s\S]*?)<\/script>/g))new vm.Script(match[1]);
 const shell=read('js/full-home-shell.js');assert.ok(shell.includes("document.querySelector('.mobile-bottom-nav')"));assert.ok(shell.includes("id='sharedBottomNav'"));assert.match(shell,/id='sharedMainTabs'/);assert.match(shell,/id='sharedSiteHeader'/);const index=read('index.html'),nav=index.match(/<nav class="mobile-bottom-nav"[\s\S]*?<\/nav>/)?.[0]||'';assert.ok(nav.indexOf('data-mobile-home')<nav.indexOf('data-mobile-calendar')&&nav.indexOf('data-mobile-calendar')<nav.indexOf('mobile-add-action')&&nav.indexOf('mobile-add-action')<nav.indexOf('data-mobile-case')&&nav.indexOf('data-mobile-case')<nav.indexOf('data-mobile-tools'));for(const label of ['儀表盤','看板','列表','表格','日曆'])assert.ok(shell.includes(label));new vm.Script(shell);new vm.Script(read('js/planner-layout.js'));
});
test('director referral work keeps table, import, filters, OCR and original data workflows',()=>{
 const code=read('js/director-cloud.js');new vm.Script(code);
 assert.match(code,/let recordLayout='表格'/);assert.match(code,/let recordTableExpanded=true/);assert.match(code,/\['表格','清單','方格','看板'\]/);
 for(const field of ['reportImportOpen','data-dir-filter="search"','data-dir-filter="recordMonth"','data-dir-filter="supervisor"','data-dir-filter="status"','data-dir-filter="kind"','data-dir-filter="from"','data-dir-filter="to"','OCR 原始辨識結果','OCR 辨識結果','AI 辨識結果','ref-ocr-summary','dirRecordAI'])assert.ok(code.includes(field),field);
 assert.ok(!code.includes('id="directorTabs"'));assert.ok(!code.includes('dir-pomodoro'));
});
test('canonical task edits preserve metadata, in-progress state, concurrent additions and other days',()=>{
 const key='yhn_supervisor_daily_plans_v1';let raw=JSON.stringify({'2026-10-20':{focus:'原重點',reflection:'複盤',tasks:[{id:'a',title:'家訪',start:'09:00',end:'10:00',category:'家訪',status:'進行中',priority:'重要',caseRef:'keep'}]},'2026-10-21':{tasks:[{id:'b',title:'明日'}]}});
 const context={window:{},structuredClone,localStorage:{getItem:()=>raw,setItem:(k,v)=>{assert.equal(k,key);raw=v}}};vm.runInNewContext(read('js/planner-bridge.js'),context);const bridge=context.window.yhnPlanBridge,tasks=bridge.load();tasks[0].title='修正家訪';const concurrent=JSON.parse(raw);concurrent['2026-10-20'].tasks.push({id:'c',title:'另一頁新增'});raw=JSON.stringify(concurrent);bridge.save(tasks);let saved=JSON.parse(raw);assert.equal(saved['2026-10-20'].focus,'原重點');assert.equal(saved['2026-10-20'].tasks[0].caseRef,'keep');assert.equal(saved['2026-10-20'].tasks[0].status,'進行中');assert.equal(saved['2026-10-20'].tasks.length,2);assert.equal(saved['2026-10-21'].tasks[0].title,'明日');
 const next=bridge.load();next[0].done=true;bridge.save(next);assert.equal(JSON.parse(raw)['2026-10-20'].tasks[0].status,'已完成');
});
