from pathlib import Path
import shutil
root=Path(__file__).resolve().parents[1]
dist=root/'dist'
if dist.exists(): shutil.rmtree(dist)
dist.mkdir()
for name in ['index.html','style.css','logo.png','original-longcare-logo.png','serviceData.js','script.js','script.legacy.js','js','law']:
    p=root/name
    if p.is_dir(): shutil.copytree(p,dist/name)
    elif p.exists(): shutil.copy2(p,dist/name)
print('Static toolbox prepared.')
