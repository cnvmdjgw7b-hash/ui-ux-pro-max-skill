const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const root=path.resolve(__dirname,'..');
const source=fs.readFileSync(root+'/js/director-cloud.js','utf8');
const s={Date,Set,Map,URL,Blob,TextEncoder,setTimeout,clearTimeout,window:{addEventListener(){}},document:{getElementById:()=>null,querySelector:()=>null,querySelectorAll:()=>[],body:{classList:{toggle(){}}}},console};
const hook="window.test={calendarEventButton,calendarTodo,calendarLabels};";
vm.runInNewContext(source.slice(0,source.lastIndexOf('})();'))+hook+source.slice(source.lastIndexOf('})();')),s);
const t=s.window.test,colors=new Set();
for(const [type,[key]] of Object.entries(t.calendarLabels)){
 const e={type,entity:'case',id:'test',field:'dueDate',label:'<測試>'};
 const chip=t.calendarEventButton(e),agenda=t.calendarTodo(e);
 assert(chip.includes('data-label-color="'+key+'"'));assert(agenda.includes('data-label-color="'+key+'"'));
 assert(chip.includes('&lt;測試&gt;'));assert(chip.includes('data-calendar-drag="true"'));assert(agenda.includes('data-calendar-complete="test"'));colors.add(key);
}
assert.equal(colors.size,6);
const visit=fs.readFileSync(root+'/js/visit.js','utf8');const c={};vm.runInNewContext(visit,c);
assert.deepEqual([1,7,10,11,20,21].map(c.chineseNumber),['一','七','十','十一','二十','二十一']);
const html=fs.readFileSync(root+'/index.html','utf8');for(const id of ['printVisitForm','printHomeFormPreview'])assert(new RegExp('id="'+id+'"[^>]*>下載可編輯 Word').test(html));
console.log('PASS: six calendar label types retain drag/edit/complete and escaping; Chinese numbering and both home Word controls.');
