const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs');
const L=require('../js/care-plan-linkage'),X=require('../js/care-plan-export'),layout=require('../templates/care-plan-renbao-layout.json');
const cat=[{code:'BA07',name:'協助沐浴及洗頭',goal:'維持清潔及安全',plan:'依體力協助沐浴，留意安全。'},{code:'BA13',name:'陪同外出',goal:'安全參與社區活動',plan:'出門前確認體力與輪椅安全。'}];
const base=()=>({schemaVersion:2,fields:{cpName:'測試甲',rbPlanOpenDate:'2026-03-30'},caregivers:[],evaluations:[]});
test('three calendar months, year rollover, short months, leap year and invalid dates',()=>{
 assert.equal(L.nextReview('2026-10-12'),'2027-01-12');assert.equal(L.nextReview('2026-11-30'),'2027-02-28');assert.equal(L.nextReview('2023-11-30'),'2024-02-29');assert.equal(L.nextReview('2026-08-31'),'2026-11-30');assert.equal(L.nextReview('2026-02-30'),'');assert.equal(L.iso('1151012'),'2026-10-12');
 assert.equal(L.reviewProblem({rbPlanAssessmentDate:'2026-10-12',rbPlanNextAssessmentDate:'2027-01-12'}),'');assert.match(L.reviewProblem({rbPlanAssessmentDate:'2026-10-12',rbPlanNextAssessmentDate:'2027-01-13'}),/不得超過/);assert.equal(L.reviewProblem({rbPlanAssessmentDate:'2026-10-12',rbPlanNextAssessmentDate:'2026-12-01'}),'');assert.match(L.reviewProblem({rbPlanEffectiveDate:'2026-10-12',rbPlanNextAssessmentDate:'2026-10-12'}),/晚於/);
});
test('roster name/open date fill only current case and protect a manually corrected opening date',()=>{
 const d=L.seedCase({fields:{}},{id:'a',name:'測試甲',serviceStart:'115/03/30'});assert.equal(d.fields.cpName,'測試甲');assert.equal(d.fields.rbPlanOpenDate,'2026-03-30');assert.equal(L.seedCase({fields:{rbPlanOpenDate:'2026-02-01'}},{name:'測試甲',serviceStart:'2026-03-30'}).fields.rbPlanOpenDate,'2026-02-01');assert.equal(L.seedCase({}, {name:'測試乙'}).fields.rbPlanOpenDate,'');assert.notEqual(L.key({id:'a',name:'同名'}),L.key({id:'b',name:'同名'}));
});
test('legacy illness, consciousness, family and services merge once while preserving source fields',()=>{
 const old={cpHealthNote:'既有疾病原文',cpFamilyNote:'既有家庭原文',cpCare:'BA13 陪同外出',cpGap:'下午人力待確認'},one=L.legacyMerge(base(),old),two=L.legacyMerge(one,old);
 assert.deepEqual(one,two);assert.equal(one.legacyFields.cpCare,old.cpCare);assert.equal(one.fields.rbPlanDisabilityCause,'既有疾病原文');assert.equal(one.fields.rbPlanFamilySupport,'既有家庭原文');assert.equal(one.fields.rbPlanExecution,'BA13 陪同外出');
 let d=L.selectionMerge(one,{cognition:['意識清楚','情緒穩定'],diseases:['高血壓']});assert.match(d.fields.rbPlanPhysical,/意識清楚/);assert.match(d.fields.rbPlanPsychological,/情緒穩定/);assert.ok(!d.fields.rbPlanPhysical.includes('情緒穩定'));assert.match(d.fields.rbPlanDisabilityCause,/高血壓/);assert.match(d.fields.rbPlanDisabilityCause,/既有疾病原文/);
 d=L.selectionMerge(d,{cognition:[],diseases:['高血壓']});assert.equal(d.fields.rbPlanPhysical,'');
 const edited=L.legacyMerge({...one,fields:{...one.fields,rbPlanDisabilityCause:'人工修正的摘要'}},{...old,cpHealthNote:'來源後來修改'});assert.equal(edited.fields.rbPlanDisabilityCause,'人工修正的摘要');assert.ok(edited.linkageWarnings.length);
});
test('only matching visits merge; repeated updates keep manual work and original wording',()=>{
 const v={name:'測試甲',caseNo:'A',date:'2026-10-12',healthNote:'今天想出去走走。',familyResponse:'家屬表示服務良好。',treatment:'一、個案狀況\n保留原文\n二、服務情形\n依既有安排',services:[{code:'BA13',name:'陪同外出'}]};
 const a=L.visitMerge(base(),v,{name:'測試甲',caseNo:'A'});assert.equal(a.applied,true);assert.match(a.data.fields.rbPlanModificationContent,/一、個案狀況\n保留原文/);assert.equal(a.data.fields.rbPlanAssessmentDate,'2026-10-12');assert.deepEqual(L.visitMerge(a.data,v,{name:'測試甲',caseNo:'A'}).data,a.data);
 assert.equal(L.visitMerge(base(),v,{name:'測試乙',caseNo:'B'}).applied,false);assert.equal(L.visitMerge(base(),v,{name:'測試甲',caseNo:'B'}).applied,false);
 assert.equal(L.visitMerge(base(),{name:'測試甲',date:'2026-10-19'},{name:'測試甲'}).applied,false);
 const changed={...a.data,fields:{...a.data.fields,rbPlanDisabilityCause:'已由人員修正'}};assert.equal(L.visitMerge(changed,{...v,healthNote:'新的文字'},{name:'測試甲',caseNo:'A'}).data.fields.rbPlanDisabilityCause,'已由人員修正');
});
test('services continue without duplicate rows or invented units; goals/plans stay editable and outcomes use real observations',()=>{
 const first=L.continueServices(base(),[{code:'BA13',name:'陪同外出'}],cat),again=L.continueServices(first,[{code:'BA13',name:'陪同外出'}],cat);assert.deepEqual(first,again);assert.equal(first.caregivers[0].rows[0][0],'BA13 陪同外出');assert.equal(first.caregivers[0].rows[0][1],'');assert.equal(first.evaluations[0][1],'安全參與社區活動');assert.equal(first.evaluations[0][3],'');
 const manual={...first,evaluations:[['BA13','人工目標','人工執行','人工評值','']]};assert.equal(L.continueServices(manual,[],cat).evaluations[0][3],'人工評值');assert.equal(L.visitEvaluations(manual,{date:'2026-10-12',familyResponse:'願意增加外出',services:[{code:'BA13'}]}).evaluations[0][3],'人工評值');
 const reviewed=L.visitEvaluations(first,{date:'2026-10-12',familyResponse:'願意增加外出',services:[{code:'BA13'}]});assert.equal(reviewed.evaluations[0][3],'家訪 2026-10-12\n家屬整體回應：願意增加外出');assert.ok(!reviewed.evaluations[0][3].includes('已達成'));
 assert.equal(L.codeOf('BA17d1 血糖機驗血糖'),'BA17D1');assert.notEqual(L.codeOf('BA17d1'),L.codeOf('BA17d2'));
});
test('more services than the fixed template exposes unresolved entries and blocks export',()=>{
 const codes=['BA01','BA02','BA03','BA04','BA05','BA06','BA07'],d=L.continueServices(base(),codes.map(code=>({code,name:'測試服務'})),cat);assert.ok(d.pendingServiceItems.length);assert.ok(d.pendingEvaluationItems.length);assert.throws(()=>X.cells(d),/尚未完整/);
});
test('fit gate blocks overflowing Chinese, long Latin and explicit line breaks without changing template or text',()=>{
 const short=base();assert.deepEqual(X.fitProblems(layout,short),[]);
 for(const text of ['完整原文'.repeat(1000),'x'.repeat(2000),'一\n'.repeat(100)]){const d=base();d.fields.rbPlanPhysical=text;const errors=X.fitProblems(layout,d);assert.ok(errors.some(x=>x.ref==='A11'));assert.throws(()=>X.printHtml(layout,d),/超過固定模板/);assert.equal(d.fields.rbPlanPhysical,text)}
 const unreviewed=base();unreviewed.fields.rbPlanAssessmentDate='2026-10-12';assert.throws(()=>X.cells(unreviewed),/下次複評/);
});
test('one canonical UI hides old duplicate surfaces, moves native options and keeps save explicit',()=>{
 const s=fs.readFileSync(__dirname+'/../js/care-plan-unified-ui.js','utf8');assert.match(s,/oldLabel\.hidden=true/);assert.match(s,/oldSection\.hidden=true/);assert.match(s,/label\.before\(detail\)/);assert.match(s,/renbaoPlansByCase:map/);assert.ok(!s.includes('recordPlanSaved'));assert.ok(!s.includes('fetch('));
 const pick=fs.readFileSync(__dirname+'/../js/case-picker.js','utf8');assert.match(pick,/yhn:selected-case/);const visit=fs.readFileSync(__dirname+'/../js/visit.js','utf8');assert.match(visit,/yhn:home-visit-draft/);
});
