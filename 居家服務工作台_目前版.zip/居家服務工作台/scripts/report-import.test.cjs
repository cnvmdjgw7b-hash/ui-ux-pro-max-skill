const assert = require('node:assert/strict');
global.window = {};
require('../js/report-import.js');
const { parseWorkbook } = window.YhnReportImport;
const cells = {
  A1:{v:'115年10月照會'},
  A2:{v:'項次'},B2:{v:'個案姓名'},C2:{v:'案號'},D2:{v:'照會日期'},E2:{v:'督導'},F2:{v:'通報目標'},G2:{v:'照會項目'},H2:{v:'處理情形'},I2:{v:'行政校閱'},J2:{v:'主管校閱'},
  A3:{v:1},B3:{v:'測試個案'},C3:{v:'Y001'},D3:{v:'115/10/01'},E3:{v:'測試督導'},F3:{v:'居家'},G3:{v:'洗澡異動'},H3:{v:'已通知'},I3:{v:'OK'},J3:{v:'待核'},
  A4:{v:1},B4:{v:'測試個案'},C4:{v:'Y001'},D4:{v:'115/10/01'},E4:{v:'測試督導'},F4:{v:'陪診'},G4:{v:'陪同就醫'},H4:{v:'待回覆'},I4:{v:'待校閱'},J4:{v:'待核'},
  A5:{v:1},B5:{v:'測試個案'},C5:{v:'Y001'},D5:{v:'115/10/01'},E5:{v:'測試督導'},F5:{v:'居家'},G5:{v:'洗澡異動'},H5:{v:'已通知'},I5:{v:'OK'},J5:{v:'待核'},
  A6:{v:2},B6:{v:'另一個案'},C6:{v:'Y002'},D6:{v:'不明日期'},E6:{v:'測試督導'},F6:{v:'居家'},G6:{v:'其他異動'},H6:{t:'e',v:'#VALUE!'},I6:{v:''},J6:{v:''}
};
const parsed = parseWorkbook({SheetNames:['10月照會'],Sheets:{'10月照會':cells},Workbook:{Sheets:[{}]}},{fileName:'test.xlsx'});
assert.equal(parsed.rows.length,3,'同項次但服務內容不同的列須保留，完全重複列略過');
assert.equal(parsed.rows[0].fields.receivedDate,'2026-10-01','民國日期須轉成 ISO 日期');
assert.equal(parsed.rows[1].fields.serviceTarget,'陪診');
assert.ok(parsed.warnings.some(x=>x.includes('同檔重複列')));
assert.ok(parsed.warnings.some(x=>x.includes('日期無法辨識')));
assert.ok(parsed.warnings.some(x=>x.includes('Excel公式錯誤')));
console.log('照會異動解析測試通過：欄位對應、民國日期、相異服務保留、重複列及公式異常。');
