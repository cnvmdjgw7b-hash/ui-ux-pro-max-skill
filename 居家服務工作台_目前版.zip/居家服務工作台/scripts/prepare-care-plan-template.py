"""Extract a patient-free fixed template for the web exporter.
Only text is replaced; original style, merges, widths and print settings remain.
The source patient workbook must never be copied into the repository.
"""
import sys, zipfile, json, re, copy
from xml.sax.saxutils import escape
from pathlib import Path
from xml.etree import ElementTree as E

src=Path(sys.argv[1]); out=Path(__file__).resolve().parents[1]/'templates'
out.mkdir(exist_ok=True)
N='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
ns={'m':N}
E.register_namespace('',N)
E.register_namespace('r','http://schemas.openxmlformats.org/officeDocument/2006/relationships')
fixed={
 'A1':'花蓮縣私立永護寧居家長照機構','A2':'居家服務個案照護計劃',
 'A4':'※個案姓名：','D4':'※性別：','A5':'※開案日期：',
 'A6':'一、照護計畫版本','A7':'生效日期：','C7':'評估日期：','E7':'下次評估日期：',
 'A8':'□ 初評\n□ 複評，變更原因簡述：','A9':'二、個案身心及家庭評估簡述',
 'A10':'失能原因及現況：','A11':'1. 個案生理狀況：','A12':'2. 個案心理狀況：',
 'A13':'3. 家庭支持功能：','A14':'4. 經濟與社會資源：',
 'A15':'三、居家服務提供及執行情形','A17':'四、需求評估或服務計畫修正',
 'A19':'五、照護項目及照顧服務計畫','A20':'1. 居服員：',
 'A21':'2. 服務頻率及估計時間：','A22':'服務項目','C22':'次數','D22':'服務項目','F22':'次數',
 'A25':'1. 居服員2：','A26':'2. 服務頻率及估計時間：',
 'A27':'服務項目','C27':'次數','D27':'服務項目','F27':'次數',
 'A29':'六、照顧服務計畫執行及評值表','A34':'督導：','C34':'督導：','E34':'主管：'
}
with zipfile.ZipFile(src) as z:
 root=E.fromstring(z.read('xl/worksheets/sheet1.xml'))
 for c in root.findall('.//m:sheetData/m:row/m:c',ns):
  for child in list(c):c.remove(child)
  c.set('t','inlineStr')
  t=E.SubElement(E.SubElement(c,'{'+N+'}is'),'{'+N+'}t')
  t.set('{http://www.w3.org/XML/1998/namespace}space','preserve')
  t.text=fixed.get(c.get('r'),'')
 # Preserve original namespace declarations and every non-cell byte. Serializing
 # with ElementTree would drop prefixes named in mc:Ignorable and can cause an
 # Excel repair prompt despite parseable XML.
 def blank_cell(match):
  attrs=match[1];ref=match[2]
  attrs=re.sub(r'\s+t="[^"]*"','',attrs)
  return '<c'+attrs+' t="inlineStr"><is><t xml:space="preserve">'+escape(fixed.get(ref,''))+'</t></is></c>'
 sheet=re.sub(r'<c\b([^>]*?\br="([A-Z]+\d+)"[^>]*?)(?:/>|>[\s\S]*?</c>)',blank_cell,z.read('xl/worksheets/sheet1.xml').decode('utf-8')).encode('utf-8')
 with zipfile.ZipFile(out/'care-plan-renbao.xlsx','w',zipfile.ZIP_DEFLATED) as target:
  for item in z.infolist():
   data=z.read(item.filename)
   if item.filename=='xl/worksheets/sheet1.xml':data=sheet
   elif item.filename=='xl/sharedStrings.xml':data=('<?xml version="1.0"?><sst xmlns="'+N+'" count="0" uniqueCount="0"/>').encode()
   elif item.filename in ('docProps/core.xml','xl/persons/person.xml'):
    x=E.fromstring(data)
    for child in list(x):x.remove(child)
    data=E.tostring(x,encoding='utf-8',xml_declaration=True)
   target.writestr(copy.copy(item),data)
 styles=E.fromstring(z.read('xl/styles.xml'))
 fonts=list(styles.find('m:fonts',ns));fills=list(styles.find('m:fills',ns));borders=list(styles.find('m:borders',ns))
 css=[]
 for xf in styles.find('m:cellXfs',ns):
  font=fonts[int(xf.get('fontId','0'))]; a=xf.find('m:alignment',ns)
  def val(tag,default):
   e=font.find('m:'+tag,ns);return e.get('val',default) if e is not None else default
  # Keep the template font family, size, alignment and solid fills.
  d={'font-family':val('name','sans-serif'),'font-size':val('sz','11')+'pt',
     'font-weight':'bold' if font.find('m:b',ns) is not None else 'normal',
     'text-align':a.get('horizontal','left') if a is not None else 'left',
     'vertical-align':{'center':'middle'}.get(a.get('vertical','top'),a.get('vertical','top')) if a is not None else 'top'}
  for edge in ['top','right','bottom','left']:
   e=borders[int(xf.get('borderId','0'))].find('m:'+edge,ns)
   if e is not None and e.get('style'):d['border-'+edge]='1px solid #000'
  p=fills[int(xf.get('fillId','0'))].find('m:patternFill',ns)
  if p is not None and p.get('patternType')=='solid':
   fg=p.find('m:fgColor',ns)
   if fg is not None and fg.get('rgb'):d['background-color']='#'+fg.get('rgb')[-6:]
  css.append(d)
 rows=[]
 for r in root.findall('m:sheetData/m:row',ns):
  rows.append({'row':int(r.get('r')),'height':float(r.get('ht','15')),
   'cells':[{'ref':c.get('r'),'style':int(c.get('s','0')),'text':fixed.get(c.get('r'),'')} for c in r]})
 layout={'rows':rows,'styles':css,'merges':[m.get('ref') for m in root.findall('m:mergeCells/m:mergeCell',ns)],
         'widths':[15,15,15,19.453125,19.453125,18],'schemaVersion':2}
 (out/'care-plan-renbao-layout.json').write_text(json.dumps(layout,ensure_ascii=False),encoding='utf-8')
print('Patient-free template and layout prepared; original workbook unchanged.')
