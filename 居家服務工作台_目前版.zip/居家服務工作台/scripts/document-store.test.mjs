import {test} from 'node:test';import assert from 'node:assert/strict';
import {properties,EXTRA_FIELDS,extraRead,extraWrite,notionWrite,notionRead,notionConfigured,fileTicket,fileUrl,privateFile} from '../server/document-store.mjs';
class Bucket{constructor(){this.m=new Map();this.rev=0}async get(k){const o=this.m.get(k);return o?{etag:String(o.rev),text:async()=>o.s,body:o.s,httpMetadata:o.httpMetadata}:null}async put(k,s,options={}){if(options.onlyIf?.etagDoesNotMatch==='*'&&this.m.has(k))return null;this.m.set(k,{s,rev:++this.rev,httpMetadata:options.httpMetadata});return {etag:String(this.rev)}}async delete(k){this.m.delete(k)}async list({prefix}){return {objects:[...this.m.keys()].filter(k=>k.startsWith(prefix)).map(key=>({key})),truncated:false}}}
test('six original field keys roundtrip with owner isolation',async()=>{const env={BUCKET:new Bucket()},fields=Object.fromEntries(EXTRA_FIELDS.map(k=>[k,k+'測試']));await extraWrite(env,'owner',123,{...fields,ocrDocuments:[{rawText:'測試OCR'}]});const [r]=await extraRead(env,'owner',[{id:123}]);for(const k of EXTRA_FIELDS)assert.equal(r[k],fields[k]);assert.equal(r.ocrDocuments[0].rawText,'測試OCR');assert.equal((await extraRead(env,'other',[{id:123}]))[0].reportProcessing,undefined)});
test('Notion select mismatch is retained without inventing status',()=>{const schema={properties:{個案姓名:{type:'title'},現況:{type:'select',select:{options:[{name:'服務中'}]}},照會日期:{type:'date'}}};const out=properties({recordType:'照會',personName:'TEST測試',currentStatus:'過去',receivedDate:'2026-10-18'},schema);assert.equal(out.properties.現況,undefined);assert.equal(out.warnings.length,1);assert.equal(out.properties.照會日期.date.start,'2026-10-18')});
test('missing Notion authorization reports failure, not a save success',async()=>{const env={BUCKET:new Bucket()};await assert.rejects(notionWrite(env,'test',{data:{recordType:'照會',personName:'TEST',clientRequestId:crypto.randomUUID()}}),/授權尚未設定/)});
test('private photo tickets enforce owner, size and expiry',async()=>{const env={BUCKET:new Bucket()},ticket=await fileTicket(env,'owner',{contentType:'image/png',sizeBytes:3});assert.equal(await fileUrl('other',ticket.storageKey),null);await assert.rejects(privateFile(env,'other',new Request('https://test/api?key='+encodeURIComponent(ticket.storageKey))),/未授權/);const put=await privateFile(env,'owner',new Request('https://test/api?key='+encodeURIComponent(ticket.storageKey),{method:'PUT',headers:{'Content-Type':'image/png'},body:Uint8Array.from([1,2,3])}));assert.equal(put.status,204);const get=await privateFile(env,'owner',new Request('https://test/api?key='+encodeURIComponent(ticket.storageKey)));assert.equal((await get.arrayBuffer()).byteLength,3);assert.equal(get.headers.get('Cache-Control'),'private, no-store')});
test('storage key is not mistaken for a Notion token',()=>{assert.equal(notionConfigured({NOTION_STORAGE_KEY:'arbitrary-encryption-key'}),false);assert.equal(notionConfigured({NOTION_STORAGE_KEY:'ntn_TEST_ONLY'}),true)});
test('mock Notion contract: create, six fields/raw text, edit, two readers, stale-write protection',async()=>{
 // Contract fixture only. This test does not establish any live Notion connection.
 const original=globalThis.fetch,pages=new Map(),blocks=new Map(),env={BUCKET:new Bucket(),YHN_NOTION_TOKEN:'TEST_ONLY'};let tick=0,creates=0;
 const timestamp=()=>new Date(1800000000000+(++tick)*1000).toISOString();
 const withType=props=>Object.fromEntries(Object.entries(props).map(([k,v])=>[k,{type:Object.keys(v)[0],...v}]));
 const schema={properties:Object.fromEntries(['個案姓名','通報日期','通報類型','通報主旨','通報人','通報目標','處理情形','行政備註','後續追蹤','補充','繳交日'].map(k=>[k,k==='個案姓名'?{type:'title'}:k.endsWith('日期')||k==='繳交日'?{type:'date'}:k==='通報類型'?{type:'select',select:{options:[{name:'暫停服務'}]}}:{type:'rich_text'}]))};
 globalThis.fetch=async(url,options={})=>{const path=new URL(url).pathname.replace('/v1/',''),body=options.body?JSON.parse(options.body):null;let result;
  if(path.startsWith('data_sources/'))result=schema;
  else if(path==='pages'&&options.method==='POST'){creates++;const id=crypto.randomUUID(),blockId=crypto.randomUUID();result={id,properties:withType(body.properties),last_edited_time:timestamp()};pages.set(id,result);blocks.set(id,[{id:blockId,...body.children[0]}]);}
  else if(path.startsWith('pages/')){result=pages.get(path.split('/')[1]);if(options.method==='PATCH'){Object.assign(result.properties,withType(body.properties));result.last_edited_time=timestamp()}}
  else if(path.includes('/children')){const list=blocks.get(path.split('/')[1]);if(body?.children)list.push(...body.children.map(x=>({id:crypto.randomUUID(),...x})));result={results:list,has_more:false};}
  else if(path.startsWith('blocks/')&&options.method==='PATCH'){for(const [id,list]of blocks){const b=list.find(x=>x.id===path.split('/')[1]);if(b){b.code=body.code;pages.get(id).last_edited_time=timestamp();result=b;break}}}
  if(!result)throw Error('Unexpected mock endpoint '+path);return Response.json(structuredClone(result));
 };
 try{const data={recordType:'異動',personName:'TEST測試乙',clientRequestId:crypto.randomUUID(),receivedDate:'2026-10-19',subject:'暫停服務',noticeType:'暫停服務',...Object.fromEntries(EXTRA_FIELDS.map(k=>[k,'TEST '+k])),ocrDocuments:[{rawText:'測試原文',correctedText:'人工核對原文'}]};const created=await notionWrite(env,'same-owner',{data});assert.equal(created.notionSync,'synced');assert.equal(creates,1);for(const k of EXTRA_FIELDS)assert.equal(created.record[k],data[k]);
  const readerA=(await notionRead(env,'same-owner'))[0],readerB=(await notionRead(env,'same-owner'))[0];assert.deepEqual(readerA,readerB);const edited=await notionWrite(env,'same-owner',{id:readerA.id,data:{...readerA,reportProcessing:'人工修正處理情形'}});assert.equal(edited.record.reportProcessing,'人工修正處理情形');assert.equal((await notionRead(env,'same-owner'))[0].reportProcessing,'人工修正處理情形');assert.equal(creates,1);assert.equal([...blocks.values()][0].length,2);await assert.rejects(notionWrite(env,'same-owner',{id:readerB.id,data:readerB}),/其他裝置已更新/);await assert.rejects(notionWrite(env,'other-owner',{id:readerA.id,data:readerA}),/不屬於/);
 }finally{globalThis.fetch=original}
});
test('recording save regression: followupAction survives legacy roundtrip and edits without status replacement',async()=>{
 const env={BUCKET:new Bucket()},user='TEST-owner',id=991;
 const first='仁寶：待確認；照顧計畫：待確認；班表截圖未上傳；主任待核';
 await extraWrite(env,user,id,{followupAction:first,reportProcessing:'人工處理內容'});
 const [saved]=await extraRead(env,user,[{id,followupAction:'另一種伺服器摘要',finalStatus:'待追蹤'}]);
 assert.equal(saved.followupAction,first);assert.equal(saved.finalStatus,'待追蹤');
 await extraWrite(env,user,id,{followupAction:'無需後續'});
 const [updated]=await extraRead(env,user,[{id,finalStatus:'完成'}]);assert.equal(updated.followupAction,'無需後續');assert.equal(updated.reportProcessing,'人工處理內容');assert.equal(updated.finalStatus,'完成');
 assert.equal((await extraRead(env,'TEST-other',[{id,followupAction:'原值'}]))[0].followupAction,'原值');
 const history=[...env.BUCKET.m].filter(([k])=>k.includes('/legacy-history/'));assert.equal(history.length,1);assert.equal(JSON.parse(history[0][1].s).fields.followupAction,first);
});
