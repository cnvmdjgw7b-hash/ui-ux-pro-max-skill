const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');

const context={window:{}};
vm.runInNewContext(fs.readFileSync('js/work-calendar.js','utf8'),context);
const render=context.window.yhnWorkCalendarUI.render;
const cursor=new Date(2026,8,1);
const tasks=[
  {id:'a',title:'回覆林先生照會',category:'照會',date:'2026-09-01',time:'09:00',person:'王督導',note:'確認資料',status:'待處理'},
  {id:'b',title:'異動通報',category:'異動',date:'2026-09-01',time:'10:30',person:'李督導',status:'已完成'},
  {id:'c',title:'送件公所',category:'送件',date:'2026-09-01',time:'13:00',person:'王督導',status:'追蹤中'},
  {id:'d',title:'附約期限確認',category:'附約',date:'2026-09-01',time:'15:00',person:'林督導',status:'待處理'},
  {id:'e',title:'新增第5項',category:'照會',date:'2026-09-01',time:'16:00',person:'王督導',status:'待處理'},
  {id:'f',title:'十月家訪',category:'家訪',date:'2026-10-03',time:'08:00',person:'林督導',status:'待處理'},
];
const base={tasks,date:'2026-09-01',cursor,query:'',category:'all'};

test('six calendar modes render their distinct layouts with shared actionable tasks',()=>{
  const modes=['month','day','week','table','agenda','year'];
  const results=Object.fromEntries(modes.map(mode=>[mode,render({...base,mode})]));
  assert.match(results.month.html,/calendar-month-grid/);
  assert.doesNotMatch(results.month.html,/calendar-selected-agenda/);
  assert.match(results.day.html,/calendar-day-view/);
  assert.match(results.week.html,/calendar-week-grid/);
  assert.match(results.table.html,/calendar-table/);
  assert.match(results.agenda.html,/calendar-month-grid[\s\S]*calendar-selected-agenda/);
  assert.match(results.year.html,/calendar-year-grid/);
  for(const mode of ['day','week','table','agenda']){
    assert.match(results[mode].html,/data-mark="a"/);
    assert.match(results[mode].html,/data-edit="a"/);
    assert.match(results[mode].html,/data-delete="a"/);
  }
  assert.equal(results.month.categoryOptions.length,5);
  assert.match(results.month.summary,/照會/);
});

test('search and category filters apply consistently and escaped task content stays safe',()=>{
  const filtered=render({...base,mode:'table',query:'王督導',category:'照會'});
  assert.match(filtered.html,/回覆林先生照會/);
  assert.doesNotMatch(filtered.html,/異動通報|送件公所/);
  const escaped=render({...base,tasks:[{...tasks[0],title:'<script>alert(1)</script>'}],mode:'day'});
  assert.doesNotMatch(escaped.html,/<script>/);
  assert.match(escaped.html,/&lt;script&gt;/);
});

test('many same-day events expand in month and concise agenda views',()=>{
  const month=render({...base,mode:'month'}).html;
  assert.match(month,/data-expand-day="2026-09-01"/);
  const concise=render({...base,mode:'agenda'}).html;
  assert.match(concise,/展開全部 5 項行程/);
  const expanded=render({...base,mode:'agenda',agendaExpanded:true}).html;
  assert.match(expanded,/新增第5項/);
  assert.match(expanded,/收合行程/);
});
