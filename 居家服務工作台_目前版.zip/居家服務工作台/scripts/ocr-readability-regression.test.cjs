const {test}=require('node:test'),assert=require('node:assert/strict');
const P=require('../js/document-ocr-core.js'),C=require('../js/form-readability.js');
const control=value=>({value,type:'text',tagName:'INPUT',dispatchEvent(){}});
const form=values=>({elements:{namedItem:key=>values[key]}});
test('reported label substitutions recover explicit fields, not print dates or assessor',()=>{
 const r=P.parse('服務提供單位照會單\n個霧姓名/訊證二號：測試甲/A123456789\n列印日期：115/10/16 08:44:02\n評估照專：測試乙\n照曾日期：115/10/15\n照會項日：SC09 居家短照服務');
 assert.equal(r.fields.personName,'測試甲');assert.equal(r.fields.receivedDate,'2026-10-15');assert.equal(r.fields.subject,'SC09 居家短照服務');assert.equal(r.fields.supervisor,undefined);
 const bad=P.parse('照會單\n個霧姓名/訊證二號：測試甲/U20230808\n列印日期：115/10/16');assert.equal(bad.fields.personName,undefined);assert.equal(bad.fields.receivedDate,undefined);
});
test('table tab separates actual label and value',()=>{const r=P.parse('照會單\n個案姓名\t測試甲\n照會日期\t115/10/15\n照會項目\tBA07');assert.equal(r.fields.personName,'測試甲');assert.equal(r.fields.subject,'BA07')});
test('different patient prevents partial filling into wrong case',()=>{const values={recordType:control('照會'),personName:control('人工姓名'),subject:control('')};const out=P.fill(form(values),P.parse('照會單\n個案姓名：測試甲\n照會項目：BA07'));assert.match(out.reason,/身分不同/);assert.equal(values.subject.value,'')});
test('same-source OCR correction updates untouched OCR value only',()=>{const values={recordType:control('照會'),subject:control('錯誤內容')},previous={subject:'錯誤內容'},parsed=P.parse('照會單\n照會項目：SC09 居家短照服務');assert.deepEqual(P.fill(form(values),parsed,{previous}).applied,['subject']);values.subject.value='人工修正';assert.deepEqual(P.fill(form(values),parsed,{previous,touched:new Set(['subject'])}).applied,[]);assert.equal(values.subject.value,'人工修正')});
test('all six existing themes have readable input and primary button text',()=>{const themes=[['#FFFFFF','#17344F','#C63054'],['#FFFFFF','#17344F','#D36384'],['#FFFFFF','#17344F','#FF929A'],['#233B54','#EAF4FB','#8CCCF0'],['#4B3528','#FFF0E2','#FFB66E'],['#2A4439','#EDF7EF','#B6DFC0']];for(const [bg,ink,brand]of themes){assert.ok(C.ratio(bg,ink)>=4.5);assert.ok(C.ratio(brand,C.onBrand(brand))>=4.5)}});
