const {test}=require('node:test'),assert=require('node:assert/strict');
const P=require('../js/document-ocr-core.js');
test('merged referral table keeps service rows above and below its label, not remarks quantities',()=>{const r=P.parse('照會單\n照會日期：115/10/15\n項目\nBA07[協助沐浴及洗頭] ×18\nBA13[陪同外出] ×5\n照會項目\nBA02[基本日常照顧] ×4\nBA16-1[代購] ×10\n備註：\nBA07*18 每週四次');assert.equal(r.fields.subject,'BA07[協助沐浴及洗頭] ×18；BA13[陪同外出] ×5；BA02[基本日常照顧] ×4；BA16-1[代購] ×10');assert.ok(!r.fields.subject.includes('每週'));assert.equal(r.fields.receivedDate,'2026-10-15')});
test('uncertain Latin codes are not silently corrected',()=>{const r=P.parse('照會單\n項目\n8A07[協助沐浴]\nBAO2[基本照顧]\n備註：請核對');assert.equal(r.fields.subject,undefined)});
