const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const ui=fs.readFileSync('js/document-ocr-ui.js','utf8');
const cloud=fs.readFileSync('js/director-cloud.js','utf8');
const css=fs.readFileSync('document-ocr.css','utf8');

test('photo inbox exposes per-image category, status, filtering and original-text review',()=>{
 for(const text of ['照片辨識與文件歸檔','辨識收件匣','data-ocr-filters','data-ocr-count','data-ocr-original','data-ocr-text','data-ocr-type','classificationStatus','archiveCategory'])assert.ok(ui.includes(text),text);
});

test('dropped files pass through the existing private original-photo upload before OCR',()=>{
 assert.ok(ui.includes('if(onFiles)onFiles(files);else session.addFiles(files)'));
 assert.ok(cloud.includes("onFiles:files=>upload(files,'source')"));
 assert.ok(cloud.includes("documentReview?.addFiles(files)"));
 assert.ok(cloud.includes("uploadOne(file,'source',identity)"));
});

test('batch inbox shows a distinct drop target and stacks review controls on narrow phones',()=>{
 assert.ok(css.includes('.ocr-inbox.is-drop-target'));
 assert.ok(css.includes('@media(max-width:640px)'));
 assert.ok(css.includes('.ocr-page-row select{grid-column:2'));
});
