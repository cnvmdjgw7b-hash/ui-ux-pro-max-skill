const test=require('node:test'),assert=require('node:assert/strict');const {reports,csv}=require('../js/report-export.js');
test('照會／異動各用附件欄序，不混日期、姓名與後續欄位',()=>{
 const rows=[{id:'a',recordType:'照會',receivedDate:'2026-10-01',responseDate:'2026-10-02',caseNumber:'00123',personName:'測試甲',subject:'照會內容',reportFixCompleted:'已補正',reportFollowup:'不應混入修正完成'},{id:'b',recordType:'異動',receivedDate:'2026-10-03',personName:'測試乙',noticeType:'異動種類',subject:'異動主旨',sourceOrReporter:'測試人',reportFollowup:'後續內容',reportSupplementary:'補充內容'}];const original=JSON.stringify(rows),r=reports(rows);
 assert.equal(r.length,2);assert.deepEqual(r[0].matrix[1],['項次','案號','個案姓名','督導','照會日期','回覆日期','回覆情形','現況','照會項目','繳交日','處理情形','行政校閱','主管校閱','行政備註','修正完成','補充']);
 assert.deepEqual(r[1].matrix[1],['項次','通報日期','通報類型','通報主旨','個案姓名2','通報人','繳交日','處理情形','行政校閱','主管校閱','行政備註','後續追蹤','補充','','','']);
 assert.equal(r[0].matrix[2][1],'00123');assert.equal(r[0].matrix[2][4],'1151001');assert.equal(r[0].matrix[2][5],'1151002');assert.equal(r[0].matrix[2][14],'已補正');assert.equal(r[1].matrix[2][3],'異動主旨');assert.equal(r[1].matrix[2][11],'後續內容');assert.equal(JSON.stringify(rows),original);
});
test('跨月份分表、選定報表月份不改原日期、缺值留空且不丟案件',()=>{
 const rows=[{recordType:'照會',receivedDate:'2026-09-23'},{recordType:'照會',receivedDate:'2026-10-01'},{recordType:'異動'}];assert.equal(reports(rows).reduce((sum,r)=>sum+r.count,0),3);const r=reports(rows,{month:'2026-10'});assert.equal(r.length,2);assert.equal(r[0].title,'115年10月照會統計明細');assert.equal(r[0].matrix[2][4],'1150923');assert.equal(r[1].matrix[2][1],'');assert.throws(()=>reports([{recordType:'不明'}]),/類型尚未確認/);
});
test('CSV保留多行、逗號與引號，提供BOM並阻擋公式執行',()=>{const s=csv([['a,b','x"y','一\n二','=HYPERLINK("bad")']]);assert(s.startsWith('\uFEFF'));assert(s.includes('"a,b"'));assert(s.includes('"x""y"'));assert(s.includes('"一\n二"'));assert(s.includes('"\'=HYPERLINK'));assert(s.endsWith('\r\n'))});
