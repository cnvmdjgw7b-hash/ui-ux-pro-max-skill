from __future__ import annotations

import base64
import json
import mimetypes
import shutil
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / "dist"

if DIST.exists():
    shutil.rmtree(DIST)
(DIST / "server").mkdir(parents=True)
(DIST / ".openai").mkdir()
shutil.copy2(ROOT / ".openai/hosting.json", DIST / ".openai/hosting.json")

assets: dict[str, list[str]] = {}
for extra in ("planner-home.html", "full-home-shell.css", "dashboard-home.html", "dashboard-home.css", "shared-site-shell.css", "work-calendar.css", "case-directory.css", "care-plan-renbao-workbench.html", "visit-17-workbench.html"):
    file = ROOT / extra
    assets["/" + extra] = [mimetypes.guess_type(extra)[0] or "application/octet-stream", base64.b64encode(file.read_bytes()).decode("ascii")]

for name in ("index.html", "line-v33", "ocr-engine", "document-ocr.css", "form-readability.css", "theme-contrast.css", "yhn-ocr-sw.js", "style.css", "workstation-shell.css", "homepage-v142.css", "director-cloud.css", "step1-layout.css", "home-referral-ux.css", "staff-import.css", "director.webmanifest", "logo.png", "login-fighter-sprite.png", "workstation-pet.png", "serviceData.js", "js", "law", "templates", "quota", "icons"):

    path = ROOT / name
    files = path.rglob("*") if path.is_dir() else [path]
    for file in files:
        if not file.is_file() or file.name.startswith("."):
            continue
        mime = mimetypes.guess_type(file.name)[0] or "application/octet-stream"
        encoded = base64.b64encode(file.read_bytes()).decode("ascii")
        assets["/" + file.relative_to(ROOT).as_posix()] = [mime, encoded]

worker = r'''import {notionConfigured, notionRead, notionWrite, fileTicket, fileUrl, privateFile} from './document-store.mjs';
import { handleMcp } from './workstation-mcp.mjs';
const assets = __ASSETS__;
const CREDENTIAL_KEY = "auth/password-v1.json";
const WELCOME_KEY = "auth/first-login.json";
const PASSWORD_ITERATIONS = 100000;

const securityHeaders = {
  "Cache-Control": "private, no-store",
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "no-referrer",
  "Content-Security-Policy": "default-src 'self'; script-src 'self' 'unsafe-inline' 'wasm-unsafe-eval' https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: https:; font-src 'self' data: blob:; media-src 'self' blob:; connect-src 'self' https://*.amazonaws.com; frame-src 'self' https://yinyi114work-ai.github.io https://yhn-ai-forms.floot.app; frame-ancestors 'self' https://chatgpt.com; object-src 'none'; base-uri 'self'; form-action 'self'"
};

const encoder = new TextEncoder();
function json(data, status = 200, extraHeaders = {}) {
  const headers = new Headers(securityHeaders);
  headers.set("Content-Type", "application/json; charset=utf-8");
  for (const [name, value] of Object.entries(extraHeaders)) headers.set(name, value);
  return new Response(JSON.stringify(data), { status, headers });
}
function base64Url(bytes) {
  const data = bytes instanceof ArrayBuffer ? new Uint8Array(bytes) : bytes;
  let binary = "";
  for (const byte of data) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}
function fromBase64Url(value) {
  const base64 = value.replace(/-/g, "+").replace(/_/g, "/");
  const binary = atob(base64 + "=".repeat((4 - base64.length % 4) % 4));
  return Uint8Array.from(binary, char => char.charCodeAt(0));
}
async function derivePassword(password, salt, iterations = PASSWORD_ITERATIONS) {
  const material = await crypto.subtle.importKey("raw", encoder.encode(password), "PBKDF2", false, ["deriveBits"]);
  return new Uint8Array(await crypto.subtle.deriveBits({ name: "PBKDF2", salt, iterations, hash: "SHA-256" }, material, 256));
}
async function loadCredential(bucket) {
  const object = await bucket.get(CREDENTIAL_KEY);
  return object ? JSON.parse(await object.text()) : null;
}
function getCookie(request, name) {
  const header = request.headers.get("Cookie") || "";
  for (const part of header.split(";")) {
    const [key, ...value] = part.trim().split("=");
    if (key === name) return value.join("=");
  }
  return "";
}
async function sessionCookie(request, credential) {
  const token = getCookie(request, "__Host-yhn_session");
  const parts = token.split(".");
  if (parts.length !== 3 || !/^\d+$/.test(parts[0]) || Number(parts[0]) <= Date.now()) return false;
  try {
    const key = await crypto.subtle.importKey("raw", fromBase64Url(credential.verifier), { name: "HMAC", hash: "SHA-256" }, false, ["verify"]);
    return await crypto.subtle.verify("HMAC", key, fromBase64Url(parts[2]), encoder.encode(parts[0] + "." + parts[1]));
  } catch (_) { return false; }
}
async function makeSessionCookie(credential, remember) {
  const seconds = remember ? 2592000 : 43200;
  const expires = String(Date.now() + seconds * 1000);
  const nonce = base64Url(crypto.getRandomValues(new Uint8Array(18)));
  const key = await crypto.subtle.importKey("raw", fromBase64Url(credential.verifier), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const signature = base64Url(await crypto.subtle.sign("HMAC", key, encoder.encode(expires + "." + nonce)));
  const maxAge = remember ? `; Max-Age=${seconds}` : "";
  return `__Host-yhn_session=${expires}.${nonce}.${signature}; Path=/; Secure; HttpOnly; SameSite=Strict${maxAge}`;
}
async function markFirstLogin(bucket) {
  const stored = await bucket.put(WELCOME_KEY, JSON.stringify({ usedAt: new Date().toISOString() }), { onlyIf: { etagDoesNotMatch: "*" } });
  return !!stored;
}
async function platformSessionKey(request) {
  const id=request.headers.get("oai-authenticated-user-id");
  return id ? "auth/site-sessions/"+base64Url(await crypto.subtle.digest("SHA-256",encoder.encode(id)))+".json" : null;
}
async function rememberPlatformSession(request,bucket,expires) {
  const key=await platformSessionKey(request);
  if(key) await bucket.put(key,JSON.stringify({expires}));
}
async function verifiedWorkstationSession(request,bucket,credential) {
  if(await sessionCookie(request,credential)) {
    const expires=Number(getCookie(request,"__Host-yhn_session").split(".")[0]);
    await rememberPlatformSession(request,bucket,expires);
    return true;
  }
  const key=await platformSessionKey(request);
  if(!key)return false;
  const stored=await bucket.get(key);
  return !!stored && Number(JSON.parse(await stored.text()).expires)>Date.now();
}
async function authApi(request, env, path) {
  const bucket = env && env.BUCKET;
  if (!bucket) return json({ message: "密碼後端儲存尚未連線，請聯絡工作台管理者。" }, 503);
  if (path === "/api/auth/status" && ["GET", "HEAD"].includes(request.method)) {
    const credential = await loadCredential(bucket);
    return json({ configured: !!credential, authenticated: credential ? await verifiedWorkstationSession(request,bucket,credential) : false });
  }
  if (path === "/api/auth/logout" && request.method === "POST") {
    const siteKey=await platformSessionKey(request);
    if(siteKey) await bucket.delete(siteKey);
    return json({ ok: true }, 200, { "Set-Cookie": "__Host-yhn_session=; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age=0" });
  }
  if (path !== "/api/auth/setup" && path !== "/api/auth/login") return json({ message: "找不到密碼服務。" }, 404);
  if (request.method !== "POST") return json({ message: "不支援此操作。" }, 405, { Allow: "POST" });
  const origin = request.headers.get("Origin");
  if (origin && origin !== new URL(request.url).origin) return json({ message: "請從工作台頁面操作。" }, 403);
  let body;
  try { body = await request.json(); } catch (_) { return json({ message: "資料格式有誤，請重新操作。" }, 400); }
  const password = typeof body.password === "string" ? body.password : "";
  const passwordLength = Array.from(password).length;
  if (passwordLength < 8 || passwordLength > 128) return json({ message: "密碼需為 8 至 128 個字元。" }, 400);

  let credential = await loadCredential(bucket);
  if (path === "/api/auth/setup") {
    if (credential) return json({ message: "工作台密碼已設定，請輸入現有密碼登入。" }, 409);
    const salt = crypto.getRandomValues(new Uint8Array(16));
    const verifier = await derivePassword(password, salt);
    credential = { version: 1, algorithm: "PBKDF2-SHA-256", iterations: PASSWORD_ITERATIONS, salt: base64Url(salt), verifier: base64Url(verifier), createdAt: new Date().toISOString() };
    const created = await bucket.put(CREDENTIAL_KEY, JSON.stringify(credential), { onlyIf: { etagDoesNotMatch: "*" } });
    if (!created) return json({ message: "密碼剛由另一位使用者完成設定，請輸入該密碼登入。" }, 409);
  } else {
    if (!credential) return json({ message: "尚未設定工作台密碼，請重新整理並註冊設定。" }, 409);
    const candidate = await derivePassword(password, fromBase64Url(credential.salt), credential.iterations);
    const expected = fromBase64Url(credential.verifier);
    let difference = candidate.length ^ expected.length;
    for (let i = 0; i < Math.max(candidate.length, expected.length); i++) difference |= (candidate[i] || 0) ^ (expected[i] || 0);
    if (difference !== 0) return json({ message: "密碼不正確，請再試一次。" }, 401);
  }
  const cookie = await makeSessionCookie(credential, body.remember === true);
  await rememberPlatformSession(request,bucket,Number(cookie.split(";")[0].split("=")[1].split(".")[0]));
  const welcome = await markFirstLogin(bucket);
  return json({ ok: true, welcome }, 200, { "Set-Cookie": cookie });
}

async function authorizeDocumentFile(request,env){
  const siteUser=request.headers.get('oai-authenticated-user-id');
  if(!siteUser) return json({error:'請登入工作站'},401);
  const credential=await loadCredential(env.BUCKET);
  if(!credential||!await verifiedWorkstationSession(request,env.BUCKET,credential))return json({error:'請完成工作站登入'},401);
  const bound=await env.BUCKET.get('auth/director-site-owner-v1.json');
  if(!bound||JSON.parse(await bound.text()).siteUser!==siteUser)return json({error:'附件未授權'},403);
  if(request.method==='PUT'&&request.headers.get('Origin')!==new URL(request.url).origin)return json({error:'請從本站上傳'},403);
  return privateFile(env,siteUser,request);
}
async function workspaceKey(user){
  return "workstation/"+base64Url(await crypto.subtle.digest("SHA-256",encoder.encode(user)))+"/data-v1.json";
}
async function loadWorkspace(bucket,user){
  const key=await workspaceKey(user),object=await bucket.get(key);
  if(!object)return {key,etag:null,data:{cases:[],caregivers:[],records:[],kpis:[]}};
  const parsed=JSON.parse(await object.text());
  return {key,etag:object.etag,data:{cases:Array.isArray(parsed.cases)?parsed.cases:[],caregivers:Array.isArray(parsed.caregivers)?parsed.caregivers:[],records:Array.isArray(parsed.records)?parsed.records:[],kpis:Array.isArray(parsed.kpis)?parsed.kpis:[]}};
}
async function homeDataKey(user){
  return "workstation/"+base64Url(await crypto.subtle.digest("SHA-256",encoder.encode(user)))+"/home-data-v1.json";
}
function homeDataPrefix(key){return key.slice(0,-'home-data-v1.json'.length)+'home-history/'}
async function loadHomeData(bucket,user){
  const key=await homeDataKey(user),object=await bucket.get(key);
  if(!object)return {key,etag:null,data:null};
  return {key,etag:object.etag,data:JSON.parse(await object.text())};
}
async function saveHomeSnapshot(bucket,key,data){
  const prefix=homeDataPrefix(key),name=prefix+new Date().toISOString().replace(/[:.]/g,'-')+'-'+crypto.randomUUID()+'.json';
  await bucket.put(name,JSON.stringify({savedAt:new Date().toISOString(),data}));
  const listed=await bucket.list({prefix,limit:1000});
  const old=listed.objects.slice().sort((a,b)=>new Date(a.uploaded)-new Date(b.uploaded)).slice(0,Math.max(0,listed.objects.length-20));
  for(const item of old)await bucket.delete(item.key);
}
async function saveWorkspace(bucket,state){
  const condition=state.etag?{etagMatches:state.etag}:{etagDoesNotMatch:"*"};
  const saved=await bucket.put(state.key,JSON.stringify(state.data),{onlyIf:condition});
  if(!saved)throw Object.assign(new Error("資料剛由另一個頁面更新，請重新讀取後再儲存。"),{status:409});
}
function workspaceCollection(entity){return {case:"cases",caregiver:"caregivers",record:"records",kpi:"kpis"}[entity]}
const HOME_DATA_KEYS=new Set(['yhn_director_workstation_v1','yhn_supervisor_daily_plans_v1','yhn_supervisor_habits_v1','yhn_workstation_case_roster_v1','yhn_workstation_selected_case_v1','yhn_workstation_visit_activity_v1','yhn_workstation_visit_records_v1','yhn_care_plan_generator_v1','yhn_care_plan_draft_v1']);
async function directorApi(request, env) {
  // Sites request identity is scoped to this Site; it is NOT the account access-policy ID.
  const siteUser = request.headers.get("oai-authenticated-user-id");
  if (!siteUser) return json({ error: "網站登入狀態尚未傳入，請重新整理工作站。" }, 401);
  const credential = await loadCredential(env.BUCKET);
  if (!credential || !await verifiedWorkstationSession(request,env.BUCKET,credential)) return json({ error: "工作站登入狀態未完成，請從左下角登入設定驗證一次。" }, 401);
  if (request.method !== "POST") return json({ error: "不支援此操作。" }, 405);
  if (request.headers.get("Origin") !== new URL(request.url).origin) return json({ error: "請從本站操作。" }, 403);
  if (!String(request.headers.get("Content-Type")||"").startsWith("application/json")) return json({ error: "資料格式不符。" }, 415);
  const body = await request.text();
  if (body.length > 800000) return json({ error: "資料量過大。" }, 413);
  let input; try { input=JSON.parse(body); } catch { return json({error:"資料格式不符。"},400); }
  if (!["read","write","remove","upload","url","status","workstation-sync-read","workstation-sync-write","workstation-sync-history","workstation-sync-restore"].includes(input.action)) return json({error:"未知操作。"},400);

  // The selected Site is confirmed owner-private. Bind its first authenticated,
  // password-verified visitor atomically. A later audience change cannot expose this data.
  const ownerKey="auth/director-site-owner-v1.json";
  let bound=await env.BUCKET.get(ownerKey);
  if (!bound) {
    await env.BUCKET.put(ownerKey,JSON.stringify({siteUser,createdAt:new Date().toISOString()}),{onlyIf:{etagDoesNotMatch:"*"}});
    bound=await env.BUCKET.get(ownerKey);
  }
  if (!bound || JSON.parse(await bound.text()).siteUser!==siteUser) return json({error:"此帳號尚未授權使用主任雲端資料。"},403);
  if(input.action==='status')return json({provider:'sites',flootConnected:false,notionConfigured:notionConfigured(env)});
  if(input.action==='workstation-sync-read'){
    const state=await loadHomeData(env.BUCKET,siteUser);
    return json({data:state.data,etag:state.etag,provider:'sites-r2'});
  }
  if(input.action==='workstation-sync-history'){
    const state=await loadHomeData(env.BUCKET,siteUser),listed=await env.BUCKET.list({prefix:homeDataPrefix(state.key),limit:100});
    const snapshots=listed.objects.slice().sort((a,b)=>new Date(b.uploaded)-new Date(a.uploaded)).slice(0,20).map(x=>({id:x.key,savedAt:x.uploaded?.toISOString?.()||String(x.uploaded||'')}));
    return json({snapshots,etag:state.etag});
  }
  if(input.action==='workstation-sync-write'){
    const state=await loadHomeData(env.BUCKET,siteUser),data=input.payload?.data,expected=input.payload?.expectedEtag??null;
    if(!data||typeof data!=='object'||Array.isArray(data)||Object.keys(data).some(k=>!HOME_DATA_KEYS.has(k))||Object.values(data).some(v=>v!==null&&typeof v!=='string'))return json({error:'同步資料欄位不符。'},400);
    if(JSON.stringify(data).length>700000)return json({error:'同步資料超過安全容量，原資料仍保留。'},413);
    if(state.etag!==expected)return json({error:'雲端資料剛由另一台裝置更新，請重新同步。',etag:state.etag},409);
    if(state.data)await saveHomeSnapshot(env.BUCKET,state.key,state.data);
    const condition=state.etag?{etagMatches:state.etag}:{etagDoesNotMatch:'*'},saved=await env.BUCKET.put(state.key,JSON.stringify(data),{onlyIf:condition});
    if(!saved)return json({error:'同步時另一台裝置剛完成更新，請重新同步。'},409);
    return json({ok:true,data,etag:saved.etag,updatedAt:new Date().toISOString()});
  }
  if(input.action==='workstation-sync-restore'){
    const state=await loadHomeData(env.BUCKET,siteUser),id=String(input.payload?.snapshotId||''),prefix=homeDataPrefix(state.key);
    if(!id.startsWith(prefix)||id.includes('..'))return json({error:'備份識別無效。'},400);
    if(state.etag!==(input.payload?.expectedEtag??null))return json({error:'雲端資料剛由另一台裝置更新，請重新整理備份清單。'},409);
    const object=await env.BUCKET.get(id);if(!object)return json({error:'找不到這份雲端備份。'},404);
    const snapshot=JSON.parse(await object.text()),data=snapshot?.data;
    if(!data||typeof data!=='object'||Array.isArray(data)||Object.keys(data).some(k=>!HOME_DATA_KEYS.has(k))||Object.values(data).some(v=>v!==null&&typeof v!=='string')||JSON.stringify(data).length>700000)return json({error:'備份格式不符，未還原。'},409);
    if(state.data)await saveHomeSnapshot(env.BUCKET,state.key,state.data);
    const condition=state.etag?{etagMatches:state.etag}:{etagDoesNotMatch:'*'},saved=await env.BUCKET.put(state.key,JSON.stringify(data),{onlyIf:condition});
    if(!saved)return json({error:'還原時資料剛由另一台裝置更新，請重新載入。'},409);
    return json({ok:true,data,etag:saved.etag});
  }
  if(input.action==='url') {const url=await fileUrl(siteUser,input.payload?.storageKey);if(url)return json({url});}
  if(input.action==='upload')return json(await fileTicket(env,siteUser,input.payload));
  if(input.action==='read'){
    const state=await loadWorkspace(env.BUCKET,siteUser),out={...state.data,provider:'sites',flootConnected:false,notionConfigured:notionConfigured(env)};
    if(notionConfigured(env)){try{out.records=[...out.records,...await notionRead(env,siteUser)]}catch(e){out.notionError=e.message;}}
    return json(out);
  }
  if(input.action==='write'&&input.payload?.entity==='record'){
    const p=input.payload;
    if(String(p.id||'').startsWith('notion:')||(!p.id&&p.data?.ocrDocuments?.length&&notionConfigured(env)))return json(await notionWrite(env,siteUser,p));
  }
  if(input.action==='remove'&&String(input.payload?.id||'').startsWith('notion:'))return json({error:'本次未開放刪除Notion案件，請保留原資料。'},409);
  const collection=workspaceCollection(input.payload?.entity);
  if(!collection)return json({error:'不支援的資料類型。'},400);
  const state=await loadWorkspace(env.BUCKET,siteUser),rows=state.data[collection],id=String(input.payload?.id||crypto.randomUUID());
  if(input.action==='write'){
    const index=rows.findIndex(row=>String(row.id)===id),record={...(index>=0?rows[index]:{}),...(input.payload?.data||{}),id,updatedAt:new Date().toISOString()};
    if(index>=0)rows[index]=record;else rows.push(record);
    await saveWorkspace(env.BUCKET,state);
    return json({id,record,notionSync:'sites'});
  }
  if(input.action==='remove'){
    const index=rows.findIndex(row=>String(row.id)===id);
    if(index<0)return json({error:'找不到這筆資料，請重新讀取。'},404);
    rows.splice(index,1);await saveWorkspace(env.BUCKET,state);return json({ok:true,id});
  }
  return json({error:'未知操作。'},400);
}
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === "/mcp") return handleMcp(request);
    if(url.pathname==='/api/document-file'){try{return await authorizeDocumentFile(request,env)}catch(e){return json({error:e.message},e.status||503)}}
    if (url.pathname === "/api/director-health" && request.method==="GET") return json({ok:true,provider:"sites",flootConnected:false});
    if (url.pathname === "/api/director") {
      try { return await directorApi(request,env); } catch(error) { return json({error:error?.message||"本站操作暫時失敗，編輯內容已保留。"},error?.status||503); }
    }
    if (url.pathname.startsWith("/api/auth/")) {
      try { return await authApi(request, env, url.pathname); }
      catch (error) {
        console.error("Password service error", error && error.name ? error.name : "UnknownError");
        return json({ message: "密碼服務暫時無法完成，請稍後再試。" }, 503);
      }
    }
    if (!["GET", "HEAD"].includes(request.method)) return new Response("Method not allowed", { status: 405, headers: { ...securityHeaders, Allow: "GET, HEAD" } });
    let path = decodeURIComponent(url.pathname);
    if (path === "/") path = "/index.html";
    if (path === "/law/") path = "/law/index.html";

    const asset = assets[path];
    if (!asset) return new Response("Not found", { status: 404, headers: securityHeaders });

    const headers = new Headers(securityHeaders);
    headers.set("Content-Type", asset[0]);
    const body = request.method === "HEAD"
      ? null
      : Uint8Array.from(atob(asset[1]), char => char.charCodeAt(0));
    return new Response(body, { headers });
  }
};
'''.replace("__ASSETS__", json.dumps(assets, separators=(",", ":")))

(DIST / "server/index.js").write_text(worker, encoding="utf-8")
print(f"Prepared private static Worker with {len(assets)} local assets.")

shutil.copy2(ROOT / "server/document-store.mjs", DIST / "server/document-store.mjs")

shutil.copy2(ROOT / "server/workstation-mcp.mjs", DIST / "server/workstation-mcp.mjs")
