const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const R=require('../js/care-plan-renbao.js'),P=require('../js/document-ocr-core.js');
test('Renbao headings, cells, two supervisor signatures and five evaluation columns match source',()=>{
 assert.deepEqual(R.sections.slice(1,7).map(x=>x.title),['一、照護計畫版本','二、個案身心及家庭評估簡述','三、居家服務提供及執行情形','四、需求評估或服務計畫修正','五、照護項目及照顧服務計畫','六、照顧服務計畫執行及評值表']);
 assert.deepEqual(R.evaluationColumns,['照護項目','照顧目標','照護服務執行計劃','評值','原表右側空白欄']);assert.deepEqual(R.sections.at(-1).fields.map(x=>[x[1],x[3]]),[['督導','A34'],['督導','C34'],['主管','E34']]);
 const required=['※性別','※開案日期','生效日期','評估日期','下次評估日期','初評','複評','變更原因簡述','失能原因及現況','需求評估或服務計畫修正'];const labels=R.sections.flatMap(s=>(s.fields||[]).map(x=>x[1]));required.forEach(l=>assert.ok(labels.includes(l),l));
});
test('exact care-plan spelling and section boundaries fill actual new controls without merging paragraphs',()=>{
 const r=P.parse('居家服務個案照護計劃\n個案姓名：測試甲\n一、照護計畫版本\n生效日期：115/10/12\n評估日期：115/10/13\n下次評估日期：116/04/11\n■ 複評\n變更原因簡述：維持原文\n二、個案身心及家庭評估簡述\n疾病史：測試疾病\n三、居家服務提供及執行情形\n原文執行情形\n四、需求評估或服務計畫修正\n計畫異動日期：115.10.12\n五、照護項目及照顧服務計畫\n1. 居服員：測試乙\n2. 服務頻率及估計時間：每周一至周六\n1. 居服員2：測試丙\n2. 服務頻率及估計時間：每周日\n督導：測試丁\n督導：測試戊\n主管：測試己');
 assert.equal(r.type,'照護計畫');assert.equal(r.fields.cpName,'測試甲');assert.equal(r.fields.rbPlanAssessmentDate,'2026-10-13');assert.equal(r.fields.rbPlanChangeReason,'維持原文');assert.equal(r.fields.rbPlanExecution,'原文執行情形');assert.equal(r.fields.rbPlanReassessment,true);assert.equal(r.fields.rbPlanCaregiver2,'測試丙');assert.equal(r.fields.rbPlanFrequency2,'每周日');assert.equal(r.fields.rbPlanSupervisor1,'測試丁');assert.equal(r.fields.rbPlanSupervisor2,'測試戊');assert.equal(r.fields.cpDate,undefined);
});
test('preview retains all entered service rows, units and long evaluation text; no invented defaults',()=>{
 const long='保留原始完整評值文字'.repeat(100),p=R.preview({fields:{cpName:'TEST',rbPlanChangeReason:'原文\n逐行保留'},caregivers:[{name:'TEST居服員',frequency:'週一',rows:[['BA05-1__10711 餐食照顧','13','GA09 居家喘息服務','42'],['BA13 陪同外出','51','','']]}],evaluations:[['問題','目標','執行',long,'2026-10-19']]});assert.ok(p.includes(long));assert.ok(p.includes('BA13 陪同外出\t51'));assert.ok(p.includes('原文\n逐行保留'));assert.ok(!p.includes('暫無或待補充'));assert.ok(!p.includes('依個案主要照顧問題'));
});
test('new plan uses existing draft store, preserves legacy and does not schedule reminders',()=>{
 const s=fs.readFileSync(path.join(__dirname,'../js/care-plan-renbao.js'),'utf8');assert.ok(s.includes("const KEY='yhn_care_plan_generator_v1'"));assert.ok(s.includes('...previous'));assert.ok(s.includes('old.append(legacy)'));assert.ok(!/recordPlanSaved|schedulePlanReview|fetch\(/.test(s));const html=fs.readFileSync(path.join(__dirname,'../index.html'),'utf8');assert.equal((html.match(/id="cpName"/g)||[]).length,1);
});
