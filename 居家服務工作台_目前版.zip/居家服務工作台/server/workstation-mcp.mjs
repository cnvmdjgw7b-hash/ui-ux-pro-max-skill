const origin = 'https://yhn-ltcnotes-skin-test.wennnm.chatgpt.site';
const workflows = Object.freeze({
  home_visit: ['家訪紀錄', 'visitTool'],
  phone_visit: ['電訪紀錄', 'phoneAssistTool'],
  service_change: ['異動通報', 'mutationTool'],
  care_plan: ['照顧計畫', 'yhnCarePlanTool'],
});
const tool = {
  name: 'open_workstation_workflow',
  description: '取得永護寧既有測試工作台的功能連結，可直達家訪、電訪、異動通報或照顧計畫。省略 workflow 時列出全部入口。此工具只回傳連結。',
  inputSchema: {
    type: 'object',
    properties: { workflow: { type: 'string', enum: Object.keys(workflows) } },
    additionalProperties: false,
  },
  annotations: { readOnlyHint: true, openWorldHint: false },
};

export async function handleMcp(request) {
  const headers = { 'Cache-Control': 'private, no-store' };
  if (request.method !== 'POST') {
    return new Response(null, { status: 405, headers: { ...headers, Allow: 'POST' } });
  }

  const reply = (id, result) => Response.json({ jsonrpc: '2.0', id, ...result }, { headers });
  const error = (id, code, message) => reply(id, { error: { code, message } });
  let message;
  try {
    message = await request.json();
  } catch {
    return error(null, -32700, 'Parse error');
  }
  if (message?.jsonrpc !== '2.0' || typeof message.method !== 'string') {
    return error(null, -32600, 'Invalid Request');
  }

  const { id, method, params } = message;
  if (id === undefined) return new Response(null, { status: 202, headers });
  if (method === 'server/discover') {
    return reply(id, { result: { supportedVersions: ['2026-07-28'], capabilities: { tools: {} } } });
  }
  if (method === 'tools/list') return reply(id, { result: { tools: [tool] } });
  if (method !== 'tools/call') return error(id, -32601, 'Method not found');
  if (params?.name !== tool.name) return error(id, -32602, 'Unknown tool');

  const args = params.arguments ?? {};
  const workflow = args.workflow;
  if (typeof args !== 'object' || Array.isArray(args)
      || Object.keys(args).some(key => key !== 'workflow')
      || (workflow !== undefined && (typeof workflow !== 'string' || !Object.hasOwn(workflows, workflow)))) {
    return reply(id, { result: { isError: true, content: [{ type: 'text', text: '請選擇工作台支援的功能。' }] } });
  }

  const entries = workflow === undefined ? Object.values(workflows) : [workflows[workflow]];
  const links = entries.map(([label, section]) => `[${label}](${origin}/#${section})`);
  return reply(id, { result: { content: [{ type: 'text', text: links.join('\n') }] } });
}
