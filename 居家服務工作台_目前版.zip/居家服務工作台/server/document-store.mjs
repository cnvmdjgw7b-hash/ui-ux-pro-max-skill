// Server-only integration. No credentials or patient snapshots are bundled here.
const SOURCES={照會:'cf35b0e4-0a3c-469f-b6ee-36ce4746f4a7',異動:'8076e7e1-6ad8-4f09-a5f9-36e5684de0ed'};
export const EXTRA_FIELDS=['serviceTarget','reportProcessing','reportAdminNote','reportFixCompleted','reportFollowup','reportSupplementary'];
const META='YHN_WORKSTATION_RECORD_V1';
const keys=['recordType','caseNumber','personName','supervisor','sourceOrReporter','serviceTarget','noticeType','receivedDate','responseDate','responseStatus','currentStatus','subject','details','reportProcessing','reportAdminNote','reportFixCompleted','reportFollowup','reportSupplementary','renbaoStatus','carePlanStatus','scheduleStatus','contractStatus','contractDueDate','contractReminderNote','serviceConnectionStatus','managerReview','adminReview','submittedDate','supervisorCompletedDate','recheckStatus','completionNote','followupAction','followupStatus','finalStatus','sourceImageStorageKey','sourceImageStorageKeys','evidenceStorageKey','ocrDocuments','clientRequestId','syncVersion'];
const maps={照會:{personName:'個案姓名',caseNumber:'案號',supervisor:'督導',receivedDate:'照會日期',responseDate:'回覆日期',responseStatus:'回覆情形',currentStatus:'現況',subject:'照會項目',reportProcessing:'處理情形',reportAdminNote:'行政備註',reportFixCompleted:'修正完成',reportSupplementary:'補充',submittedDate:'繳交日'},異動:{personName:'個案姓名',receivedDate:'通報日期',noticeType:'通報類型',subject:'通報主旨',sourceOrReporter:'通報人',serviceTarget:'通報目標',reportProcessing:'處理情形',reportAdminNote:'行政備註',reportFollowup:'後續追蹤',reportSupplementary:'補充',submittedDate:'繳交日'}};
const error=(message,status=400)=>Object.assign(Error(message),{status});
const enc=new TextEncoder();
async function scope(user){return [...new Uint8Array(await crypto.subtle.digest('SHA-256',enc.encode(user)))].map(x=>x.toString(16).padStart(2,'0')).join('')}
async function prefix(user){return 'document-integration/'+await scope(user)+'/'}
async function read(bucket,key){const o=await bucket.get(key);return o?{data:JSON.parse(await o.text()),etag:o.etag}:null}
// Honor an existing Notion-named secret only if it has a Notion-token prefix.
// An opaque storage/encryption key must never be sent as an API credential.
function runtimeToken(env){return env.YHN_NOTION_TOKEN||(/^(ntn_|secret_)/.test(env.NOTION_STORAGE_KEY||'')?env.NOTION_STORAGE_KEY:null)}
export function notionConfigured(env){return !!runtimeToken(env)}
async function notion(env,path,method='GET',body){
 if(!notionConfigured(env))throw error('Notion執行階段授權尚未設定；沒有同步成功。原編輯內容仍保留。',503);
 const controller=new AbortController(),t=setTimeout(()=>controller.abort(),25000);let response;
 try{response=await fetch('https://api.notion.com/v1/'+path,{method,headers:{Authorization:'Bearer '+runtimeToken(env),'Notion-Version':'2026-03-11','Content-Type':'application/json'},...(body?{body:JSON.stringify(body)}:{}),signal:controller.signal});const out=await response.json();if(!response.ok)throw error(response.status===401||response.status===403?'Notion未授權此資料來源，請檢查連接權限。':response.status===429?'Notion流量限制，請稍後核對再儲存。':'Notion操作失敗：'+(out.message||response.status),response.status===429?429:502);return out}finally{clearTimeout(t)}
}
function clean(input){if(!input||typeof input!=='object'||Array.isArray(input))throw error('案件資料格式錯誤');const out={};for(const k of keys)if(Object.hasOwn(input,k))out[k]=input[k];if(!SOURCES[out.recordType]||typeof out.personName!=='string'||!out.personName.trim())throw error('請確認案件類型及個案姓名');for(const [k,v]of Object.entries(out))if(!['sourceImageStorageKeys','ocrDocuments'].includes(k)&&v!=null&&typeof v!=='string')throw error('欄位格式錯誤：'+k);if(out.sourceImageStorageKeys&&(!Array.isArray(out.sourceImageStorageKeys)||out.sourceImageStorageKeys.length>8||out.sourceImageStorageKeys.some(x=>typeof x!=='string')))throw error('照片最多8張且必須有有效參照');if(out.ocrDocuments&&(!Array.isArray(out.ocrDocuments)||out.ocrDocuments.length>8))throw error('辨識文件最多8頁');if(JSON.stringify(out).length>160000)throw error('文件原文過大，請分批保存');return out}
function rich(value){const text=String(value??'');return Array.from({length:Math.ceil(text.length/1800)},(_,i)=>({type:'text',text:{content:text.slice(i*1800,(i+1)*1800)}}))}
export function properties(record,schema){
 const out={},warnings=[];for(const [key,name]of Object.entries(maps[record.recordType])){if(!Object.hasOwn(record,key))continue;const def=schema.properties?.[name];if(!def)throw error('Notion缺少既有欄位：'+name,409);const value=record[key];
  if(def.type==='title')out[name]={title:rich(value)};
  else if(def.type==='rich_text')out[name]={rich_text:rich(value)};
  else if(def.type==='date'){if(value&&!/^\d{4}-\d{2}-\d{2}$/.test(value))throw error('日期格式不符：'+name);out[name]={date:value?{start:value}:null}}
  else if(def.type==='select'){if(!value){out[name]={select:null};continue}if(def.select.options.some(x=>x.name===value))out[name]={select:{name:value}};else warnings.push(name+'「'+value+'」未符合Notion選項；原值保留在同一案件原始欄位，不猜改狀態')}
  else throw error('Notion欄位型別已變更：'+name,409)
 }return {properties:out,warnings};
}
function block(record,id){return {object:'block',type:'code',code:{language:'json',caption:[{type:'text',text:{content:META+':'+id}}],rich_text:rich(JSON.stringify({marker:META,id,record}))}}}
function parseBlock(block){try{if(block.type!=='code'||!block.code.caption.some(x=>x.plain_text===META||x.plain_text?.startsWith(META+':')||x.text?.content?.startsWith(META+':')))return null;const o=JSON.parse(block.code.rich_text.map(x=>x.plain_text??x.text?.content??'').join(''));return o.marker===META?o:null}catch{return null}}
async function children(env,pageId){let start,all=[];do{const x=await notion(env,'blocks/'+pageId+'/children?page_size=100'+(start?'&start_cursor='+encodeURIComponent(start):''));all.push(...x.results);start=x.has_more?x.next_cursor:null;if(all.length>1000)throw error('案件內容過長，請人工核對',409)}while(start);return all}
async function loadRecord(env,pageId,user){const p=await notion(env,'pages/'+pageId),blocks=await children(env,pageId),b=blocks.find(x=>parseBlock(x)),meta=b&&parseBlock(b);if(!meta)throw error('Notion案件缺少工作站識別，未讀取其他個案頁',409);const binding=await read(env.BUCKET,await prefix(user)+'notion/'+meta.id+'.json');if(!binding||binding.data.pageId!==pageId)throw error('案件識別未授權',403);const r={...meta.record,id:'notion:'+pageId,syncVersion:p.last_edited_time,notionSync:'synced'};for(const [key,name]of Object.entries(maps[r.recordType]||{})){const prop=p.properties[name];if(!prop)continue;const value=prop.type==='title'||prop.type==='rich_text'?prop[prop.type].map(x=>x.plain_text??x.text?.content??'').join(''):prop.type==='date'?prop.date?.start||null:prop.type==='select'?prop.select?.name:null;
 // Unsupported select vocabularies are retained in metadata; don't erase them on read.
 if(prop.type!=='select'||value!=null)r[key]=value;
 }return {record:r,block:b,page:p,uuid:meta.id}}
export async function notionRead(env,user){const p=await prefix(user)+'notion/';let cursor,records=[];do{const list=await env.BUCKET.list({prefix:p,limit:100,cursor});for(const key of list.objects){const entry=await read(env.BUCKET,key.key);if(entry?.data.pageId)records.push((await loadRecord(env,entry.data.pageId,user)).record)}cursor=list.truncated?list.cursor:undefined;if(records.length>1000)throw error('同步案件過多，需分頁讀取，原資料未刪除',409)}while(cursor);return records}
export async function notionWrite(env,user,payload){
 const record=clean(payload.data);const root=await prefix(user),uuid=record.clientRequestId;if(!/^[0-9a-f-]{36}$/i.test(uuid||''))throw error('缺少有效儲存識別，請重新開啟案件');const indexKey=root+'notion/'+uuid+'.json';let existing=await read(env.BUCKET,indexKey),pageId=existing?.data.pageId;
 if(payload.id){if(!/^notion:[0-9a-f-]{36}$/i.test(payload.id))throw error('案件識別不符');pageId=payload.id.slice(7);if(existing?.data.pageId!==pageId)throw error('這筆案件不屬於目前使用者的同步索引',403)}
 // Conditional lock prevents duplicate creates/concurrent writes. Uncertain requests are NEVER replayed.
 const lockKey=root+'locks/'+uuid+'.json',locked=await env.BUCKET.put(lockKey,JSON.stringify({at:Date.now()}),{onlyIf:{etagDoesNotMatch:'*'}});if(!locked)throw error('此案件仍在儲存或上次結果待核對，請更新資料確認，勿重複新增。',409);
 let uncertain=false;
 try{
  let loaded;if(pageId){loaded=await loadRecord(env,pageId,user);if(loaded.uuid!==uuid)throw error('案件識別不一致',409);if(record.syncVersion&&record.syncVersion!==loaded.record.syncVersion)throw error('其他裝置已更新這筆案件，請重新讀取後再修改。',409)}
  const schema=await notion(env,'data_sources/'+SOURCES[record.recordType]),mapped=properties(record,schema),now=new Date().toISOString();record.createdAt=loaded?.record.createdAt||now;record.updatedAt=now;
  if(!pageId){
   uncertain=true;const created=await notion(env,'pages','POST',{parent:{type:'data_source_id',data_source_id:SOURCES[record.recordType]},properties:mapped.properties,children:[block(record,uuid)]});pageId=created.id;
   await env.BUCKET.put(indexKey,JSON.stringify({pageId,uuid}));uncertain=false;
  }else{
   uncertain=true;await notion(env,'blocks/'+pageId+'/children','PATCH',{children:[{object:'block',type:'code',code:{language:'json',caption:[{type:'text',text:{content:'YHN_RECORD_HISTORY:'+uuid}}],rich_text:rich(JSON.stringify({at:now,previous:loaded.record}))}}]});await notion(env,'pages/'+pageId,'PATCH',{properties:mapped.properties});await notion(env,'blocks/'+loaded.block.id,'PATCH',{code:block(record,uuid).code});uncertain=false;
  }
  const saved=(await loadRecord(env,pageId,user)).record;
  // Six fields and raw OCR must survive metadata and the selected native properties.
  for(const k of [...EXTRA_FIELDS,'ocrDocuments','subject','personName'])if(Object.hasOwn(record,k)&&JSON.stringify(record[k])!==JSON.stringify(saved[k]))throw error('Notion讀回不一致：'+k+'，請核對原案件。',409);
  return {id:saved.id,record:saved,warnings:mapped.warnings,notionSync:'synced'};
 }finally{if(!uncertain)await env.BUCKET.delete(lockKey)}
}
export async function extraRead(env,user,records){
 const p=await prefix(user)+'legacy/',available=new Set();let cursor;
 do{const page=await env.BUCKET.list({prefix:p,limit:1000,cursor});for(const item of page.objects)available.add(item.key);cursor=page.truncated?page.cursor:undefined}while(cursor);
 // Original Floot has over a thousand rows; never issue one R2 read per untouched row.
 const needed=records.filter(r=>available.has(p+encodeURIComponent(r.id)+'.json'));
 if(needed.length>200)throw error('補充資料需分頁載入，未刪除資料；請先完成分頁驗收。',503);
 const fields=new Map();for(let i=0;i<needed.length;i+=8)await Promise.all(needed.slice(i,i+8).map(async r=>{const o=await read(env.BUCKET,p+encodeURIComponent(r.id)+'.json');if(o)fields.set(String(r.id),o.data.fields)}));
 return records.map(r=>fields.has(String(r.id))?{...r,...fields.get(String(r.id)),notionSync:'legacy'}:r);
}
export async function extraWrite(env,user,id,record){if(!id)throw error('雲端未回傳案件ID，無法安全關聯補充欄位',409);const fields={};for(const key of [...EXTRA_FIELDS,'ocrDocuments','caseNumber','sourceImageStorageKeys','followupAction'])if(Object.hasOwn(record,key))fields[key]=record[key];if(!Object.keys(fields).length)return;const p=await prefix(user),key=p+'legacy/'+encodeURIComponent(id)+'.json',previous=await read(env.BUCKET,key);if(previous)await env.BUCKET.put(p+'legacy-history/'+encodeURIComponent(id)+'/'+crypto.randomUUID()+'.json',JSON.stringify(previous.data));await env.BUCKET.put(key,JSON.stringify({fields:{...previous?.data.fields,...fields},updatedAt:new Date().toISOString()}));}
export async function privateFile(env,user,request){
 const url=new URL(request.url),key=url.searchParams.get('key'),p=await prefix(user)+'photos/';if(!key?.startsWith(p)||key.includes('..'))throw error('附件未授權',403);
 if(request.method==='PUT'){const ticket=await read(env.BUCKET,key+'.ticket');if(!ticket)throw error('上傳授權失效',403);if(ticket.data.expires<Date.now())throw error('上傳已過期',403);if(request.headers.get('Content-Type')!==ticket.data.type)throw error('檔案型別不符',415);const bytes=await request.arrayBuffer();if(bytes.byteLength!==ticket.data.size||bytes.byteLength>10*1024*1024)throw error('檔案大小不符',413);await env.BUCKET.put(key,bytes,{httpMetadata:{contentType:ticket.data.type}});await env.BUCKET.delete(key+'.ticket');return new Response(null,{status:204})}
 if(request.method==='GET'){const data=await env.BUCKET.get(key);if(!data)throw error('找不到原始附件',404);return new Response(data.body,{headers:{'Content-Type':data.httpMetadata?.contentType||'application/octet-stream','Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff'}})}throw error('不支援操作',405);
}
export async function fileTicket(env,user,payload){if(!/^image\/(jpeg|png|webp|heic|heif|gif|bmp)$/i.test(payload.contentType)||!Number.isInteger(payload.sizeBytes)||payload.sizeBytes<1||payload.sizeBytes>10*1024*1024)throw error('請選擇10MB內的照片');const key=await prefix(user)+'photos/'+crypto.randomUUID();await env.BUCKET.put(key+'.ticket',JSON.stringify({expires:Date.now()+3600000,type:payload.contentType,size:payload.sizeBytes}));return {storageKey:key,uploadUrl:'/api/document-file?key='+encodeURIComponent(key),headers:{'Content-Type':payload.contentType}}}
export async function fileUrl(user,key){const p=await prefix(user)+'photos/';return typeof key==='string'&&key.startsWith(p)?'/api/document-file?key='+encodeURIComponent(key):null}
