const CACHE = 'yhn-offline-ocr-v2';
const OCR_PREFIX = '/line-v33/ocr/';
const OCR_FILES = new Set([
  '/ocr-engine/core/tesseract-core-lstm.wasm.js',
  '/ocr-engine/core/tesseract-core-simd-lstm.wasm.js',
  '/ocr-engine/core/tesseract-core-relaxedsimd-lstm.wasm.js',
  OCR_PREFIX + 'tesseract.min.js',
  OCR_PREFIX + 'worker.min.js',
  OCR_PREFIX + 'tesseract-core-simd-lstm.wasm.js',
  OCR_PREFIX + 'lang/chi_tra.traineddata'
]);

self.addEventListener('install', event => event.waitUntil(self.skipWaiting()));
self.addEventListener('activate', event => event.waitUntil((async () => {
  await Promise.all((await caches.keys()).filter(key => key.startsWith('yhn-offline-ocr-') && key !== CACHE).map(key => caches.delete(key)));
  await self.clients.claim();
})()));
self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin || !OCR_FILES.has(url.pathname)) return;
  event.respondWith((async () => {
    const cache = await caches.open(CACHE);
    const saved = await cache.match(request);
    if (saved) return saved;
    const response = await fetch(request);
    if (response.ok) await cache.put(request, response.clone());
    return response;
  })());
});
