繁體中文 Tesseract OCR 模型 chi_tra.traineddata
Source: https://github.com/tesseract-ocr/tessdata_fast
License: Apache-2.0
